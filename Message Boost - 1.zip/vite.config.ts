import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    sourcemap: false, // Disable source maps to reduce output size
    rollupOptions: {
      output: {
        manualChunks: undefined // Avoid code splitting to limit file count
      }
    }
  }
})
