// Helper function to handle response

const handleResponse = async <T>(response: Response): Promise<T> => {

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'An error occurred');
    }
    return response.json();
};

// Helper function to set headers

const getHeaders = (): HeadersInit => {

    const headers: HeadersInit = {
        'Content-Type': 'application/json',
    };
    const token = localStorage.getItem('token');
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
};

// Auto-detect environment based on current browser URL

const detectEnvironment = (): 'prod' | 'dev' => {
    if (typeof window !== 'undefined') {
        return window.location.hostname.includes('advicglobal.com') ? 'prod' : 'dev';
    }
    return 'dev';
};

// Get base URL by environment

const getBaseUrl = (env?: 'dev' | 'prod') => {
    const finalEnv = env || detectEnvironment();
    return finalEnv === 'prod'
        ? import.meta.env.VITE_API_BASE_URL_PROD
        : import.meta.env.VITE_API_BASE_URL_DEV;
};

interface ApiConfig extends RequestInit {
    env?: 'dev' | 'prod';
}

const apiService = {
    get: async <T>(url: string, config?: ApiConfig): Promise<T> => {
        const baseUrl = getBaseUrl(config?.env);
        const response = await fetch(`${baseUrl}${url}`, {
            method: 'GET',
            headers: getHeaders(),
            ...config,
        });
        return handleResponse<T>(response);
    },

    post: async <T>(url: string, data?: any, config?: ApiConfig): Promise<T> => {
        const baseUrl = getBaseUrl(config?.env);
        const response = await fetch(`${baseUrl}${url}`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify(data),
            ...config,
        });
        return handleResponse<T>(response);
    },

    put: async <T>(url: string, data?: any, config?: ApiConfig): Promise<T> => {
        const baseUrl = getBaseUrl(config?.env);
        const response = await fetch(`${baseUrl}${url}`, {
            method: 'PUT',
            headers: getHeaders(),
            body: JSON.stringify(data),
            ...config,
        });
        return handleResponse<T>(response);
    },

    delete: async <T>(url: string, config?: ApiConfig): Promise<T> => {
        const baseUrl = getBaseUrl(config?.env);
        const response = await fetch(`${baseUrl}${url}`, {
            method: 'DELETE',
            headers: getHeaders(),
            ...config,
        });
        return handleResponse<T>(response);
    },
};

export default apiService;
