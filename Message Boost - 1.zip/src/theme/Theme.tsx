import { ThemeConfig } from "antd";

// Custom tokens for your app
export const customTokens = {
    colorBgHeader: "#BFC8CD",    // Custom background for the header
    colorBgSidebar: "#9DA7AE",   // Custom background for the sidebar
    colorTextHeader: "#292D31",   // Custom text color for the header
    colorTextSidebar: "#3D4247",  // Custom text color for the sidebar
    colorButtonSuccess: "#27AE60",// Custom success button color
    colorButtonDanger: "#E74C3C", // Custom danger button color
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",  // Box shadow style
    borderRadius: 8,    // Border radius for elements
};

export const theme: ThemeConfig = {
  token: {
    // 🌈 Brand Colors (Soft yet elegant)
    colorPrimary: '#4F86F7',          // Soft but rich blue
    colorSuccess: '#3DC47E',          // Calming green
    colorWarning: '#FFB020',          // Gentle amber
    colorError: '#FF5A5F',            // Soft alert red
    colorInfo: '#7A9CF7',             // Complementary info blue

    // 🎨 Neutral Palette
    colorBgBase: '#F9FAFB',           // Main page background (almost white)
    colorBgContainer: '#FFFFFF',      // Cards, panels, tables
    colorBgElevated: '#FCFCFD',       // Slightly lifted elements

    colorTextBase: '#1E1E1E',         // Primary text (dark gray, not pure black)
    colorTextSecondary: '#4B5563',    // Subdued body text
    colorTextTertiary: '#9CA3AF',     // Placeholder, labels

    // 🧱 Borders & Dividers
    colorBorder: '#E5E7EB',           // Soft gray for component boundaries
    colorBorderSecondary: '#F3F4F6',  // Extra subtle borders (inner dividers)

    // 🧭 Shadows & Radius
    boxShadow: '0 2px 6px rgba(0, 0, 0, 0.04)',
    borderRadius: 6,
  },

  components: {
    Layout: {
      colorBgHeader: '#FFFFFF',
      colorText: '#1E1E1E',
    },
    Menu: {
      colorItemBg: '#FFFFFF',
      colorItemText: '#4B5563',
      colorItemTextHover: '#4F86F7',
      colorItemBgSelected: '#E0E7FF',
    },
    Button: {
      colorPrimary: '#4F86F7',
      colorLink: '#4F86F7',
    },
    Card: {
      colorBgContainer: '#FFFFFF',
      padding: 20,
      borderRadius: 12,
    },
    Table: {
      colorBgContainer: '#FFFFFF',
      colorBorder: '#E5E7EB',
      headerBg: '#F3F4F6',
    },
  },
};

export const darkTheme: ThemeConfig = {
    token: {
        colorBgBase: "#1e1e2f",         // Background color for dark mode
        colorBgContainer: "#252540",   // Container background for dark mode (use this for card backgrounds as well)
        colorPrimary: "#4A90E2",        // Primary color in dark mode
        colorPrimaryHover: "#3679c2",   // Primary hover color in dark mode
        colorPrimaryActive: "#265a8a",  // Primary active color in dark mode
        colorTextBase: "#ffffff",       // Text color in dark mode
        colorTextSecondary: "#aaa",     // Secondary text color in dark mode
        colorLink: "#4A90E2",           // Link color in dark mode
        colorBorderBg: "#444",          // Border color for backgrounds in dark mode
        colorBorder: "#666",            // Replaced colorBorderInput with colorBorder in dark mode
        // Removed colorCardBg since it's not valid
    },
};
