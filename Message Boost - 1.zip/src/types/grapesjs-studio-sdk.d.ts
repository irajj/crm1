declare module '@grapesjs/studio-sdk/style' {
    const content: any;
    export default content;
}

declare module '@grapesjs/studio-sdk/react' {
    interface CreateEditorOptions {
        licenseKey?: string;
        theme?: string;
        project?: any;
        storage?: {
            type: string;
            onSave: () => Promise<void>;
            onLoad: () => Promise<any>;
            autosaveChanges?: number;
            autosaveIntervalMs?: number;
        };
        plugins?: (string | ((editor: any) => void))[];
        pluginOptions?: {
            [key: string]: any;
        };
        canvas?: {
            styles?: string[];
            scripts?: string[];
            customBadgeLabel?: string;
            disableSelection?: boolean;
            disableDrag?: boolean;
            disablePointerEvents?: boolean;
        };
    }

    const StudioEditor: React.FC<{
        options: CreateEditorOptions;
        onReady?: (editor: any) => void;
        ref?: React.RefObject<any>;
        setEmailBody?: (body: string) => void;
    }>;

    export default StudioEditor;
} 