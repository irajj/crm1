import { ConfigProvider } from "antd";
import AppRoutes from "./Routes";
import { theme } from "./theme/Theme";
import './App.css'

const App = () => {
    return (
        <ConfigProvider theme={theme}>
            <AppRoutes />
        </ConfigProvider>
    );
};

export default App;
