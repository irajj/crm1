// Date : 27-05-2025
// new created record must be show in the first page.


// Date:03-06-2025
// Remove the button
// Remove the select all Checkbox.


// Date:10-06-2025
// Change the header name

// Date:23-06-2025
// add a new status


// Date:30-06-2025
// make the record disable when status is the schedual


import { Button, Flex, Table, Tag } from "antd";
import type { TableColumnsType, TableProps } from "antd";
import { TableRowSelection } from "antd/es/table/interface";
import Title from "antd/es/typography/Title";
import dayjs from "dayjs";
import { Plus } from "lucide-react";
import { useEffect, useState, useCallback } from "react";
import apiService from "../../services/ApiService";
import { Link } from "react-router-dom";
import Search, { SearchProps } from "antd/es/input/Search";
import "antd/dist/reset.css";
import "./Campaigns.css";
import { useNavigate } from "react-router-dom";

interface DataType {
  key: string;
  msgsetupname: string;
  msgsetupmessagestatuslable: string;
  id: string;
  name: string;
  date: string;
  createdon: string;
  createdOnFormatted: string;
  createdby: {
    EntityLogicalName: string;
    id: string;
    name: string;
  };
}

const statusColors: Record<string, string> = {
  
  "In Progress": "orange",
  Scheduled: "yellow",
  
  Sent: "green",
  "Pending Setup": "blue", 
};


const columns: TableColumnsType<DataType> = [
  {
    title: "Name",
    dataIndex: "msgsetupname",
    sorter: (a, b) =>
      (a.msgsetupname || "").localeCompare(b.msgsetupname || ""),
    sortDirections: ["ascend", "descend"],
  },
  {
    title: "Scheduled Date",
    dataIndex: "msgsetupsenddatetimeformet",
    sorter: (a, b) =>
      (dayjs(a.date).isValid() ? dayjs(a.date).valueOf() : 0) -
      (dayjs(b.date).isValid() ? dayjs(b.date).valueOf() : 0),
    sortDirections: ["ascend", "descend"],
  },
  {
    title: "Status",
    dataIndex: "msgsetupmessagestatuslable",
    sorter: (a, b) =>
      (a.msgsetupmessagestatuslable || "").localeCompare(
        b.msgsetupmessagestatuslable || ""
      ),
    sortDirections: ["ascend", "descend"],
    render: (status) => (
      <Tag color={statusColors[status] || "default"}>{status}</Tag>
    ),
  },
  {
    title: "Created On",
    dataIndex: "createdOnFormatted",
    render: (text) => (dayjs(text).isValid() ? text : "N/A"),
    sorter: (a, b) =>
      (dayjs(a.createdOnFormatted).isValid()
        ? dayjs(a.createdOnFormatted).valueOf()
        : 0) -
      (dayjs(b.createdOnFormatted).isValid()
        ? dayjs(b.createdOnFormatted).valueOf()
        : 0),
    sortDirections: ["ascend", "descend"],
  },
  {
    title: "Created By",
    dataIndex: ["createdby", "name"],
    sorter: (a, b) =>
      (a.createdby?.name || "").localeCompare(b.createdby?.name || ""),
    sortDirections: ["ascend", "descend"],
  },
];

const Campaigns = () => {
  const navigate = useNavigate();
  const [data, setData] = useState<DataType[]>([]);
  const [originalData, setOriginalData] = useState<DataType[]>([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [isInitialLoad, setIsInitialLoad] = useState(true);

  const fetchData = useCallback(
    async (page: number, count: number) => {
      setLoading(true);
      try {
        const endpoint = isInitialLoad
          ? `/messagesetup`
          : `/messagesetup?PageNumber=${page}&count=${count}`;

        const response = await apiService.get<any>(endpoint);

        const items = isInitialLoad ? response.data : response.data?.items;

        const total = isInitialLoad
          ? Array.isArray(response.data)
            ? response.data.length
            : 0
          : response.data?.totalCount || 0;

        // Sort items by createdon in descending order
        items.sort((a: any, b: any) => {
          const dateA = dayjs(a.createdon);
          const dateB = dayjs(b.createdon);
          if (dateA.isValid() && dateB.isValid()) {
            return dateB.valueOf() - dateA.valueOf();
          } else if (dateA.isValid()) {
            return -1;
          } else if (dateB.isValid()) {
            return 1;
          } else {
            return 0;
          }
        });

        const mappedData = items.map((item: any) => ({
          ...item,
          key: item.id,
          createdOnFormatted: dayjs(item.createdon).format("YYYY-MM-DD HH:mm"),
        }));
        setData(mappedData);
        setOriginalData(mappedData);
        setTotalCount(total);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    },
    [isInitialLoad]
  );

  useEffect(() => {
    const loadData = async () => {
      await fetchData(currentPage, pageSize);
      if (isInitialLoad) setIsInitialLoad(false);
    };
    loadData();
  }, [currentPage, pageSize, fetchData, isInitialLoad]);

  useEffect(() => {
    if (searchText) {
      const filteredData = originalData.filter((item) =>
        item.msgsetupname?.toLowerCase().includes(searchText.toLowerCase())
      );
      setData(filteredData);
    } else {
      setData(originalData);
    }
  }, [searchText, originalData]);

  const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
    const filteredKeys = newSelectedRowKeys.filter((key) => {
      const record = data.find((item) => item.key === key);
      return (
        record &&
        record.msgsetupmessagestatuslable !== "Scheduled" &&
        record.msgsetupmessagestatuslable !== "Sent"
      );
    });
    setSelectedRowKeys(filteredKeys);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    hideSelectAll: true,
    // Disable checkbox for Scheduled records
    getCheckboxProps: (record: DataType) => ({
      disabled:
        record.msgsetupmessagestatuslable === "Scheduled" ||
        record.msgsetupmessagestatuslable === "Sent",
    }),
  };



  const onSearch: SearchProps["onSearch"] = (value) => {
    setSearchText(value.trim());
    setCurrentPage(1);
  };

  const handleTableChange: TableProps<DataType>["onChange"] = (pagination) => {
    if (pagination.current !== currentPage) {
      setCurrentPage(pagination.current!);
    }
    if (pagination.pageSize !== pageSize) {
      setPageSize(pagination.pageSize!);
      setCurrentPage(1);
    }
  };
  const handleRowDoubleClick = (record: DataType) => {
    console.log(record);
    navigate(`/campaigns/${record.id}`);
  };



  return (
    <Flex vertical style={{ height: "100%" }}>
      <div
        className="menubar"
        style={{
          borderBottom: "1px solid #dde4e9",
          padding: "0.4rem",
          background: "white",
          position: "sticky",
          top: "48px",
          zIndex: "2",
        }}
      >
        <Flex gap={"0.2rem"}>
          <Link to="new">
            <Button color="default" variant="filled" size="middle">
              <Plus size={16} />
              New
            </Button>
          </Link>
          {/* <Button
            size="middle"
            color="danger"
            variant="text"
            disabled={selectedRowKeys.length === 0}
          >
            <Trash size={16} />
            Delete
          </Button> */}
        </Flex>
      </div>
      <Flex
        vertical
        style={{
          padding: "1rem",
          background: "white",
          flexGrow: "1",
        }}
      >
        <Flex
          justify="space-between"
          align="center"
          style={{ marginBottom: "1rem" }}
        >
          <Title level={4}>Campaigns</Title>

          <Flex gap="middle" justify="end" align="center">
            <Search
              placeholder="Search campaigns"
              onSearch={onSearch}
              style={{ width: 200 }}
            />
          </Flex>
        </Flex>

        <Table<DataType>
          style={{ flexGrow: 1 }}

          columns={columns}
          dataSource={data}
          onChange={handleTableChange}
          loading={loading}
          rowSelection={{
            ...rowSelection,
            hideSelectAll: true
          }}
          onRow={(record: DataType) => ({
            onDoubleClick: () => handleRowDoubleClick(record),
            style: { cursor: 'pointer' }
          })}

          scroll={{ y: "calc(100vh - 299px)", x: "none" }}
          pagination={{
            current: currentPage,
            pageSize: pageSize,
            total: totalCount,
            showSizeChanger: true,
            pageSizeOptions: ["10", "20", "50", "100"],
          }}
          showSorterTooltip={{ target: "sorter-icon" }}
        />
      </Flex>
    </Flex>
  );
};

export default Campaigns;