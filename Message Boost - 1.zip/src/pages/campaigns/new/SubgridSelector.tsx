//31-05-2025
// Author: Abhishek
// Made ui changes
//  - made spacing changes like margins and padding


// Author: Deven
// date: 24-06-2025
// disable the import button when user not select any audiance type.

// Date:30-06-2025
// make the record disable when status is the schedual

// Date:04-08-2025
// make the Audience Type required

import { Button, Select, Space } from 'antd';
import { Minus, Plus } from 'lucide-react';

interface SubgridSelectorProps {
    subgridType: string;
    handleSubgridType: (value: string) => void;
    showDrawer: () => void;
    handleDelete: () => Promise<void>;
    showRemoveButton: boolean;
    isExistingCampaign: boolean;
    showAudienceType?: boolean;
    isScheduled?: boolean;
}

const SubgridSelector: React.FC<SubgridSelectorProps> = ({
    subgridType,
    handleSubgridType,
    showDrawer,
    handleDelete,
    showRemoveButton,
    isExistingCampaign,
    showAudienceType = true,
    isScheduled = false,
}) => {
    return (
        <div style={{
            marginBottom: '16px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
        }}>
            <div>
                {showAudienceType && (
                    <>
                        <label style={{ marginRight: 8 }}>Audience Type  <span style={{ color: 'red' }}>*</span></label>
                        <Select
                            onChange={isScheduled ? undefined : handleSubgridType}
                            value={subgridType}
                            style={{ minWidth: '100px', marginRight: '20px' }}
                            disabled={isExistingCampaign || isScheduled}
                            options={[
                                { value: 'none', label: 'None', disabled: true },
                                { value: 'Account', label: 'Account' },
                                { value: 'Contact', label: 'Contact' },
                                { value: 'Lead', label: 'Lead' },
                            ]}
                        />
                    </>
                )}
                {!showAudienceType && (
                    <>
                        <label style={{ marginRight: 8 }}>Suppression Lists</label>
                    </>
                )}
            </div>
            <div>

                <Space>
                    <Button type="primary" onClick={showDrawer} disabled={subgridType === 'none' || isScheduled}>
                        <Plus size={16} /> Import
                    </Button>
                    {showRemoveButton && (
                        <Button danger onClick={handleDelete} disabled={isScheduled}>
                            <Minus size={16} /> Remove
                        </Button>
                    )}
                </Space>
            </div>
        </div>
    );
};

export default SubgridSelector;