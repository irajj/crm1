// Author: Deven
// Date: 2025-06-11
// This is a duplicate of importDrawer.tsx for the right-side import functionality. You can now customize this file independently.
//
// If you want to make changes specific to the right-side import drawer, do so here.
//
// Original importDrawer.tsx content below:
// ... existing code ... 

import { Button, Drawer, Empty, Form, Space, Table, Spin } from "antd";
import { ColumnType } from "antd/es/table";
import React, { useEffect, useState } from "react";
import apiService from "../../../services/ApiService";

interface ImportDrawerProps {
    open: boolean;
    onClose: () => void;
    subgridType: string;
    onImport: (selectedRows: Record<string, any>[]) => void;
    importedRows: Record<string, any>[];
}

interface DataType {
    id: string;
    contactEmailAddress?: string;
    contactFullname?: string;
    statusLabel?: string;
    emailaddress1?: string;
    [key: string]: any;
}

const ImportDrawerRight: React.FC<ImportDrawerProps> = ({
    open,
    onClose,
    subgridType,
    onImport,
    importedRows,
}) => {
    const [data, setData] = useState<DataType[]>([]);
    const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
    const [selectedRows, setSelectedRows] = useState<Record<string, any>[]>([]);
    const [form] = Form.useForm();
    const [isLoading, setIsLoading] = useState(false);
    const [, setError] = useState<string | null>(null);
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0,
    });

    // Fetch marketing data when drawer opens
    useEffect(() => {
        if (open && subgridType !== "none") {
            const fetchMarketingData = async () => {
                setIsLoading(true);
                try {
                    const response = await apiService.get<any>(
                        `/marketing/${subgridType}`
                    );
                    const responseData = Array.isArray(response.data) ? response.data : [];
                    setData(responseData);
                    setPagination((prev) => ({
                        ...prev,
                        total: response.total || responseData.length,
                    }));
                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                } catch (error) {
                    setError("Failed to load marketing data");
                } finally {
                    setIsLoading(false);
                }
            };
            fetchMarketingData();
        }
    }, [open, subgridType]);

    // Sync selected rows with importedRows
    useEffect(() => {
        if (Array.isArray(importedRows)) {
            setSelectedRows(importedRows);
            setSelectedRowKeys(importedRows.map((row) => row.id));
        } else {
            setSelectedRows([]);
            setSelectedRowKeys([]);
        }
    }, [importedRows]);

    // Reset states when drawer closes
    useEffect(() => {
        if (!open) {
            setData([]);
            setSelectedRowKeys([]);
            setSelectedRows([]);
            form.resetFields();
            setPagination({ current: 1, pageSize: 10, total: 0 });
            setError(null);
        }
    }, [form, open]);

    // Dynamic column configuration based on subgridType
    const getColumns = (): ColumnType<DataType>[] => {
        return [{
            title: "Name",
            dataIndex: "name",
            render: (_: any, record: DataType) => record.name,
            sorter: (a, b) => (a.name || "").localeCompare(b.name || ""),
            sortDirections: ["ascend", "descend"],
            showSorterTooltip: true,
        }];
    };

    const handleTableChange = (newPagination: any) => {
        const isPageSizeChanged = newPagination.pageSize !== pagination.pageSize;
        setPagination({
            ...newPagination,
            current: isPageSizeChanged ? 1 : newPagination.current, // Reset to page 1 if page size changes
        });
    };

    const onSelectChange = (
        newSelectedRowKeys: React.Key[],
        newSelectedRows: Record<string, any>[]
    ) => {
        setSelectedRowKeys(newSelectedRowKeys);
        setSelectedRows(newSelectedRows);
    };

    const rowSelection = {
        selectedRowKeys,
        onChange: onSelectChange,
    };

    const handleImport = () => {
        onImport(selectedRows);
        onClose();
    };

    return (
        <Drawer
            title="List"
            width={720}
            onClose={onClose}
            open={open}
            extra={
                <Space>
                    <Button onClick={onClose}>Cancel</Button>
                    <Button type="primary" onClick={handleImport}>
                        Import List
                    </Button>
                </Space>
            }
        >
            <Form layout="vertical" form={form} className="import-drawer-form">
                {isLoading ? (
                    <div style={{ textAlign: "center", padding: "40px 0" }}>
                        <Spin size="large" tip="Loading data..." />
                    </div>
                ) : data.length > 0 ? (
                    <>
                        <div
                            style={{
                                marginBottom: 16,
                                display: "flex",
                                alignItems: "center",
                                gap: "16px",
                            }}
                        >
                            <Button
                                type="primary"
                                onClick={() => {
                                    if (selectedRowKeys.length === data.length) {
                                        setSelectedRowKeys([]);
                                        setSelectedRows([]);
                                    } else {
                                        const allKeys = data.map((item) => item.id);
                                        const allRows = data;
                                        setSelectedRowKeys(allKeys);
                                        setSelectedRows(allRows);
                                    }
                                }}
                                disabled={data.length === 0}
                            >
                                {selectedRowKeys.length === data.length
                                    ? `Deselect All List`
                                    : `Select All List`}
                            </Button>
                            <span style={{ fontSize: "14px", color: "#666" }}>
                                Selected: {selectedRowKeys.length}{" "}
                                {selectedRowKeys.length === 1 ? "List" : "Lists"}
                            </span>
                        </div>
                        <Table
                            rowSelection={rowSelection}
                            dataSource={data}
                            rowKey="id"
                            columns={getColumns()}
                            pagination={{
                                ...pagination,
                                showSizeChanger: true,
                                showTotal: (total) => `Total ${total} items`,
                            }}
                            onChange={handleTableChange}
                            style={{ flexGrow: 1 }}
                            scroll={{ y: "calc(100vh - 388px)", x: "none" }}
                            showSorterTooltip={{ target: "sorter-icon" }}
                        />
                    </>
                ) : (
                    <div style={{ textAlign: "center", padding: "40px 0" }}>
                        <Empty description="No data found for the selected list." />
                    </div>
                )}
            </Form>
        </Drawer>
    );
};

export default ImportDrawerRight; 