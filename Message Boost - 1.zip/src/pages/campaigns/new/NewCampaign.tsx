// Author: Deven
// Date: 14-05-2025



// Solved the issue of focusing the cursor in the email editor.
// Updated the email body to show in the preview.
// remove the editor name



// Date: 15-05-2025
// Add alert on the refresh



// Date: 20-05-2025
// Bug in the Previos Button
// lock the Message Type filed
// lock the Audience Type when user id is already exitis
// Done button click issue
// open recored issue



// Date : 21-05-2025

// resolve the error in the campiagn page -- done
// remove the cureent editor and add a grape js editor



// Date : 26-05-2025

// clen-up  a campaign page record
// check the all the remaning record must be work. not give any error
// remove the grapeJs editor into Preview model and add a simple div to show a email body.
// change the ui of the campaign page of the second step. in that step all the fields are arrange side by side and put a grapejs into last with full width and height.



// Date: 27-05-25
// change the current Stage  value +1 all the . this changes are come from a backend.
// new created record must be show in the frist page.
// lock the Grapejs default when user click on the edit template button then only can be edit.
// call a associate api when user add more leads/contacts/accounts in the exiting ones
// add a loader in the import button
// changes into all notification
// change the api payload


// Date:28-05-2025
// remove the loader when user deassociate the users.
// call the deassociatemessagesetup and associatemessagesetup api into next button


// Date:30-05-2025
// Change the API payload — fromName and fromEmail should be passed into the messageSetup API

// Date:31-05-2025
// change the api call


// Date:01-06-2025
// remove the notification when user are not import any data and click on the next button
// fix the email body show

// Date:02-06-2025
// remove the words like records and data and mke it dynmeic like contacs, Lead and Account.
// Pass a query parameter into api

// Date:03-06-2025
// Changes the Api of the /templatepreviewpersonalization/${subgridType.toLowerCase()}/${masgid}
// add a warning for the user when they select a audince type but not import a single recods and try to click on the next.

// make changes dyanemic in the notification

// Date:03-06-2025
// fix the issue in the Account url
// Fix the Api of the Preview

// Date:05-06-2025
// show a campaign name when user click on the extings record at a right side of the back arrow button
// user can edit that name.
// alos when new campiagn created


// Date:10-06-2025
// Time Zone remove
// add a subgrid
// Changes into ui

// Date: 17-06-2025
// next button diable when use click on the next
// change the notification

// Date: 19-06-2025
// fix the css of the campagin name
// add a loader into preview model
// test the email template for the import the code from the outside

// Date:20-06-2025
// changes into paylaod

// Date:24-06-2025
// Manage the next button

// Date: 26-06-2025
// solve the issue in the email bosy show

// Date:27-06-2025
// solve the issue of the staus are not proper show when user are sedual or on-progres.

// Date:30-06-2025
// make the record disable when status is the schedual
//Prevent POST API calls in handleNext when status is Scheduled to avoid status updates
// add a statisc notification on the top of the head recodrs when status is the Scheduled

// Date:03-07-2025
// solve the issue of the data in the current ==2 when record is the read only mode.

// Date:03-07-2025
// Make a Summary and changes the layout of that and some ui changes.

// Date:04-07-2025
// only one api are call when record are in the read only mode



// date: 04-08-2025
// uncommnet the redireact issue (Line 641)
// make the campaign name required


import { useEffect, useState, useRef } from 'react';
import type { InputRef } from 'antd';
import {
    Card,
    Empty,
    Steps,
    Table,
    Input,
    Select,
    Row,
    Col,
    Button,
    Form,
    Radio,
    DatePicker,
    Typography,
    Alert,
    notification,
    Spin,
    Flex,
    Divider,
    Modal,
    Descriptions,
    Badge,
    Tag,

} from 'antd';
import { EditOutlined, SaveOutlined, CloseOutlined, UserOutlined, StopOutlined, ProfileOutlined, EyeOutlined } from '@ant-design/icons';
import SubgridSelector from './SubgridSelector';
import StepNavigation from './StepNavigation';
import dayjs from 'dayjs';
import { Link, useNavigate, useParams } from 'react-router-dom';
import apiService from '../../../services/ApiService';
import { ArrowLeft } from 'lucide-react';
import ImportDrawer from './importDrawer';
import ImportDrawerRight from './importDrawerRight';
import Overview from './campaignGrapeJs/GrapeJs';
const { Title } = Typography;
const { Option } = Select;
import './NewCampaign.css'
import Paragraph from 'antd/es/skeleton/Paragraph';
import { red } from '@mui/material/colors';

interface PreviewRecord {
    id: string;
    name: string;
    entityLogicalName: string;
    accountname?: string;
}

interface ColumnType {
    title: string;
    dataIndex: string;
    key: string;
    sorter?: (a: any, b: any) => number;
    render?: (value: any, record: any, index: number) => React.ReactNode;
}

const columns: Record<string, ColumnType[]> = {
    none: [],
    Contact: [
        {
            title: 'Email Address',
            dataIndex: 'contactEmailAddress',
            key: 'contactEmailAddress',
            sorter: (a, b) => a.contactEmailAddress.localeCompare(b.contactEmailAddress),
        },
        {
            title: 'Full Name',
            dataIndex: 'contactFullname',
            key: 'contactFullname',
            sorter: (a, b) => a.contactFullname.localeCompare(b.contactFullname),
        },
        {
            title: 'Company',
            dataIndex: 'company.name',
            key: 'company.name',
            render: (_: any, record: any) => record.company?.name || '',
            sorter: (a, b) => (a.company?.name || '').localeCompare(b.company?.name || ''),
        },
        // {
        //     title: 'City',
        //     dataIndex: 'contactAddressCity',
        //     key: 'contactAddressCity',
        //     sorter: (a, b) => a.cityField - b.cityField,
        // },
        {
            title: 'Status',
            dataIndex: 'statusLabel',
            key: 'status',
            sorter: (a, b) => a.status - b.status,
        },
    ],
    Lead: [
        {
            title: 'Full Name',
            dataIndex: 'fullname',
            key: 'fullname',
            sorter: (a, b) => a.fullnameField.localeCompare(b.fullnameField),
        },
        {
            title: 'Email Address',
            dataIndex: 'emailaddress1',
            key: 'emailaddress1',
            sorter: (a, b) => a.emailField.localeCompare(b.emailField),
        },
        {
            title: 'Company',
            dataIndex: 'company.name',
            key: 'company.name',
            render: (_: any, record: any) => record.company?.name || '',
            sorter: (a, b) => (a.company?.name || '').localeCompare(b.company?.name || ''),
        },
        {
            title: 'Contact',
            dataIndex: 'contact.name',
            key: 'contact.name',
            render: (_: any, record: any) => record.contact?.name || '',
            sorter: (a, b) => a.contactfield.localeCompare(b.contactfield),
        },
        {
            title: 'Status',
            dataIndex: 'company.statusLabel',
            key: 'company.statusLabel',
            render: (_: any, record: any) => record.company?.statusLabel || '',
            sorter: (a, b) => (a.company?.statusLabel || '').localeCompare(b.company?.statusLabel || ''),
        },
    ],
    Account: [
        {
            title: 'Full Name',
            dataIndex: 'name',
            key: 'name',
            sorter: (a, b) => a.fullName.localeCompare(b.fullName),
        },
        {
            title: 'Email Address',
            dataIndex: 'accountemailaddress',
            key: 'accountemailaddress',
            sorter: (a, b) => a.emailField.localeCompare(b.emailField),
        },
        {
            title: 'Primary Contact',
            dataIndex: 'contact.name',
            key: 'contact.name',
            render: (_: any, record: any) => record.contact?.name || '',
            sorter: (a, b) => a.primarycontact - b.primarycontact,
        },
        {
            title: 'Main Phone',
            dataIndex: 'mobilephone',
            key: 'mobilephone',
            sorter: (a, b) => a.phonenumber.localeCompare(b.phonenumber),
        },
        {
            title: 'Status',
            dataIndex: 'statusLabel',
            key: 'status',
            sorter: (a, b) => a.status - b.status,
        },
    ],
};

const steps = [
    { title: 'Define Audience' },
    { title: 'Select Template' },
    { title: 'Set Schedule' },
];

interface MessageSetupPayload {
    id: string | null;
    msgsetupmessagestatus: number;
    currentstage: number;
    msgsetupsendnow?: boolean;
    msgsetupsenddatetime?: string | null;
    msgsetupname?: string | null;
}

const NewCampaign: React.FC = () => {
    const { id } = useParams();
    const [current, setCurrent] = useState<number>(0);
    const [isNavigating, setIsNavigating] = useState<boolean>(false);
    const [subgridType, setSubgridType] = useState<string>('none');
    const [open, setOpen] = useState<boolean>(false);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [openRight, setOpenRight] = useState<boolean>(false);
    const [previewRecords, setPreviewRecords] = useState<PreviewRecord[] | null>(null);
    const [selectedRecord, setSelectedRecord] = useState<string | null>(null);
    const [htmlPreviewData, setHtmlPreviewData] = useState<string>('');
    const [openPreview, setOpenPreview] = useState<boolean>(false);
    const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [showUnsavedChangesModal, setShowUnsavedChangesModal] = useState<boolean>(false);
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [pendingNavigation, setPendingNavigation] = useState<number | null>(null);
    const [tableColumns, setTableColumns] = useState<ColumnType[]>([]);
    const [data, setData] = useState<Record<string, any>[]>([]);
    const [rightGridData, setRightGridData] = useState<Record<string, any>[]>([]);
    const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
    const [selectedRows, setSelectedRows] = useState<Record<string, any>[]>([]);
    const [rightSelectedRowKeys, setRightSelectedRowKeys] = useState<React.Key[]>([]);
    const [rightSelectedRows, setRightSelectedRows] = useState<Record<string, any>[]>([]);
    const [templates, setTemplates] = useState<any[]>([]);
    const [emailBody, setEmailBody] = useState<string>('');
    const [scheduleType, setScheduleType] = useState<string>('0');
    const [deliveryDate, setDeliveryDate] = useState<string>('');
    const [isScheduled, setIsScheduled] = useState<boolean>(false);
    const [isReadOnly, setIsReadOnly] = useState<boolean>(false);
    const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);

    const [templateDetails, setTemplateDetails] = useState<{
        id: string;
        messageType: string;
        emailSubject: string;
        // fromUser: { id: string; name: string };
        // fromName: string;
        // fromEmail: string;
        emailBody: string;
    }>({
        id: '',
        messageType: '',
        emailSubject: '',
        // fromUser: { id: '', name: '' },
        // fromName: '',
        // fromEmail: '',
        emailBody: '',
    });
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [messageSetup, setMessageSetup] = useState<{
        fromName: string;
        fromEmail: string;
    }>({
        fromName: '',
        fromEmail: ''
    });
    const [selectedTemplate, setSelectedTemplate] = useState<string | undefined>(undefined);
    const [masgid, setMsgid] = useState<string | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [isDeleting, setIsDeleting] = useState<boolean>(false);
    const [editedEmailBody, setEditedEmailBody] = useState<string>('');
    const [isEditing, setIsEditing] = useState<boolean>(false);
    const [form] = Form.useForm();
    const [api, contextHolder] = notification.useNotification();
    const navigate = useNavigate();
    const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
    const [, setNewlyImportedRecords] = useState<Record<string, any>[]>([]);
    const [key, setKey] = useState<number>(0);
    const [campaignName, setCampaignName] = useState<string>('');
    const [isEditingName, setIsEditingName] = useState<boolean>(false);
    const [editedCampaignName, setEditedCampaignName] = useState<string>('');
    const [isSavingName, setIsSavingName] = useState<boolean>(false);
    const inputRef = useRef<InputRef>(null);

    const handleSaveCampaignName = async () => {
        // Prevent saving campaign name if status is Scheduled
        if (isReadOnly) {
            api.open({
                message: "Cannot Edit Campaign Name",
                description: "Campaign name cannot be edited when status is Scheduled.",
                type: "warning",
                duration: 2,
            });
            setIsNavigating(false);
            return false;
        }
        if (!editedCampaignName.trim()) {
            api.open({
                message: 'Campaign Name Required',
                description: 'Please enter a name for your campaign.',
                type: 'warning',
                duration: 2,
            });
            setIsNavigating(false);
            return;
        }
        if (id || masgid) {
            try {
                setIsSavingName(true);
                const payload = {
                    id: id || masgid,
                    msgsetupname: editedCampaignName,
                };

                await apiService.post('/messagesetup', payload);
                setCampaignName(editedCampaignName);
                setIsEditingName(false);

                api.open({
                    message: 'Success',
                    description: 'Campaign name updated successfully.',
                    type: 'success',
                    duration: 2,
                });
            } catch (error: any) {
                api.open({
                    message: 'Error',
                    description: error.message || 'Failed to update campaign name.',
                    type: 'error',
                    duration: 2,
                });
                setIsNavigating(false);
                return false;
            } finally {
                setIsSavingName(false);
            }
        } else {

            setCampaignName(editedCampaignName);
            setIsEditingName(false);
            return true;
        }
    };

    const handleNameClick = () => {
        setEditedCampaignName(campaignName);
        setIsEditingName(true);
        setTimeout(() => {
            inputRef.current?.focus();
        }, 0);
    };

    const handleNameBlur = () => {
        if (editedCampaignName !== campaignName) {
            handleSaveCampaignName();
        } else {
            setIsEditingName(false);
        }
    };

    const handleNameKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleSaveCampaignName();
        } else if (e.key === 'Escape') {
            setIsEditingName(false);
            setEditedCampaignName(campaignName);
        }
    };

    useEffect(() => {
        if (!id && !campaignName && !isReadOnly) {
            setIsEditingName(true);
            setEditedCampaignName('');
            setTimeout(() => {
                inputRef.current?.focus();
            }, 0);
        }
    }, [id, campaignName, isReadOnly]);

    useEffect(() => {
        console.log('useEffect for current === 1 triggered', {
            current,
            id,
            masgid,
            selectedTemplate,
            templateDetails,
            emailBody,
            editedEmailBody,
            localStorageEmailBody: localStorage.getItem(`campaign_${id || masgid}_email_body`),
        });
        if (current === 1) {
            setIsEditing(false);
            if (isReadOnly) {
                // In read-only mode, only load saved email body from localStorage
                const savedEmailBody = localStorage.getItem(`campaign_${id || masgid}_email_body`);
                if (savedEmailBody) {
                    setEditedEmailBody(savedEmailBody);
                    setEmailBody(savedEmailBody);
                    setTemplateDetails((prev) => ({ ...prev, emailBody: savedEmailBody }));
                }
                setKey((prev) => prev + 1);
                return;
            }
            if (id || masgid) {
                const savedEmailBody = localStorage.getItem(`campaign_${id || masgid}_email_body`);
                if (savedEmailBody) {
                    setEditedEmailBody(savedEmailBody);
                    setEmailBody(savedEmailBody);
                    setTemplateDetails((prev) => ({ ...prev, emailBody: savedEmailBody }));
                } else if (selectedTemplate) {
                    const fetchTemplateData = async () => {
                        try {
                            setLoading(true);
                            const response = await apiService.get<{ data: any }>(`/messagetemplate/${selectedTemplate}`);
                            const data = response.data;
                            if (data && data.emailbody) {
                                setEmailBody(data.emailbody);
                                setEditedEmailBody(data.emailbody);
                                setTemplateDetails((prev) => ({ ...prev, emailBody: data.emailbody }));
                            } else {
                                setEmailBody('');
                                setEditedEmailBody('');
                                setTemplateDetails((prev) => ({ ...prev, emailBody: '' }));
                                api.open({
                                    message: 'Template Data Missing',
                                    description: 'No email body found for the selected template.',
                                    type: 'warning',
                                    duration: 2,
                                });
                            }
                        } catch (error) {
                            console.error('Error fetching template data:', error);
                            api.open({
                                message: 'Error Loading Template',
                                description: 'Failed to load template data. Please try again.',
                                type: 'error',
                                duration: 2,
                            });
                        } finally {
                            setLoading(false);
                        }
                    };
                    fetchTemplateData();
                } else {
                    setEmailBody('');
                    setEditedEmailBody('');
                    setTemplateDetails((prev) => ({ ...prev, emailBody: '' }));
                }
            } else {
                setEmailBody(templateDetails.emailBody || '');
                setEditedEmailBody(templateDetails.emailBody || '');
            }
            setKey((prev) => prev + 1);
        }
    }, [current, id, masgid, selectedTemplate, templateDetails.emailBody]);


    const handleEditTemplate = () => {
        if (isReadOnly) {
            api.open({
                message: "Cannot Edit Template",
                description: "Template editing is disabled when status is Scheduled.",
                type: "warning",
                duration: 2,
            });
            return;
        }
        const currentEmailBody = templateDetails.emailBody || '';
        setEditedEmailBody(currentEmailBody);
        setIsEditing(true);
        if (id) {
            localStorage.setItem(
                `campaign_${id}_original_template`,
                JSON.stringify({
                    templateId: selectedTemplate,
                    emailBody: currentEmailBody,
                })
            );
        }
    };

    const handleCancelEdit = () => {
        const originalTemplateData = localStorage.getItem(`campaign_${id}_original_template`);
        const originalData = originalTemplateData ? JSON.parse(originalTemplateData) : null;
        setEditedEmailBody(originalData?.emailBody || templateDetails.emailBody || '');
        setIsEditing(false);
        setHasUnsavedChanges(false);
    };

    useEffect(() => {
        const handleBeforeUnload = (e: BeforeUnloadEvent) => {
            if (current === 1) {
                e.preventDefault();
                e.returnValue = '';
                return '';
            }
        };

        window.addEventListener('beforeunload', handleBeforeUnload);
        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
        };
    }, [current]);



    const getSubgridType = (primaryentity: number) => {
        if (primaryentity === 1) return 'Contact';
        if (primaryentity === 2) return 'Lead';
        if (primaryentity === 3) return 'Account';
        return 'none';
    };

    // const getSetup = async () => {
    //     setLoading(true);
    //     setError(null);
    //     try {
    //         const response = await apiService.get<any>(`/messagesetup/${id}`);

    //         const isScheduledOrSent = response.data.msgsetupmessagestatuslable === "Scheduled" ||
    //             response.data.msgsetupmessagestatuslable === "Sent";

    //         setIsReadOnly(isScheduledOrSent);

    //         // setIsReadOnly(
    //         //     response.data.msgsetupmessagestatuslable === "Scheduled" ||
    //         //     response.data.msgsetupmessagestatuslable === "Sent"
    //         // );
    //         const primaryEntity = response.data.primaryentity;

    //         if (!Number.isInteger(primaryEntity) || primaryEntity < 1 || primaryEntity > 3) {
    //             setError('Invalid primaryentity value. Please check the record data.');
    //             setLoading(false);
    //             return;
    //         }
    //         const subgridTypeValue = getSubgridType(primaryEntity);
    //         setMsgid(response.data.id);

    //         // Set right grid data from response lists
    //         // if (response.data.lists && Array.isArray(response.data.lists)) {
    //         //     setRightGridData(response.data.lists.map((list: any) => ({
    //         //         id: list.id,
    //         //         name: list.name || list.listname
    //         //     })));
    //         // }

    //         if (subgridTypeValue === 'none') {
    //             setError('Invalid primaryentity value. Please check the record data.');
    //             return;
    //         }

    //         setMsgid(response.data.id);
    //         if (
    //             response.data.msgsetupmessagestatuslable === "Scheduled" ||
    //             response.data.msgsetupmessagestatuslable === "Sent"
    //         ) {
    //             setCurrent(response.data.currentstage - 1);
    //         } else {
    //             setCurrent(response.data.currentstage);
    //         }
    //         setSubgridType(subgridTypeValue);
    //         // console.log('Campaign Name:', response.data.msgsetupname); // Debug log
    //         setCampaignName(response.data.msgsetupname || '');

    //         let scheduleTypeValue = '0'; // Default to "Send Now"
    //         let deliveryDateValue = '';
    //         if (response.data.msgsetupsendnow === true) {
    //             scheduleTypeValue = '0';
    //         } else if (response.data.msgsetupsenddatetime) {
    //             scheduleTypeValue = '1';
    //             deliveryDateValue = response.data.msgsetupsenddatetime;
    //         }
    //         setScheduleType(scheduleTypeValue);
    //         setDeliveryDate(deliveryDateValue);

    //         setCurrent(isScheduledOrSent ? response.data.currentstage - 1 : response.data.currentstage == 3 && response.data.msgsetupmessagestatuslable == "In Progress" ? response.data.currentstage - 1 : response.data.currentstage);


    //         // Set subgrid data
    //         if (response.data.lists && Array.isArray(response.data.lists)) {
    //             setRightGridData(
    //                 response.data.lists.map((list: any) => ({
    //                     id: list.id,
    //                     name: list.name || list.listname,
    //                 }))
    //             );
    //         }

    //         if (subgridTypeValue === 'none') {
    //             setError('Invalid primaryentity value. Please check the record data.');
    //             return;
    //         }
    //         setSubgridType(subgridTypeValue);

    //         // Determine the data key based on subgridType
    //         const dataKey = subgridTypeValue.toLowerCase() + 's'; // e.g., 'contacts', 'leads', 'accounts'
    //         const records = response.data[dataKey] || [];

    //         // Map records to table format
    //         const mappedData = records.map((item: any) => {
    //             if (subgridTypeValue === 'Contact') {
    //                 return {
    //                     id: item.id,
    //                     contactEmailAddress: item.email || item.contactEmailAddress,
    //                     contactFullname: item.fullname || item.contactFullname,
    //                     company: { name: item.company?.name || '' },
    //                     contactAddressCity: item.city || item.contactAddressCity,
    //                     statusLabel: item.status || item.statusLabel,
    //                 };
    //             } else if (subgridTypeValue === 'Lead') {
    //                 return {
    //                     id: item.id,
    //                     fullname: item.fullname || item.fullnameField,
    //                     emailaddress1: item.email || item.emailField,
    //                     company: { name: item.company?.name || '' },
    //                     contact: { name: item.contact?.name || '' },
    //                     statusLabel: item.company?.statusLabel || '',
    //                 };
    //             } else if (subgridTypeValue === 'Account') {
    //                 return {
    //                     id: item.id,
    //                     name: item.name || item.fullName,
    //                     accountemailaddress: item.email || item.emailField,
    //                     contact: { name: item.contact?.name || '' },
    //                     mobilephone: item.mobilephone || item.phonenumber,
    //                     statusLabel: item.status || item.statusLabel,
    //                 };
    //             }
    //             return item;
    //         });

    //         setData(mappedData);
    //         setTableColumns(columns[subgridTypeValue] || []);

    //         // Fetch and set list data
    //         // try {
    //         //     const listResponse = await apiService.get<any>(`/messagesetup/${id}/lists`);
    //         //     const listData = listResponse.data || [];
    //         //     const mappedListData = listData.map((item: any) => ({
    //         //         id: item.id,
    //         //         name: item.name || item.listname,
    //         //     }));
    //         //     setRightGridData(mappedListData);
    //         // } catch (listError) {
    //         //     console.error('Error fetching list data:', listError);
    //         //     // Don't set error state here as it's not critical
    //         // }


    //         const templateData = response.data.messagetemplateid;
    //         setSelectedTemplate(templateData?.id);
    //         const emailBodyFromResponse = response.data.emailbody || templateData?.emailbody || '';
    //         const updatedDetails = {
    //             id: templateData?.id || '',
    //             messageType: templateData?.messagetype || '',
    //             emailSubject: response.data?.msgsetupsubject || '',
    //             emailBody: emailBodyFromResponse,
    //         };

    //         setTemplateDetails(updatedDetails);
    //         setMessageSetup({
    //             fromName: response.data?.msgsetupfromname || '',
    //             fromEmail: response.data?.msgsetupfromemail || '',
    //         });

    //         setEmailBody(emailBodyFromResponse);
    //         setEditedEmailBody(emailBodyFromResponse);

    //         localStorage.setItem(
    //             `campaign_${id}_original_template`,
    //             JSON.stringify({
    //                 templateId: templateData?.id,
    //                 emailBody: emailBodyFromResponse
    //             })
    //         );

    //         form.setFieldsValue({
    //             Template: templateData?.emailtemplatename,
    //             type: updatedDetails.messageType,
    //             subject: updatedDetails.emailSubject,
    //             name: response.data?.msgsetupfromname || '',
    //             email: response.data?.msgsetupfromemail || '',
    //             scheduleType: scheduleTypeValue,
    //             deliveryDate: deliveryDateValue ? dayjs(deliveryDateValue) : null,
    //         });
    //     } catch (error) {
    //         console.error('Error in getSetup:', error);
    //         setError('Failed to load campaign data. Please try again.');
    //     } finally {
    //         setLoading(false);
    //     }
    // };

    const getSetup = async () => {
        setLoading(true);
        setError(null);
        try {
            const response = await apiService.get<any>(`/messagesetup/${id}`);

            const isScheduledOrSent =
                response.data.msgsetupmessagestatuslable === 'Scheduled' ||
                response.data.msgsetupmessagestatuslable === 'Sent';

            setIsReadOnly(isScheduledOrSent);

            const primaryEntity = response.data.primaryentity;

            // Validate primaryentity
            if (!Number.isInteger(primaryEntity) || primaryEntity < 1 || primaryEntity > 3) {
                setError('Invalid primaryentity value. Please check the record data.');
                setLoading(false);
                return;
            }

            const subgridTypeValue = getSubgridType(primaryEntity);
            setMsgid(response.data.id);

            // Set campaign name
            setCampaignName(response.data.msgsetupname || '');

            // Handle read-only mode and current stage
            if (isScheduledOrSent) {
                setCurrent(response.data.currentstage - 1);
            } else {
                setCurrent(
                    response.data.currentstage === 3 &&
                        response.data.msgsetupmessagestatuslable === 'In Progress'
                        ? response.data.currentstage - 1
                        : response.data.currentstage
                );
            }

            setSubgridType(subgridTypeValue);

            // Set right grid data (lists)
            if (response.data.lists && Array.isArray(response.data.lists)) {
                setRightGridData(
                    response.data.lists.map((list: any) => ({
                        id: list.id,
                        name: list.name || list.listname,
                    }))
                );
            }

            // Map records to table format
            const dataKey = subgridTypeValue.toLowerCase() + 's';
            const records = response.data[dataKey] || [];
            const mappedData = records.map((item: any) => {
                if (subgridTypeValue === 'Contact') {
                    return {
                        id: item.id,
                        contactEmailAddress: item.email || item.contactEmailAddress,
                        contactFullname: item.fullname || item.contactFullname,
                        company: { name: item.company?.name || '' },
                        contactAddressCity: item.city || item.contactAddressCity,
                        statusLabel: item.status || item.statusLabel,
                    };
                } else if (subgridTypeValue === 'Lead') {
                    return {
                        id: item.id,
                        fullname: item.fullname || item.fullnameField,
                        emailaddress1: item.email || item.emailField,
                        company: { name: item.company?.name || '' },
                        contact: { name: item.contact?.name || '' },
                        statusLabel: item.company?.statusLabel || '',
                    };
                } else if (subgridTypeValue === 'Account') {
                    return {
                        id: item.id,
                        name: item.name || item.fullName,
                        accountemailaddress: item.email || item.emailField,
                        contact: { name: item.contact?.name || '' },
                        mobilephone: item.mobilephone || item.phonenumber,
                        statusLabel: item.status || item.statusLabel,
                    };
                }
                return item;
            });

            setData(mappedData);
            setTableColumns(columns[subgridTypeValue] || []);

            // Template and message setup
            const templateData = response.data.messagetemplateid;
            setSelectedTemplate(templateData?.id);
            const emailBodyFromResponse = response.data.emailbody || templateData?.emailbody || '';
            const updatedDetails = {
                id: templateData?.id || '',
                messageType: templateData?.messagetype || '',
                emailSubject: response.data?.msgsetupsubject || '',
                emailBody: emailBodyFromResponse,
            };

            setTemplateDetails(updatedDetails);
            setMessageSetup({
                fromName: response.data?.msgsetupfromname || '',
                fromEmail: response.data?.msgsetupfromemail || '',
            });

            setEmailBody(emailBodyFromResponse);
            setEditedEmailBody(emailBodyFromResponse);

            localStorage.setItem(
                `campaign_${id}_original_template`,
                JSON.stringify({
                    templateId: templateData?.id,
                    emailBody: emailBodyFromResponse,
                })
            );

            form.setFieldsValue({
                Template: templateData?.emailtemplatename,
                type: updatedDetails.messageType,
                subject: updatedDetails.emailSubject,
                name: response.data?.msgsetupfromname || '',
                email: response.data?.msgsetupfromemail || '',
                scheduleType: response.data.msgsetupsendnow ? '0' : '1',
                deliveryDate: response.data.msgsetupsenddatetime
                    ? dayjs(response.data.msgsetupsenddatetime)
                    : null,
            });
        } catch (error) {
            console.error('Error in getSetup:', error);
            setError('Failed to load campaign data. Please try again.');
        } finally {
            setLoading(false);
        }
    };
    
    useEffect(() => {
        if (current === 2) {
            form.setFieldsValue({
                scheduleType: scheduleType,
                deliveryDate: deliveryDate ? dayjs(deliveryDate) : null,
            });
        }
    }, [current, scheduleType, deliveryDate, form]);


    useEffect(() => {
        return () => {

            if (id) {
                localStorage.removeItem(`campaign_${id}_original_template`);
                localStorage.removeItem(`campaign_${id}_email_body`);
            }
        };
    }, [id]);

    useEffect(() => {
        if (id) {
            getSetup();
        }
    }, [id]);

    useEffect(() => {
        if (subgridType === 'none') {
            setTableColumns([]);
            return;
        }
        setTableColumns(columns[subgridType] || []);
    }, [subgridType]);

    const fetchTemplates = async () => {
        if (isReadOnly) {
            setTemplates([]);
            return;
        }
        try {
            const response = await apiService.get<any>(`/messagetemplates/${subgridType.toLowerCase()}?isactive=false`);
            setTemplates(response?.data || []);
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (error) {
            // Handle error silently or show notification if needed
        }
    };

    const fetchPreviewRecords = async () => {

        if (isReadOnly) {
            setPreviewRecords([]);
            setSelectedRecord(null);
            setHtmlPreviewData('');
            return;
        }

        setPreviewRecords(null);
        setSelectedRecord(null);
        setHtmlPreviewData('');

        try {
            const response = await apiService.get<{ data: PreviewRecord[] }>(
                `/templatepreviewpersonalization/${subgridType.toLowerCase()}/${masgid}`
            );
            setPreviewRecords(response.data);
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (error) {
            api.open({
                message: 'Failed to Load Records',
                description: 'Unable to fetch preview records. Please try again.',
                type: 'error',
                duration: 2,
            });
        }
    };

    useEffect(() => {
        if (current === 1 && !isReadOnly) {
            fetchTemplates();
            if (subgridType !== 'none') {
                fetchPreviewRecords();
            }
        }
    }, [current, subgridType, isReadOnly]);



    const handleImportData = async (selectedRows: Record<string, any>[], isRightGrid: boolean = false) => {

        if (isReadOnly) {
            api.open({
                message: "Cannot Import Records",
                description: "Importing records is disabled when status is Scheduled.",
                type: "warning",
                duration: 2,
            });
            return;
        }
        try {
            api.open({
                message: 'Importing Records',
                description: 'Please wait while we import the records...',
                duration: 0,
                key: 'importLoading',
            });

            if (isRightGrid) {
                setRightGridData((prevData) => {
                    const combinedData = [...prevData, ...selectedRows];
                    return Array.from(new Map(combinedData.map(item => [item.id, item])).values());
                });

                api.destroy('importLoading');
                api.open({
                    message: 'Suppression Lists Imported',
                    description: `${selectedRows.length} records have been added to the Suppression Lists. They will be associated when you click Next.`,
                    type: 'success',
                    duration: 4,
                });
            } else {
                setData((prevData) => {
                    const combinedData = [...prevData, ...selectedRows];
                    return Array.from(new Map(combinedData.map(item => [item.id, item])).values());
                });

                setNewlyImportedRecords(selectedRows);
                api.destroy('importLoading');

                api.open({
                    message: `${subgridType} Imported`,
                    description: `${selectedRows.length} ${subgridType.toLowerCase()} have been added to the campaign. They will be associated when you click Next.`,
                    type: 'success',
                    duration: 4,
                });
            }
        } catch (error: unknown) {
            api.destroy('importLoading');
            api.open({
                message: 'Import Failed',
                description: error instanceof Error ? error.message : 'Failed to import records. Please try again.',
                type: 'error',
                duration: 2,
            });
        }
    };

    const changeTemplate = async (selectedId: string) => {
        if (isReadOnly) {
            api.open({
                message: 'Cannot Change Template',
                description: 'Template changes are disabled when the campaign is Scheduled or Sent.',
                type: 'warning',
                duration: 2,
            })
        }
        setSelectedTemplate(selectedId);
        setLoading(true);

        try {
            const response = await apiService.get<{ data: any }>(`/messagetemplate/${selectedId}`);
            const data = response.data;

            if (!data) {
                throw new Error('No template data received');
            }

            const updatedDetails = {
                id: selectedId,
                messageType: 'Email',
                emailSubject: data.emailsubject || '',
                // fromUser: data?.fromuser || { id: '', name: '' },
                // fromName: data?.fromname || '',
                // fromEmail: data.fromemail || '',
                emailBody: data.emailbody || '',
            };

            setTemplateDetails(updatedDetails);
            // setMessageSetup({
            //     fromName: data?.fromname || data?.fromuser?.name || '',
            //     fromEmail: data?.fromuser?.email || data.fromemail || ''
            // });
            setEmailBody(data.emailbody || '');
            setEditedEmailBody(data.emailbody || '');
            setHtmlPreviewData(data.emailbody || '');
            setIsEditing(false);

            if (id || masgid) {
                localStorage.setItem(
                    `campaign_${id || masgid}_original_template`,
                    JSON.stringify({
                        templateId: selectedId,
                        emailBody: data.emailbody,
                    })
                );

                localStorage.removeItem(`campaign_${id || masgid}_email_body`);
            }

            form.setFieldsValue({
                Template: data.emailtemplatename,
                type: 'Email',
                subject: data.emailsubject,
                // user: data?.fromuser?.name || '',
                //name: data?.fromname || data?.fromuser?.name || '',
                // email: data?.fromuser?.email || data.fromemail || '',
            });

            if (id && messageSetup.fromEmail && messageSetup.fromName) {
                const payload = {
                    id: id,
                    msgsetupmessagestatus: 1,
                    messagetemplateid: selectedId,
                    // msgsetupmessagingplatform: 'b402baab-9058-ef11-bfe3-000d3a3deaa8',
                    msgsetupfromemail: messageSetup.fromEmail,
                    msgsetupfromname: messageSetup.fromName,
                    msgsetupsubject: data.emailsubject,
                    // systemuserid: data?.fromuser?.id,
                    currentstage: 2,
                    //primaryentity: subgridType === 'Contact' ? 1 : subgridType === 'Account' ? 3 : 2,
                    emailbody: data.emailbody,
                    msgsetupname: campaignName,
                };



                await apiService.post('/messagesetup', payload);
            }


            setKey(prev => prev + 1);
        } catch (error: any) {
            api.open({
                message: 'Error Loading Template',
                description: error.message || 'Failed to load template details. Please try again.',
                type: 'error',
            });
        } finally {
            setLoading(false);
        }
    };

    const onSelectChange = (
        newSelectedRowKeys: React.Key[] = [],
        newSelectedRows: Record<string, any>[] = []
    ) => {
        setSelectedRowKeys(newSelectedRowKeys);
        setSelectedRows(newSelectedRows);
    };

    const onRightSelectChange = (
        newSelectedRowKeys: React.Key[] = [],
        newSelectedRows: Record<string, any>[] = []
    ) => {
        setRightSelectedRowKeys(newSelectedRowKeys);
        setRightSelectedRows(newSelectedRows);
    };

    const handleDelete = async (isRightGrid: boolean = false): Promise<void> => {
        const selectedKeys = isRightGrid ? rightSelectedRowKeys : selectedRowKeys;
        const selectedData = isRightGrid ? rightSelectedRows : selectedRows;
        if (isReadOnly) {
            api.open({
                message: 'Cannot Delete Records',
                description: 'Deleting records is disabled when the campaign is Scheduled or Sent.',
                type: 'warning',
                duration: 2,
            });
            return;
        }

        if (selectedKeys.length === 0) {
            api.open({
                message: 'No Records Selected',
                description: 'Please select records to delete.',
                type: 'warning',
                duration: 2
            });
            return;
        }

        setIsDeleting(true);
        try {
            if (isRightGrid) {
                setRightGridData((prevData) => prevData.filter((item) => !selectedKeys.includes(item.id)));
                setRightSelectedRowKeys([]);
                setRightSelectedRows([]);
            } else {
                setData((prevData) => prevData.filter((item) => !selectedKeys.includes(item.id)));
                setSelectedRowKeys([]);
                setSelectedRows([]);
            }

            api.open({
                message: `${subgridType.toLowerCase()} Removed`,
                description: `Selected ${subgridType.toLowerCase()} have been removed from the ${isRightGrid ? 'right' : 'left'} grid.`,
                type: 'success',
                duration: 2
            });
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (error: unknown) {
            if (isRightGrid) {
                setRightGridData((prevData) => [...prevData, ...selectedData]);
                setRightSelectedRowKeys(selectedKeys);
                setRightSelectedRows(selectedData);
            } else {
                setData((prevData) => [...prevData, ...selectedData]);
                setSelectedRowKeys(selectedKeys);
                setSelectedRows(selectedData);
            }

            api.open({
                message: 'Removal Failed',
                description: error instanceof Error ? error.message : 'Failed to remove records. Please try again.',
                type: 'error',
                duration: 2
            });
        } finally {
            setTimeout(() => {
                setIsDeleting(false);
            }, 500);
        }
    };

    const handleSubgridType = (e: string) => {
        if (isReadOnly) {
            api.open({
                message: "Cannot Change Audience Type",
                description: "Audience type cannot be changed when status is Scheduled.",
                type: "warning",
                duration: 2,
            });
            return;
        }
        if (id && subgridType !== 'none') {
            return;
        }
        if (e !== subgridType) {
            setSubgridType(e);
            setData([]);
            setSelectedRowKeys([]);
            setSelectedRows([]);
        }
    };

    const handleNavigationWithUnsavedChanges = (newStep: number) => {
        setIsNavigating(true);
        if (current === 1) {
            const originalTemplateData = localStorage.getItem(`campaign_${id}_original_template`);
            const originalData = originalTemplateData ? JSON.parse(originalTemplateData) : null;
            const hasChanges = editedEmailBody &&
                (editedEmailBody !== templateDetails.emailBody ||
                    (originalData && editedEmailBody !== originalData.emailBody));

            if (hasChanges) {
                Modal.confirm({
                    title: 'Warning: Unsaved Changes',
                    content: 'You have made changes to the email template. Navigating away will discard these changes. Do you want to continue?',
                    okText: 'Yes, Continue',
                    cancelText: 'No, Stay Here',
                    onOk: () => {
                        setCurrent(newStep);
                        setHasUnsavedChanges(false);
                        setEditedEmailBody(templateDetails.emailBody);
                        setIsEditing(false);
                        setIsNavigating(false);
                    },
                    onCancel: () => {
                        setIsNavigating(false);
                    }
                });
                return;
            }
        }

        if (current === 2 && hasUnsavedChanges) {
            Modal.confirm({
                title: 'Unsaved Changes',
                content: 'You have unsaved changes in the schedule. Are you sure you want to go back?',
                okText: 'Yes, Go Back',
                cancelText: 'No, Stay Here',
                onOk: () => {
                    setCurrent(newStep);
                    setHasUnsavedChanges(false);
                    setScheduleType('0');
                    setDeliveryDate('');
                    form.setFieldsValue({
                        scheduleType: '0',
                        deliveryDate: null,
                    });
                    setIsNavigating(false);
                },
                onCancel: () => {
                    setIsNavigating(false);
                }
            });
        } else if (hasUnsavedChanges) {
            Modal.confirm({
                title: 'Unsaved Changes',
                content: 'You have unsaved changes. Are you sure you want to go back?',
                okText: 'Yes, Go Back',
                cancelText: 'No, Stay Here',
                onOk: () => {
                    setCurrent(newStep);
                    setHasUnsavedChanges(false);
                    setIsNavigating(false);
                },
                onCancel: () => {
                    setIsNavigating(false);
                }
            });
        } else {
            setCurrent(newStep);
            setIsNavigating(false);
        }
    };


    const handleScheduleTypeChange = (e: any) => {
        setScheduleType(e.target.value);
        setHasUnsavedChanges(true);
        if (e.target.value === '0') {
            setDeliveryDate('');
            form.setFieldsValue({ deliveryDate: null });
        }
    };

    const handleDeliveryDateChange = (value: any) => {
        setDeliveryDate(value ? value.format() : '');
        setHasUnsavedChanges(true);
    };

    const handleNext = async () => {
        setIsNavigating(true);
        if (isReadOnly) {
            try {
                if (current === 0) {
                    // Validate campaign name
                    let currentName = isEditingName ? editedCampaignName : campaignName;
                    if (!currentName.trim()) {
                        api.open({
                            message: 'Campaign Name Required',
                            description: 'Please enter a name for your campaign.',
                            type: 'warning',
                            duration: 2,
                        });
                        setIsNavigating(false);
                        return;
                    }

                    // Validate audience type
                    if (subgridType === 'none') {
                        api.open({
                            message: 'Please select at least one Audience Type',
                            type: 'warning',
                            duration: 2,
                        });
                        setIsNavigating(false);
                        return;
                    }

                    // Validate audience data
                    if (data.length === 0) {
                        api.open({
                            message: 'No Audience Selected',
                            description: `Please import at least one ${subgridType.toLowerCase()} before proceeding.`,
                            type: 'warning',
                            duration: 2,
                        });
                        setIsNavigating(false);
                        return;
                    }

                    // Proceed to next step without API calls
                    setCurrent((prev) => Math.min(prev + 1, steps.length - 1));
                    setIsNavigating(false);
                    // api.open({
                    //     message: 'Read-Only Mode',
                    //     description: 'This campaign is Scheduled. You can view the next step but cannot make changes.',
                    //     type: 'info',
                    //     duration: 2,
                    // });
                } else if (current === 1) {
                    // Validate campaign name
                    let currentName = isEditingName ? editedCampaignName : campaignName;
                    if (!currentName.trim()) {
                        api.open({
                            message: 'Campaign Name Required',
                            description: 'Please enter a name for your campaign.',
                            type: 'warning',
                            duration: 2,
                        });
                        setIsNavigating(false);
                        return;
                    }

                    // Validate template selection
                    if (!selectedTemplate) {
                        api.open({
                            message: 'Please select a template first.',
                            type: 'warning',
                            duration: 2,
                        });
                        setIsNavigating(false);
                        return;
                    }

                    // Proceed to next step without API calls
                    setCurrent((prev) => Math.min(prev + 1, steps.length - 1));
                    setIsNavigating(false);
                    // api.open({
                    //     message: 'Read-Only Mode',
                    //     description: 'This campaign is Scheduled. You can view the next step but cannot make changes.',
                    //     type: 'info',
                    //     duration: 2,
                    // });
                } else if (current === 2) {
                    // Stay on the current step for Scheduled campaigns
                    // api.open({
                    //     message: 'Read-Only Mode',
                    //     description: 'This campaign is Scheduled. Use the "Back to Home Page" button to return to the campaigns list.',
                    //     type: 'info',
                    //     duration: 2,
                    // });
                    setIsNavigating(false);
                }
            } catch (error) {
                api.open({
                    message: 'Operation Failed',
                    description: error instanceof Error ? error.message : 'An error occurred. Please try again.',
                    type: 'error',
                    duration: 2,
                });
                setIsNavigating(false);
            }
            return;
        }

        // For non-Scheduled campaigns, proceed with normal logic
        try {
            if (current === 0) {
                let currentName = isEditingName ? editedCampaignName : campaignName;

                if (isEditingName) {
                    // Save the campaign name and wait for it to complete
                    const savedSuccessfully = await handleSaveCampaignName();
                    if (!savedSuccessfully) {
                        setIsNavigating(false);
                        return; // Stop navigation if save failed
                    }
                    // After saving, use the updated campaignName
                    currentName = campaignName;
                }

                // Validate campaign name
                if (!currentName.trim()) {
                    api.open({
                        message: 'Campaign Name Required',
                        description: 'Please enter a name for your campaign.',
                        type: 'warning',
                        duration: 2,
                    });
                    setIsNavigating(false);
                    return;
                }

                // Validate inputs
                if (subgridType === 'none') {
                    api.open({
                        message: 'Please select at least one Audience Type',
                        type: 'warning',
                        duration: 2,
                    });
                    setIsNavigating(false);
                    return;
                }
                if (data.length === 0) {
                    api.open({
                        message: 'No Audience Selected',
                        description: `Please import at least one ${subgridType.toLowerCase()} before proceeding.`,
                        type: 'warning',
                        duration: 2,
                    });
                    setIsNavigating(false);
                    return;
                }

                setLoading(true);
                const primaryentity = {
                    Contact: 1,
                    Account: 3,
                    Lead: 2,
                }[subgridType];

                const payload = {
                    id: null,
                    msgsetupname: campaignName,
                    msgsetupmessagestatus: 1,
                    currentstage: 1,
                    primaryentity,
                };

                try {
                    let recordIdToUse = id;
                    let newRecords = [];
                    let removedRecords = [];
                    let newLists = [];
                    let removedLists = [];

                    if (!id) {
                        // New campaign
                        const response = await apiService.post<{ data: string }>(
                            '/messagesetup',
                            payload,
                            {
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                            }
                        );
                        recordIdToUse = response.data;

                        if (!recordIdToUse) {
                            throw new Error('No recordId received from API');
                        }

                        setMsgid(recordIdToUse);
                        newRecords = [...data]; // All data records are new
                        newLists = [...rightGridData]; // All lists are new
                    } else {
                        // Existing campaign
                        const existingResponse = await apiService.get<any>(`/messagesetup/${id}`);
                        const existingRecords = existingResponse.data[subgridType.toLowerCase() + 's'] || [];
                        const existingLists = existingResponse.data.lists || [];

                        // Calculate new and removed records
                        newRecords = data.filter(
                            (newRecord) =>
                                !existingRecords.some((existingRecord: { id: string }) => existingRecord.id === newRecord.id)
                        );
                        removedRecords = existingRecords.filter(
                            (existingRecord: { id: string }) =>
                                !data.some((newRecord) => newRecord.id === existingRecord.id)
                        );

                        // Calculate new and removed lists
                        newLists = rightGridData.filter(
                            (newList) =>
                                !existingLists.some((existingList: { id: string }) => existingList.id === newList.id)
                        );
                        removedLists = existingLists.filter(
                            (existingList: { id: string }) =>
                                !rightGridData.some((newList) => newList.id === existingList.id)
                        );
                    }

                    // Only call APIs and show notifications if there are changes
                    if (newRecords.length > 0 || removedRecords.length > 0 || newLists.length > 0 || removedLists.length > 0) {
                        api.open({
                            message: `Processing ${subgridType.toLowerCase()} and Suppression Lists`,
                            description: `Please wait while we process ${newRecords.length} ${subgridType.toLowerCase()}s added, ${removedRecords.length} ${subgridType.toLowerCase()}s removed, ${newLists.length} Suppression Lists added, ${removedLists.length} Suppression Lists removed...`,
                            duration: 0,
                            key: 'processingRecords',
                        });

                        // Handle record deassociation
                        if (removedRecords.length > 0) {
                            const deAssociationPayload = removedRecords.map((member: { id: string }) => ({
                                associaterecordEntityName: subgridType.toLowerCase(),
                                primaryId: recordIdToUse,
                                associaterecordid: member.id,
                            }));
                            await apiService.post('/deassociatemessagesetup', deAssociationPayload, {
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                            });
                        }

                        // Handle record association
                        if (newRecords.length > 0) {
                            const associationPayload = newRecords.map((member) => ({
                                associaterecordEntityName: subgridType.toLowerCase(),
                                primaryId: recordIdToUse,
                                associaterecordid: member.id,
                            }));
                            await apiService.post('/associatemessagesetup', associationPayload, {
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                            });
                        }

                        // Handle list deassociation
                        if (removedLists.length > 0) {
                            const listDeAssociationPayload = removedLists.map((member: { id: string }) => ({
                                associaterecordEntityName: 'list',
                                primaryId: recordIdToUse,
                                associaterecordid: member.id,
                            }));
                            await apiService.post('/deassociatemessagesetup', listDeAssociationPayload, {
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                            });
                        }

                        // Handle list association
                        if (newLists.length > 0) {
                            const listAssociationPayload = newLists.map((member) => ({
                                associaterecordEntityName: 'list',
                                primaryId: recordIdToUse,
                                associaterecordid: member.id,
                            }));
                            await apiService.post('/associatemessagesetup', listAssociationPayload, {
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                            });
                        }

                        // Close loading notification
                        api.destroy('processingRecords');

                        // Show success notification
                        api.open({
                            message: `${subgridType} and Suppression Lists Updated`,
                            description: `Campaign successfully updated. ${newRecords.length} new ${subgridType.toLowerCase()} added, ${removedRecords.length} ${subgridType.toLowerCase()} removed, ${newLists.length} Suppression Lists added, ${removedLists.length} Suppression Lists removed.`,
                            type: 'success',
                            duration: 2,
                        });
                    }

                    // Clear newly imported records and proceed
                    setNewlyImportedRecords([]);
                    navigate(`/campaigns/${recordIdToUse}`, { replace: false });
                    setCurrent((prev) => Math.min(prev + 1, steps.length - 1));
                } catch (error) {
                    api.destroy('processingRecords');
                    api.open({
                        message: 'Operation Failed',
                        description: error instanceof Error ? error.message : 'An error occurred while updating records. Please try again.',
                        type: 'error',
                        duration: 2,
                    });
                } finally {
                    setLoading(false);
                }
            } else if (current === 1) {
                let currentName = isEditingName ? editedCampaignName : campaignName;

                if (isEditingName) {
                    // Save the campaign name and wait for it to complete
                    const savedSuccessfully = await handleSaveCampaignName();
                    if (!savedSuccessfully) {
                        setIsNavigating(false);
                        return; // Stop navigation if save failed
                    }
                    // After saving, use the updated campaignName
                    currentName = campaignName;
                }
                // Ensure campaignName is not empty before proceeding
                if (!campaignName || !campaignName.trim()) {
                    api.open({
                        message: 'Campaign Name Required',
                        description: 'Please enter a name for your campaign.',
                        type: 'warning',
                        duration: 2,
                    });
                    setIsNavigating(false);
                    return;
                }
                try {
                    await form.validateFields();
                    if (!selectedTemplate) {
                        api.open({
                            message: 'Please select a template first.',
                            type: 'warning',
                            duration: 2,
                        });
                        setIsNavigating(false);
                        return;
                    }

                    if (masgid) {
                        const formValues = form.getFieldsValue();
                        const payload = {
                            id: masgid,
                            msgsetupname: campaignName,
                            msgsetupmessagestatus: 1,
                            messagetemplateid: selectedTemplate,
                            msgsetupfromemail: messageSetup.fromEmail,
                            msgsetupfromname: messageSetup.fromName,
                            msgsetupsubject: formValues.subject,
                            currentstage: 2,
                            emailbody: emailBody,
                        };

                        await apiService.post('/messagesetup', payload, {
                            headers: {
                                'Content-Type': 'application/json',
                            },
                        });

                        setMessageSetup({
                            fromName: formValues.name,
                            fromEmail: formValues.email,
                        });
                        setTemplateDetails((prev) => ({ ...prev, emailBody: editedEmailBody }));
                        setEmailBody(editedEmailBody);
                        setIsEditing(false);
                        setCurrent((prev) => Math.min(prev + 1, steps.length - 1));
                    }
                } catch (error: any) {
                    api.open({
                        message: 'Validation Failed',
                        description: error.message || 'Please fill in all required fields.',
                        type: 'error',
                        duration: 2,
                    });
                    setIsNavigating(false);
                }
            } else if (current === 2) {
                let currentName = isEditingName ? editedCampaignName : campaignName;

                if (isEditingName) {
                    const savedSuccessfully = await handleSaveCampaignName();
                    if (!savedSuccessfully) {
                        setIsSubmitting(false);
                        setIsNavigating(false);
                        return;
                    }
                    currentName = campaignName;
                }
                // Ensure campaignName is not empty before proceeding
                if (!campaignName || !campaignName.trim()) {
                    api.open({
                        message: 'Campaign Name Required',
                        description: 'Please enter a name for your campaign.',
                        type: 'warning',
                        duration: 2,
                    });
                    setIsSubmitting(false);
                    setIsNavigating(false);
                    return;
                }
                try {
                    let mesgstatus: number = 1;
                    await form.validateFields();
                    if (scheduleType === '0') {
                        mesgstatus = 2;
                    } else if (scheduleType === '1') {
                        mesgstatus = 4;
                    }
                    const payload: MessageSetupPayload = {
                        id: masgid,
                        msgsetupname: campaignName,
                        msgsetupmessagestatus: mesgstatus,
                        currentstage: 3,
                    };

                    if (scheduleType === '1' && !deliveryDate) {
                        api.open({
                            message: 'Please select a delivery date',
                            type: 'warning',
                            duration: 2,
                        });
                        setIsSubmitting(false);
                        setIsNavigating(false);
                        return;
                    }

                    if (scheduleType === '0') {
                        payload.msgsetupsendnow = true;
                        payload.msgsetupsenddatetime = null;
                    } else if (scheduleType === '1') {
                        if (!deliveryDate) {
                            api.open({
                                message: 'Please select a delivery date',
                                type: 'warning',
                                duration: 2,
                            });
                            setIsSubmitting(false);
                            return;
                        }
                        payload.msgsetupsendnow = false;
                        payload.msgsetupsenddatetime = dayjs(deliveryDate).format('YYYY-MM-DD HH:mm:ss');
                    }

                    await apiService.post('/messagesetup', payload, {
                        headers: {
                            'Content-Type': 'application/json',
                        },
                    });

                    setHasUnsavedChanges(false);
                    api.open({
                        message: 'Campaign Created',
                        description:
                            scheduleType === '0'
                                ? 'Your campaign has been created and will be sent to your audience immediately!'
                                : `Your campaign has been scheduled to be sent to your audience on ${dayjs(
                                    deliveryDate
                                ).format('MMMM D, YYYY [at] h:mm A')} UTC.`,
                        type: 'success',
                        duration: 3,
                        onClose: () => navigate('/campaigns'),
                    });
                } catch (error) {
                    api.open({
                        message: 'Validation Failed',
                        description: error instanceof Error ? error.message : 'Please fill in all required fields.',
                        type: 'error',
                        duration: 2,
                    });
                    setIsSubmitting(false);
                    setIsNavigating(false);
                }
            }
        } catch (error) {
            api.open({
                message: 'Operation Failed',
                description: error instanceof Error ? error.message : 'An error occurred. Please try again.',
                type: 'error',
                duration: 2,
            });
            setIsSubmitting(false);
            setIsNavigating(false);
        }
    };
    const handleSaveEdit = async () => {
        if (isReadOnly) {
            api.open({
                message: 'Cannot Save Changes',
                description: 'Editing is disabled when the campaign is Scheduled or Sent.',
                type: 'warning',
                duration: 2,
            });
            return;
        }
        try {
            // Update both template details and email body
            setTemplateDetails(prev => ({ ...prev, emailBody: editedEmailBody }));
            setEmailBody(editedEmailBody);
            setHtmlPreviewData(editedEmailBody);
            setIsEditing(false);
            setHasUnsavedChanges(false);

            // Store the edited content in localStorage
            if (id || masgid) {
                localStorage.setItem(`campaign_${id || masgid}_email_body`, editedEmailBody);
            }

            api.open({
                message: 'Template Updated',
                description: 'The email template has been successfully updated.',
                type: 'success',
            });
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (error) {
            api.open({
                message: 'Save Failed',
                description: 'Failed to save the template. Please try again.',
                type: 'error',
            });
        }
    };

    // Add this useEffect to load saved email body on component mount
    useEffect(() => {
        if (id || masgid) {
            const savedEmailBody = localStorage.getItem(`campaign_${id || masgid}_email_body`);
            if (savedEmailBody) {
                setEditedEmailBody(savedEmailBody);
                setEmailBody(savedEmailBody);
                setTemplateDetails(prev => ({ ...prev, emailBody: savedEmailBody }));
            }
        }
    }, [id, masgid]);

    // Add this useEffect to clear saved email body when component unmounts
    useEffect(() => {
        return () => {
            if (id || masgid) {
                localStorage.removeItem(`campaign_${id || masgid}_email_body`);
            }
        };
    }, [id, masgid]);

    // Add useEffect to track form changes
    useEffect(() => {
        if (current === 1) {
            const originalTemplateData = localStorage.getItem(`campaign_${id}_original_template`);
            const originalData = originalTemplateData ? JSON.parse(originalTemplateData) : null;

            const hasFormChanges = () => {
                const formValues = form.getFieldsValue();
                const hasTemplateChanges = editedEmailBody !== (originalData?.emailBody || templateDetails.emailBody);
                const hasFieldChanges =
                    formValues.subject !== templateDetails.emailSubject ||
                    formValues.name !== messageSetup.fromName ||
                    formValues.email !== messageSetup.fromEmail ||
                    formValues.type !== templateDetails.messageType;

                return hasTemplateChanges || hasFieldChanges;
            };

            // Set initial form values
            form.setFieldsValue({
                subject: templateDetails.emailSubject,
                name: messageSetup.fromName,
                email: messageSetup.fromEmail,
                type: templateDetails.messageType
            });

            // Check for changes initially
            setHasUnsavedChanges(hasFormChanges());
        }
    }, [current, form, editedEmailBody, templateDetails, id, messageSetup]);

    // Add form change handler
    const handleFormChange = (changedValues: any, allValues: any) => {
        if (current === 1) {
            const originalTemplateData = localStorage.getItem(`campaign_${id}_original_template`);
            const originalData = originalTemplateData ? JSON.parse(originalTemplateData) : null;
            const hasTemplateChanges = editedEmailBody !== (originalData?.emailBody || templateDetails.emailBody);
            const hasFieldChanges =
                allValues.subject !== templateDetails.emailSubject ||
                allValues.name !== messageSetup.fromName ||
                allValues.email !== messageSetup.fromEmail ||
                allValues.type !== templateDetails.messageType;

            // If any field has changed, set hasUnsavedChanges to true
            if (hasTemplateChanges || hasFieldChanges) {
                setHasUnsavedChanges(true);
            }
        }
    };

    const handleClosePreview = () => {
        setSelectedRecord(null);
        setHtmlPreviewData('');
        setOpenPreview(false);
    };

    const handlePreviewButton = () => {
        if (!selectedTemplate) {
            api.open({
                message: 'Please select a template first.',
                type: 'warning',
                duration: 2,
            });
            return;
        }
        setSelectedRecord(null);
        setHtmlPreviewData(editedEmailBody || templateDetails.emailBody);
        form.setFieldsValue({ record: '' });
        fetchPreviewRecords();
        setOpenPreview(true);
    };

    // const handlePreviewDropdownChange = async (selectedRecord: string) => {
    //     setSelectedRecord(selectedRecord);
    //     setLoading(true);

    //     if (!selectedRecord || selectedRecord === '') {
    //         setHtmlPreviewData('');
    //         api.open({
    //             message: 'Please choose a record to preview the template',
    //             type: 'warning',
    //             duration: 2,
    //         });
    //         setLoading(false);
    //         return;
    //     }

    //     try {
    //         const currentEmailBody = isEditing ? editedEmailBody : emailBody;

    //         const payload = {
    //             TemplateID: selectedTemplate,
    //             WhoID: selectedRecord,
    //             WhatID: '2bffa321-0644-ef11-a316-0022486e92a5',
    //             EmailBody: currentEmailBody,
    //         };

    //         const response = await apiService.post<{ data: string }>(
    //             '/replacemergefields',
    //             payload
    //         );

    //         const htmlData = response.data;
    //         if (!htmlData) {
    //             throw new Error('No preview data received');
    //         }

    //         setHtmlPreviewData(htmlData);
    //     } catch (error: any) {
    //         setHtmlPreviewData('');
    //         api.open({
    //             message: 'Preview Failed',
    //             description: error.message || 'Failed to load preview data. Please try again.',
    //             type: 'error',
    //             duration: 2,
    //         });
    //     } finally {
    //         setLoading(false);
    //     }
    // };/
    const handlePreviewDropdownChange = async (selectedRecord: string) => {

        setSelectedRecord(selectedRecord);
        if (!selectedRecord || selectedRecord === '') {
            setHtmlPreviewData('');
            api.open({
                message: 'Please choose a record to preview the template',
                type: 'warning',
                duration: 2,
            });
            return;
        }
        setLoading(true);

        const headersList = {
            Accept: '*/*',
            'User-Agent': 'Thunder Client (https://www.thunderclient.com)',
            'Content-Type': 'application/json',
        };

        const currentEmailBody = isEditing ? editedEmailBody : emailBody;

        const bodyContent = JSON.stringify({
            TemplateID: `${selectedTemplate}`,
            WhoID: `${selectedRecord}`,
            WhatID: '2bffa321-0644-ef11-a316-0022486e92a5',
            EmailBody: currentEmailBody
        });

        try {
            const response = await fetch(
                'https://emailboost.azurewebsites.net/api/replacemergefields',
                {
                    method: 'POST',
                    body: bodyContent,
                    headers: headersList,
                }
            );

            const data = await response.text();
            setHtmlPreviewData(data);
        } catch {
            setHtmlPreviewData('');
            api.open({
                message: 'Preview Failed',
                description: 'Failed to load preview data. Please try again.',
                type: 'error',
                duration: 2
            });
        } finally {
            setLoading(false);
        }
    };



    // const handleMarketingListChange = async (e: any) => {
    //     const selectedId = e;
    //     setSelectedTemplate(selectedId);
    //     setLoading(true);

    //     try {
    //         const response = await apiService.get<{ data: any }>(`/messagetemplate/${selectedId}`);
    //         const data = response.data;

    //         if (!data) {
    //             throw new Error('No template data received');
    //         }

    //         // const updatedDetails = {
    //         //     messageType: data.messagetype || '',
    //         //     emailSubject: data.emailsubject || '',
    //         //     fromUser: data?.fromuser || { id: '', name: '' },
    //         //     fromName: data?.fromname || '',
    //         //     fromEmail: data.fromemail || '',
    //         //     emailBody: data.emailbody || '',
    //         // };
    //         const updatedDetails: {
    //             id: string;
    //             messageType: string;
    //             emailSubject: string;
    //             emailBody: string;
    //         } = {
    //             id: data.id || selectedId, // Use the template ID from the response or fallback to selectedId
    //             messageType: data.messagetype || '',
    //             emailSubject: data.emailsubject || '',
    //             emailBody: data.emailbody || '',
    //         };

    //         setTemplateDetails(updatedDetails);
    //         setEmailBody(data.emailbody || '');
    //         setEditedEmailBody(data.emailbody || '');
    //         setIsEditing(false);

    //         // Update messageSetup state for fromName and fromEmail
    //         // setMessageSetup({
    //         //     fromName: data.fromname || data?.fromuser?.name || '',
    //         //     fromEmail: data.fromemail || '',
    //         // });

    //         form.setFieldsValue({
    //             Template: data.emailtemplatename,
    //             type: data.messagetype,
    //             subject: data.emailsubject,
    //             user: data?.fromuser?.name || '',
    //             name: data?.fromname,
    //             email: data.fromemail,
    //         });

    //         // if (id) {
    //         //     const payload = {
    //         //         id: id,
    //         //         msgsetupmessagestatus: 1,
    //         //         messagetemplateid: selectedId,
    //         //         msgsetupmessagingplatform: 'b402baab-9058-ef11-bfe3-000d3a3deaa8',
    //         //         msgsetupfromemail: data.fromemail,
    //         //         msgsetupfromname: data.fromname || data?.fromuser?.name,
    //         //         msgsetupsubject: data.emailsubject,
    //         //         systemuserid: data?.fromuser?.id,
    //         //         currentstage: 1,
    //         //         primaryentity: subgridType === 'Contact' ? 1 : subgridType === 'Account' ? 3 : 2,
    //         //         emailbody: data.emailbody,
    //         //     };


    //         // }
    //         // eslint-disable-next-line @typescript-eslint/no-unused-vars
    //     } catch (error) {
    //         api.open({
    //             message: 'Error Loading Template',
    //             description: 'Failed to load template details. Please try again.',
    //             type: 'error',
    //         });
    //     } finally {
    //         setLoading(false);
    //     }
    // };

    const handleMarketingListChange = async (e: any) => {
        if (isReadOnly) {
            api.open({
                message: 'Cannot Change Template',
                description: 'Template changes are disabled when the campaign is Scheduled or Sent.',
                type: 'warning',
                duration: 2,
            });
            return;
        }
        const selectedId = e;
        const previousTemplateId = selectedTemplate;

        // Get original template data
        const originalTemplateData = localStorage.getItem(`campaign_${id}_original_template`);
        const originalData = originalTemplateData ? JSON.parse(originalTemplateData) : null;

        // Check if there are unsaved changes
        const hasChanges = editedEmailBody &&
            (editedEmailBody !== templateDetails.emailBody ||
                (originalData && editedEmailBody !== originalData.emailBody));

        // Get form values to check for field changes
        const formValues = form.getFieldsValue();
        const hasFieldChanges =
            formValues.subject !== templateDetails.emailSubject ||
            formValues.name !== messageSetup.fromName ||
            formValues.email !== messageSetup.fromEmail ||
            formValues.type !== templateDetails.messageType;

        // Only show warning if there are actual changes
        if (hasChanges || hasFieldChanges) {
            Modal.confirm({
                title: 'Warning: Unsaved Changes',
                content: 'You have made changes to the email template. Changing templates will discard these changes. Do you want to continue?',
                okText: 'Yes, Change Template',
                cancelText: 'No, Keep Changes',
                onOk: async () => {
                    await changeTemplate(selectedId);
                    setHasUnsavedChanges(false);
                    // Reset edited email body to match new template
                    setEditedEmailBody('');
                    setIsEditing(false);
                },
                onCancel: () => {
                    // Reset the select to previous value
                    setSelectedTemplate(previousTemplateId);
                    // Force form to update with previous template name
                    const previousTemplate = templates.find(t => t.id === previousTemplateId);
                    if (previousTemplate) {
                        form.setFieldsValue({
                            Template: previousTemplate.emailtemplatename
                        });
                    }
                }
            });
        } else {
            await changeTemplate(selectedId);
            setHasUnsavedChanges(false);
            // Reset edited email body to match new template
            setEditedEmailBody('');
            setIsEditing(false);
        }
    };

    return (
        <Flex vertical style={{ height: "100%" }}>
            {isReadOnly && (
                <div
                    style={{
                        padding: '0.5rem',
                        background: '#e6f7ff',
                        border: '1px solid #91d5ff',
                        color: '#0050b3',
                        margin: '0.5rem',
                        borderRadius: '4px',
                        fontSize: '14px',
                        textAlign: 'left',
                        zIndex: '3',
                    }}
                >
                    This campaign is in read-only mode because it is scheduled. Editing is disabled.
                </div>
            )}
            <div
                className="menubar"
                style={{
                    borderBottom: "1px solid #dde4e9",
                    padding: "0.4rem",
                    background: "white",
                    position: "sticky",
                    top: "48px",
                    zIndex: "2",
                }}
            >
                <Flex gap={'0.2rem'} align="center">
                    <Link to="/campaigns">
                        <Button color="default" variant="link" size="middle">
                            <ArrowLeft size={16} />
                        </Button>
                    </Link>
                    <div style={{ marginLeft: '8px' }}>
                        {isEditingName ? (
                            <Input
                                ref={inputRef}
                                value={editedCampaignName}
                                onChange={(e) => setEditedCampaignName(e.target.value)}
                                onBlur={handleNameBlur}
                                onKeyDown={handleNameKeyDown}
                                className="campaign-name-input"
                                disabled={isSavingName}
                                placeholder="Enter campaign name (e.g., Q2 Marketing Campaign)"
                                required
                            />
                        ) : (
                            <Typography.Title
                                level={4}
                                className="campaign-name-title"
                                style={{
                                    color: campaignName ? 'inherit' : '#bfbfbf',
                                    marginBottom: '5px',

                                }}

                                onClick={handleNameClick}
                            >
                                {campaignName || (
                                    <>
                                        Click to enter campaign name <span style={{ color: 'red' }}>*</span>
                                    </>
                                )}
                            </Typography.Title>
                        )}
                    </div>
                </Flex>
            </div>
            {contextHolder}
            <Modal
                title="Preview"
                open={openPreview}
                onCancel={handleClosePreview}
                footer={[
                    <Button key="close" type="primary" onClick={handleClosePreview}>
                        Close
                    </Button>,
                ]}
                width="60%"
                centered
                style={{ top: 20 }}
                styles={{
                    body: {
                        maxHeight: 'height: calc(-310px + 100vh);',
                        overflow: 'hidden',
                    }
                }}
            >
                <Form layout="vertical">
                    <Form.Item label="Select Record">
                        <Select
                            onChange={handlePreviewDropdownChange}
                            placeholder="Select Record"
                            value={selectedRecord}
                            dropdownStyle={{ maxHeight: 200, overflowY: 'auto' }}
                        >

                            {previewRecords && previewRecords.length > 0 ? (
                                previewRecords.map((record) => (
                                    record.entityLogicalName === "account" ? (
                                        <Option value={record.id}>
                                            {record.accountname}
                                        </Option>
                                    ) : (
                                        <Option key={record.id} value={record.id}>
                                            {record.name}
                                        </Option>
                                    )
                                ))
                            ) : (
                                <Option disabled>Select Record</Option>
                            )}
                        </Select>
                    </Form.Item>
                    <div
                        style={{
                            border: '1px solid #d9d9d9',
                            borderRadius: '4px',
                            padding: '16px',
                            height: 'calc(100vh - 300px)',
                            backgroundColor: '#fff',
                            overflow: 'auto',
                            position: 'relative'
                        }}
                    >
                        {loading ? (
                            <div
                                style={{
                                    position: 'absolute',
                                    top: '50%',
                                    left: '50%',
                                    transform: 'translate(-50%, -50%)',
                                    zIndex: 1000,
                                }}
                            ><Spin size="large" tip="Loading preview..." />
                            </div>
                        ) : (
                            <div
                                dangerouslySetInnerHTML={{
                                    __html: selectedRecord
                                        ? htmlPreviewData
                                        : editedEmailBody || templateDetails.emailBody,
                                }}
                            />

                        )}
                    </div>
                </Form>
            </Modal>
            <style>
                {`
    .error-card {
        background: #ffffff;
        border: 1px solid #e6e6e6;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        padding: 24px;
        text-align: center;
        max-width: 600px;
        margin: 0 auto;
    }
    .campaign-name-input {
        font-size: 20px;
        font-weight: 600;
        padding: 4px 8px;
        height: 32px;
        cursor: pointer;
    }
    .campaign-name-title {
        margin: 0;
        cursor: pointer;
        user-select: none;
        transition: color 0.3s ease;
    }
    .campaign-name-title:hover {
        color: #1890ff;
    }
    .error-alert {
        background: #e6f7e6;
        border: 1px solid #52c41a;
        border-radius: 6px;
        margin-bottom: 16px;
    }
    .error-alert .ant-alert-message {
        color: #1a3c1a;
        font-size: 16px;
        font-weight: 500;
    }
    .error-alert .ant-alert-description {
        color: #4a4a4a;
        font-size: 14px;
    }
    .retry-button {
        background: #1890ff;
        border: none;
        border-radius: 6px;
        color: #ffffff;
        font-weight: 500;
        padding: 8px 24px;
        transition: background 0.3s ease;
    }
    .retry-button:hover {
        background: #40a9ff;
    }
    .delete-spinner {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        zIndex: 10;
    }
    .edit-template-button {
        transition: all 0.3s ease;
        font-weight: 500;
        padding: 6px 16px;
        border-radius: 6px;
    }
    .edit-template-button:hover {
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        transform: translateY(-1px);
    }
    /* Hide GrapeJS editing controls in read-only mode */
    .gjs-pn-panel.gjs-pn-commands,
    .gjs-pn-panel.gjs-pn-devices-c,
    .gjs-pn-panel.gjs-pn-views,
    .gjs-block,
    .gjs-block-category,
    .gjs-layer,
    .gjs-sm-sector {
        display: none !important;
    }
    /* Show editing controls when not read-only */
    .gjs-editor:not(.gjs-read-only) .gjs-pn-panel.gjs-pn-commands,
    .gjs-editor:not(.gjs-read-only) .gjs-pn-panel.gjs-pn-devices-c,
    .gjs-editor:not(.gjs-read-only) .gjs-pn-panel.gjs-pn-views,
    .gjs-editor:not(.gjs-read-only) .gjs-block,
    .gjs-editor:not(.gjs-read-only) .gjs-block-category,
    .gjs-editor:not(.gjs-read-only) .gjs-layer,
    .gjs-editor:not(.gjs-read-only) .gjs-sm-sector {
        display: block !important;
    }
    /* Fallback to hide Jodit footer if showPoweredBy fails */
    .jodit-status-bar__item:last-child {
        display: none !important;
    }
    /* Remove loader */
    .gjs-loader,
    .gjs-loader-container,
    .gjs-loader-spinner,
    .gjs-loader-animation,
    .gjs-loader-wrapper,
    .gjs-loader-content,
    .gjs-loader-overlay,
    .gjs-loader-background,
    .gjs-loader-visible,
    .gjs-loader-hidden {
        display: none !important;
    }
`}
            </style>

            <Flex vertical
                style={{
                    padding: "1rem",
                    background: "white",
                    flexGrow: "1",
                }}
            >
                <Steps
                    style={{ marginBottom: '0.5rem' }}
                    current={current}
                    items={steps.map((step) => ({ key: step.title, title: step.title }))}
                />
                <StepNavigation
                    current={current}
                    next={handleNext} // Always pass handleNext, ignoring isScheduled
                    prev={() => handleNavigationWithUnsavedChanges(Math.max(current - 1, 0))} // Keep prev as is
                    isSubmitting={isSubmitting}
                    isNavigating={isNavigating}
                    isScheduled={isReadOnly}
                />
                <Divider style={{ margin: '0 0 0.5rem 0' }} />
                {current === 0 && (
                    <>
                        {loading ? (
                            <Card
                                style={{
                                    textAlign: 'center',
                                    borderRadius: '8px',
                                    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.05)',
                                    padding: '24px',
                                    margin: '20px 0'
                                }}
                            >
                                <Spin size="large" />
                            </Card>
                        ) : error ? (
                            <Card className="error-card">
                                <Alert
                                    className="error-alert"
                                    message="Error Loading Campaign"
                                    description={error}
                                    type="error"
                                    showIcon
                                />
                                <Button className="retry-button" onClick={getSetup}>
                                    Retry
                                </Button>
                            </Card>
                        ) : (
                            <>
                                <div style={{ position: 'relative' }}>
                                    {isDeleting && (
                                        <div
                                            style={{
                                                position: 'absolute',
                                                top: 0,
                                                left: 0,
                                                right: 0,
                                                bottom: 0,
                                                backgroundColor: 'rgba(255, 255, 255, 0.7)',
                                                display: 'flex',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                zIndex: 1000,
                                                borderRadius: '8px'
                                            }}
                                        >
                                            <Spin size="large" tip="Deleting records..." />
                                        </div>
                                    )}
                                    <Row gutter={16}>
                                        <Col span={12}>
                                            <SubgridSelector
                                                key="subgrid-selector-left"
                                                subgridType={subgridType}
                                                handleSubgridType={handleSubgridType} // Add this
                                                showDrawer={() => setOpen(true)} // Add this
                                                handleDelete={isReadOnly ? () => Promise.resolve() : async () => await handleDelete(false)}
                                                showRemoveButton={isReadOnly ? false : selectedRowKeys.length > 0} // Add this
                                                isExistingCampaign={!!id}
                                                showAudienceType={true}
                                                isScheduled={isReadOnly}
                                            />
                                            {subgridType === 'none' ? (
                                                <Card>
                                                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                                                </Card>
                                            ) : (
                                                <Table
                                                    key={`${subgridType}-left`}
                                                    rowSelection={
                                                        isReadOnly
                                                            ? undefined
                                                            : {
                                                                selectedRowKeys,
                                                                onChange: onSelectChange,
                                                            }
                                                    }
                                                    columns={tableColumns}
                                                    rowKey="id"
                                                    dataSource={data}
                                                    style={{ flexGrow: 1 }}
                                                    scroll={{ y: "calc(100vh - 435px)", x: "none" }}
                                                    showSorterTooltip={{ target: "sorter-icon" }}
                                                />
                                            )}
                                        </Col>
                                        <Col span={12}>
                                            <SubgridSelector
                                                key="subgrid-selector-right"
                                                subgridType={subgridType}
                                                handleSubgridType={handleSubgridType}
                                                showDrawer={isReadOnly ? () => { } : () => setOpenRight(true)}
                                                handleDelete={
                                                    isReadOnly
                                                        ? () => Promise.resolve() // No-op function returning Promise<void>
                                                        : async () => {
                                                            await handleDelete(true); // Await to ensure Promise<void> return type
                                                        }
                                                }
                                                showRemoveButton={isReadOnly ? false : rightSelectedRows.length > 0}
                                                isExistingCampaign={!!id}
                                                showAudienceType={false}
                                                isScheduled={isReadOnly}
                                            />
                                            {subgridType === 'none' ? (
                                                <Card>
                                                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                                                </Card>
                                            ) : (
                                                <Table
                                                    key={`${subgridType}-right`}
                                                    rowSelection={
                                                        isReadOnly
                                                            ? undefined
                                                            : {
                                                                selectedRowKeys: rightSelectedRowKeys,
                                                                onChange: onRightSelectChange,
                                                            }
                                                    }
                                                    columns={[
                                                        {
                                                            title: "Name",
                                                            dataIndex: "name",
                                                            key: "name",
                                                            sorter: (a, b) => (a.name || "").localeCompare(b.name || ""),
                                                            sortDirections: ["ascend", "descend"],
                                                            showSorterTooltip: true,
                                                        },
                                                    ]}
                                                    rowKey="id"
                                                    dataSource={rightGridData}
                                                    style={{ flexGrow: 1 }}
                                                    scroll={{ y: "calc(100vh - 435px)", x: "none" }}
                                                    showSorterTooltip={{ target: "sorter-icon" }}
                                                />
                                            )}
                                        </Col>
                                    </Row>
                                </div>
                                <ImportDrawer
                                    open={open}
                                    onClose={() => setOpen(false)}
                                    subgridType={subgridType}
                                    onImport={(rows) => handleImportData(rows, false)}
                                    importedRows={data}
                                />
                                <ImportDrawerRight
                                    open={openRight}
                                    onClose={() => setOpenRight(false)}
                                    subgridType={subgridType}
                                    onImport={(rows) => handleImportData(rows, true)}
                                    importedRows={rightGridData}
                                />
                            </>
                        )}
                    </>
                )}
                {current === 1 && (
                    <div>
                        <Row gutter={16}>
                            <Col span={24}>
                                <Title level={4}>Information</Title>
                                <Spin spinning={loading} tip="Loading template details...">
                                    <Form
                                        form={form}
                                        layout="vertical"
                                        onValuesChange={isReadOnly ? undefined : handleFormChange}
                                        initialValues={{
                                            subject: templateDetails.emailSubject,
                                            name: messageSetup.fromName,
                                            email: messageSetup.fromEmail,
                                            type: templateDetails.messageType
                                        }}
                                    >
                                        <Row gutter={16}>
                                            <Col span={24} sm={24} md={12} lg={8} xl={8}>
                                                <Form.Item style={{ marginBottom: '0.5rem' }}
                                                    label="Template"
                                                    name="Template"
                                                    rules={[{ required: true, message: 'Please select a Template' }]}
                                                >
                                                    <Select
                                                        showSearch
                                                        placeholder="Select an email template"
                                                        optionFilterProp="label"
                                                        style={{ width: '100%' }}
                                                        onChange={isReadOnly ? undefined : handleMarketingListChange}
                                                        value={selectedTemplate}
                                                        loading={loading}
                                                        options={templates.map((template) => ({
                                                            value: template.id,
                                                            label: template.emailtemplatename,
                                                        }))}
                                                        disabled={isReadOnly}
                                                    />
                                                </Form.Item>
                                            </Col>
                                            <Col span={24} sm={24} md={12} lg={8} xl={8}>
                                                <Form.Item style={{ marginBottom: '0.5rem' }}
                                                    label="Message Type"
                                                    name="type"
                                                    rules={[{ required: true, message: 'Please select a Message Type' }]}
                                                >
                                                    <Select
                                                        value={templateDetails.messageType}
                                                        placeholder="Message Type"
                                                        style={{ width: '100%' }}
                                                        onChange={(value) =>
                                                            setTemplateDetails({
                                                                ...templateDetails,
                                                                messageType: value,
                                                            })
                                                        }
                                                        disabled={isReadOnly} // Disable select
                                                    >
                                                        <Option value={496290000}>Email</Option>
                                                        <Option value={496290001} disabled>SMS</Option>
                                                        <Option value={496290002} disabled>WhatsApp</Option>
                                                    </Select>
                                                </Form.Item>
                                            </Col>
                                            <Col span={24} sm={24} md={12} lg={8} xl={8}>
                                                <Form.Item style={{ marginBottom: '0.5rem' }}
                                                    label="Subject"
                                                    name="subject"
                                                    rules={[{ required: true, message: 'Please enter a Subject' }]}
                                                >
                                                    <Input
                                                        value={templateDetails.emailSubject}
                                                        onChange={(e) =>
                                                            setTemplateDetails({
                                                                ...templateDetails,
                                                                emailSubject: e.target.value,
                                                            })
                                                        }
                                                        placeholder="Subject"
                                                        disabled={isReadOnly} // Disable select
                                                    />
                                                </Form.Item>
                                            </Col>
                                            <Col span={24} sm={24} md={12} lg={8} xl={8}>
                                                <Form.Item style={{ marginBottom: '0.5rem' }}
                                                    label="From Name"
                                                    name="name"
                                                    rules={[{ required: true, message: 'Please enter a From Name' }]}
                                                >
                                                    <Input
                                                        placeholder="From Name"
                                                        value={messageSetup.fromName}
                                                        onChange={(e) =>
                                                            setMessageSetup(prev => ({
                                                                ...prev,
                                                                fromName: e.target.value
                                                            }))
                                                        }
                                                        disabled={isReadOnly} // Disable select
                                                    />
                                                </Form.Item>
                                            </Col>
                                            <Col span={24} sm={24} md={12} lg={8} xl={8}>
                                                <Form.Item style={{ marginBottom: '0.5rem' }}
                                                    label="From Email"
                                                    name="email"
                                                    rules={[
                                                        { required: true, message: 'Please enter a From Email' },
                                                        { type: 'email', message: 'Please enter a valid email address' },
                                                    ]}
                                                >
                                                    <Input
                                                        placeholder="From Email"
                                                        value={messageSetup.fromEmail}
                                                        onChange={(e) =>
                                                            setMessageSetup(prev => ({
                                                                ...prev,
                                                                fromEmail: e.target.value
                                                            }))
                                                        }
                                                        disabled={isReadOnly} // Disable select
                                                    />
                                                </Form.Item>
                                            </Col>
                                        </Row>
                                        <Row>
                                            <Col span={24}>
                                                <Flex gap="small" justify="space-between" style={{ marginTop: '1rem' }}>
                                                    <Title level={4}>Preview</Title>
                                                    <Flex gap="small">
                                                        <Button
                                                            type="primary"
                                                            onClick={handlePreviewButton}
                                                            disabled={!selectedTemplate || isReadOnly}
                                                        >
                                                            Preview
                                                        </Button>
                                                        {!isEditing ? (
                                                            <Button
                                                                type="primary"
                                                                icon={<EditOutlined />}
                                                                onClick={handleEditTemplate}
                                                                disabled={
                                                                    !selectedTemplate ||
                                                                    !messageSetup.fromName.trim() ||
                                                                    !messageSetup.fromEmail.trim() ||
                                                                    isReadOnly // Disable edit for Scheduled
                                                                }
                                                            >
                                                                Edit Template
                                                            </Button>
                                                        ) : (
                                                            <>
                                                                <Button
                                                                    type="primary"
                                                                    icon={<SaveOutlined />}
                                                                    onClick={handleSaveEdit}
                                                                    disabled={isReadOnly}
                                                                >
                                                                    Finish Editing
                                                                </Button>
                                                                <Button
                                                                    icon={<CloseOutlined />}
                                                                    onClick={handleCancelEdit}
                                                                    disabled={isReadOnly}
                                                                >
                                                                    Cancel
                                                                </Button>
                                                            </>
                                                        )}
                                                    </Flex>
                                                </Flex>
                                            </Col>
                                        </Row>
                                        <Row style={{ marginTop: '16px' }}>
                                            <Col span={24}>
                                                <Card
                                                    style={{
                                                        height: 'calc(100vh - 300px)',
                                                        overflow: 'auto',
                                                        borderRadius: '8px',
                                                        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
                                                        backgroundColor: '#f5f5f5',
                                                    }}
                                                    styles={{
                                                        body: {
                                                            padding: '0',
                                                            height: '100%',
                                                            overflow: 'auto',
                                                        },
                                                    }}
                                                >
                                                    <Overview
                                                        key={`${selectedTemplate}-${key}-${isEditing}-${emailBody}`}
                                                        emailTemplateName={templateDetails.emailSubject || 'New Template'}
                                                        setEmailBody={(body: string) => {
                                                            if (isEditing && !isScheduled) {
                                                                setEditedEmailBody(body);
                                                                setHasUnsavedChanges(true);
                                                            } else {
                                                                setEmailBody(body);
                                                                setTemplateDetails((prev) => ({ ...prev, emailBody: body }));
                                                            }
                                                        }}
                                                        emailBody={isEditing ? editedEmailBody : emailBody}
                                                        id={templateDetails.id}
                                                        templateName={templateDetails.emailSubject}
                                                        readOnly={!isEditing || isScheduled}
                                                        messageSetup={{
                                                            fromEmail: messageSetup.fromEmail,
                                                            fromName: messageSetup.fromName,
                                                        }}
                                                        msgid={masgid}
                                                        handleEditTemplate={handleEditTemplate}
                                                        selectedentityname={subgridType}
                                                    />
                                                </Card>
                                            </Col>
                                        </Row>
                                    </Form>
                                </Spin>
                            </Col>
                        </Row>
                    </div>
                )}
                {current === 2 && (
                    <div className="container">
                        {/* Configure Schedule */}
                        <Row>
                            <Col span={24}>
                                <Card title="Configure Schedule" size="small" style={{ marginBottom: '16px' }}>
                                    <Form form={form} layout="vertical">
                                        <Form.Item
                                            label="Select Schedule Delivery"
                                            name="scheduleType"
                                            rules={[{ required: true, message: 'Please select a schedule type' }]}
                                        >
                                            <Radio.Group
                                                value={scheduleType}
                                                onChange={isReadOnly ? undefined : handleScheduleTypeChange}
                                                disabled={isReadOnly}
                                            >
                                                <Radio value="0">Send Now</Radio>
                                                <Radio value="1">Choose Schedule Date</Radio>
                                            </Radio.Group>
                                        </Form.Item>

                                        {scheduleType === '1' && (
                                            <Card size="small" style={{ marginTop: 12, border: '1px solid #EBEDF3' }}>
                                                <Form.Item
                                                    label="Delivery Date As per UTC"
                                                    name="deliveryDate"
                                                    rules={[{ required: true, message: 'Please select a Delivery Date' }]}
                                                    style={{ marginBottom: 0 }}
                                                >
                                                    <DatePicker
                                                        showTime
                                                        style={{ width: '100%' }}
                                                        value={deliveryDate ? dayjs(deliveryDate) : null}
                                                        onChange={isReadOnly ? undefined : handleDeliveryDateChange}
                                                        disabled={isReadOnly}
                                                    />
                                                </Form.Item>
                                            </Card>
                                        )}
                                    </Form>
                                </Card>
                            </Col>
                        </Row>

                        <Row gutter={16}>
                            {/* LEFT SIDE: Campaign Summary + Email Preview */}
                            <Col span={12}>
                                <Card title="Campaign Summary" size="small" style={{ marginBottom: '16px' }}>
                                    <Descriptions
                                        bordered
                                        column={1}
                                        labelStyle={{ fontWeight: 'bold', width: '30%' }}
                                        contentStyle={{ width: '70%' }}
                                        size="small"
                                    >
                                        <Descriptions.Item label="From Name">
                                            {messageSetup?.fromName || 'N/A'}
                                        </Descriptions.Item>
                                        <Descriptions.Item label="From Email">
                                            {messageSetup?.fromEmail || 'N/A'}
                                        </Descriptions.Item>
                                        <Descriptions.Item label="Subject">
                                            {templateDetails?.emailSubject || 'N/A'}
                                        </Descriptions.Item>
                                    </Descriptions>
                                </Card>

                                <Card title="Email Preview" size="small">
                                    <Button
                                        icon={<EyeOutlined />}
                                        type="primary"
                                        onClick={() => setIsPreviewModalOpen(true)}
                                    >
                                        Preview Email Template
                                    </Button>
                                </Card>
                            </Col>

                            {/* RIGHT SIDE: Selection Analysis */}
                            <Col span={12}>
                                <Card title=" Analysis" size="small" style={{ marginBottom: '16px' }}>
                                    <Descriptions
                                        bordered
                                        column={1}
                                        labelStyle={{ fontWeight: 'bold', width: '40%' }}
                                        contentStyle={{ width: '60%' }}
                                        size="small"
                                    >
                                        <Descriptions.Item label="Selected Contacts">
                                            {subgridType === 'Contact' ? data?.length || 0 : 'N/A'}
                                        </Descriptions.Item>

                                        <Descriptions.Item label="Suppression Lists ">
                                            {rightGridData?.length || 0}
                                        </Descriptions.Item>
                                    </Descriptions>
                                </Card>
                            </Col>
                        </Row>

                        {/* Email Modal */}
                        <Modal
                            title="Email Preview"
                            open={isPreviewModalOpen}
                            onCancel={() => setIsPreviewModalOpen(false)}
                            footer={null}
                            width={900}
                            centered
                            bodyStyle={{
                                padding: 16,
                                maxHeight: '80vh',
                                overflow: 'hidden',
                            }}
                            style={{ overflow: 'hidden' }}
                            maskStyle={{ overflow: 'hidden' }}
                        >
                            <div
                                style={{
                                    maxHeight: 'calc(80vh - 32px)',
                                    overflowY: 'auto',
                                    paddingRight: 8,
                                }}
                                dangerouslySetInnerHTML={{
                                    __html: editedEmailBody || templateDetails?.emailBody || 'No email content available',
                                }}
                            />
                        </Modal>
                    </div>
                )}





            </Flex>
        </Flex>
    );
};

export default NewCampaign;


