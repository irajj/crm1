// Date:17-06-2025
// email css issue fix

import React, { useEffect, useState, useRef, useCallback } from "react";
import StudioEditor from "@grapesjs/studio-sdk/react";
import "@grapesjs/studio-sdk/style";
import CustomPlugin from "./CustomPlugin";
import MergeFieldModal from "../../../../Components/Modals/MergeFieldModal";

// Define props interface for type safety
interface OverviewProps {
    emailTemplateName: string;
    setEmailBody: (body: string) => void;
    emailBody: string;
    id?: string | null;
    templateName?: string;
    readOnly?: boolean;
    templateDetails?: {
        fromUser?: {
            name?: string;
            id: string;
        };
        emailSubject: string;

    };
    msgid?: string | null;
    handleEditTemplate?: () => void;
    messageSetup?: {
        fromEmail: string;
        fromName: string;
    };
    msgsetupname?: string;
    selectedentityname: string;
}

// Define type for projectData
interface ProjectData {
    type: string;
    pages: Array<{
        name: string;
        component: string;
    }>;
}

const Overview: React.FC<OverviewProps> = ({
    emailTemplateName,
    setEmailBody,
    emailBody,
    id,
    readOnly = true,
    msgid,
    messageSetup,
    msgsetupname,
    selectedentityname,
}) => {
    const [projectData, setProjectData] = useState<ProjectData | null>(null);
    const [showModal, setShowModal] = useState<boolean>(false);
    const editorRef = useRef<any>(null);

    // Fetch the email template by id when reopening the record
    const fetchEmailTemplateById = useCallback(async (templateId: string) => {
        if (emailBody == null) {
            try {
                const response = await fetch(
                    `https://emailboost.azurewebsites.net/api/messagetemplate/${templateId}`
                );
                if (response.ok) {
                    const data = await response.json();
                    return data?.data?.emailbody || "<p>No content available</p>";
                } else {
                    console.error("Failed to fetch the email template:", response.status);
                    return null;
                }
            } catch (error) {
                console.error("Error fetching email template:", error);
                return null;
            }
        }
    }, [emailBody]);

    useEffect(() => {
        const handlePopup = () => setShowModal(true);
        window.addEventListener("openGrapesPopup", handlePopup);

        const loadTemplate = async () => {
            let contentToLoad = emailBody;
            debugger
            if (id) {
                const savedContent = await fetchEmailTemplateById(id);
                if (savedContent) {
                    contentToLoad = savedContent;
                }
            }

            if (contentToLoad) {
                setProjectData({
                    type: "web",
                    pages: [{ name: "body", component: contentToLoad }],
                });
            } else {
                setProjectData({
                    type: "web",
                    pages: [{ name: "body", component: "<p>No content available</p>" }],
                });
            }
        };

        loadTemplate();

        return () => {
            window.removeEventListener("openGrapesPopup", handlePopup);
        };
    }, [id, emailTemplateName, emailBody, fetchEmailTemplateById]);

    if (readOnly) {
        return (
            <div
                style={{
                    padding: "20px",
                    height: "100%",
                    overflowY: "auto",
                    overflowX: "hidden",
                    backgroundColor: "#fff",
                    position: "relative",
                    maxHeight: "calc(100vh - 300px)",
                    scrollbarWidth: "thin",
                    scrollbarColor: "#888 #f1f1f1",
                }}
                onClick={(e) => e.preventDefault()}
                onMouseDown={(e) => e.preventDefault()}
                onMouseUp={(e) => e.preventDefault()}
                dangerouslySetInnerHTML={{
                    __html: emailBody,
                }}
            />
        );
    }

    return (
        <>
            <style>
                {`
                    .gjs-pn-commands {
                        display: ${readOnly ? "none" : "block"} !important;
                    }
                    .gjs-pn-panel.gjs-pn-views,
                    .gjs-pn-panel.gjs-pn-devices-c,
                    .gjs-block,
                    .gjs-block-category,
                    .gjs-layer,
                    .gjs-sm-sector {
                        display: ${readOnly ? "none" : "block"} !important;
                    }
                `}
            </style>
            <div id="gjs" style={{ display: "flex", flexDirection: "column", height: "100vh" }}>
                {projectData && (
                    <StudioEditor
                        ref={editorRef}
                        setEmailBody={setEmailBody}
                        options={{
                            licenseKey: "a424b71617804ad7a2fa40cdda9774cdd4cab6a26030432c90106bac08d815d2",
                            theme: "dark",
                            project: projectData,
                            storage: {
                                type: "self",
                                onSave: async () => {
                                    const editor = editorRef.current;
                                    if (editor) {
                                        const html = editor.getHtml();
                                        const css = editor.getCss();
                                        setEmailBody(html);

                                        const fullHtml = `
                                        <html>
                                            <head>
                                                <style>${css}</style>
                                            </head>
                                            <body>
                                                ${html}
                                            </body>
                                        </html>`;
                                        setEmailBody(fullHtml);

                                        try {
                                            const response = await fetch(
                                                `https://emailboost.azurewebsites.net/api/messagesetup/${msgid}`
                                            );
                                            if (!response.ok) {
                                                throw new Error("Failed to fetch message setup details");
                                            }
                                            const setupData = await response.json();

                                            // Type guard to check if messageSetup is defined
                                            const fromEmail = messageSetup?.fromEmail ?? "";
                                            const fromName = messageSetup?.fromName ?? "";

                                            const payload = {
                                                id: msgid,
                                                msgsetupmessagestatus: 1,
                                                messagetemplateid: id,
                                                msgsetupfromemail: setupData.data?.msgsetupfromemail || fromEmail,
                                                msgsetupfromname: setupData.data?.msgsetupfromname || fromName,
                                                msgsetupsubject: setupData.data?.msgsetupsubject || emailTemplateName || "",
                                                currentstage: 2,
                                                emailbody: fullHtml,
                                                msgsetupname: msgsetupname || setupData.data?.msgsetupname || "",
                                            };

                                            const saveResponse = await fetch(
                                                "https://emailboost.azurewebsites.net/api/messagesetup",
                                                {
                                                    method: "POST",
                                                    headers: {
                                                        "Content-Type": "application/json",
                                                    },
                                                    body: JSON.stringify(payload),
                                                }
                                            );

                                            if (!saveResponse.ok) {
                                                const errorData = await saveResponse.json();
                                                throw new Error(errorData.message || "Failed to save message setup");
                                            }

                                            const data = await saveResponse.json();
                                            console.log("Message setup saved successfully:", data);
                                        } catch (error) {
                                            console.error("Error saving message setup:", error);
                                        }
                                    }
                                },
                                onLoad: async () => {
                                    return { project: projectData };
                                },
                                autosaveChanges: 100,
                                autosaveIntervalMs: 10000,
                            },
                            plugins: ["gjs-blocks-basic", CustomPlugin],
                            pluginOptions: {
                                "gjs-blocks-basic": { blocks: ["image"] },
                                imageUploader: (file: File) => {
                                    const formData = new FormData();
                                    formData.append("file", file);
                                    return fetch("/upload", {
                                        method: "POST",
                                        body: formData,
                                    })
                                        .then((res) => res.json())
                                        .then((data) => data.url)
                                        .catch((error) => console.error("Upload failed", error));
                                },
                            },
                            canvas: {
                                styles: [
                                    "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css",
                                ],
                                scripts: [
                                    "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js",
                                ],
                                customBadgeLabel: readOnly ? "Read Only" : "Edit Mode",
                                disableSelection: readOnly,
                                disableDrag: readOnly,
                                disablePointerEvents: readOnly,
                            },
                        }}
                        onReady={(editorInstance) => {
                            debugger
                            editorRef.current = editorInstance;
                            if (readOnly) {
                                editorInstance.setMode("view");
                            }
                        }}
                    />
                )}

                <MergeFieldModal
                    editorRef={editorRef}
                    showModal={showModal}
                    setShowModal={setShowModal}
                    selectedEntityName={selectedentityname}
                />
            </div>
        </>
    );
};

export default Overview;