import React, { useState, useEffect, MouseEvent } from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button } from "@mui/material";

interface MergeFieldModalProps {
    open: boolean;
    onClose: () => void;
    editorRef: React.RefObject<any>;
}

interface Entity {
    id: string;
    name: string;
    setname: string;
    logicalname: string;
    displayName: {
        localizedLabels: { label: string }[];
    };
}

interface Fields {
    metadataId: string;
    logicalName: string;
    attributeTypeName: { value: string };
    entityLogicalName: string;
    targets?: string[];
    displayName: {
        localizedLabels: { label: string }[];
    };
}

interface FetchedFields {
    [key: string]: Fields[];
}

const MergeFieldModal: React.FC<MergeFieldModalProps> = ({ open, onClose, editorRef }) => {
    const [currentSlide, setCurrentSlide] = useState<number>(0);
    const [personalization, setPersonalization] = useState<string>('');
    const [primaryEntities, setPrimaryEntities] = useState<Entity[]>([]);
    const [expandedEntities, setExpandedEntities] = useState<{ [key: string]: boolean }>({});
    const [fetchedFields, setFetchedFields] = useState<FetchedFields>({});

    const url_get_all_entity = 'https://emailboost.azurewebsites.net/api/entity';

    useEffect(() => {
        if (open) fetchEntities();
    }, [open]);

    const fetchEntities = async () => {
        try {
            const response = await fetch(url_get_all_entity);
            const data = await response.json();
            const entities: Entity[] = data.data;

            const primary = entities.filter(e => ['contact', 'account', 'lead', 'opportunity'].includes(e.logicalname));

            setPrimaryEntities(primary);
        } catch (error) {
            console.error("Error fetching entities:", error);
        }
    };

    const fetchFieldsForEntity = async (entityLogicalName: string, entityId: string) => {
        try {
            const response = await fetch(`https://emailboost.azurewebsites.net/api/entity/${entityLogicalName}`);
            const data = await response.json();

            const fields = data.data.filter((f: Fields) => f.displayName?.localizedLabels?.length > 0);
            setFetchedFields((prev: FetchedFields) => ({ ...prev, [entityId]: fields }));
        } catch (error) {
            console.error("Error fetching fields:", error);
        }
    };

    const toggleFields = async (entityId: string, e: MouseEvent, entity: Entity, nextSlide: string) => {
        e.preventDefault();
        if (nextSlide !== '') setCurrentSlide(Number(nextSlide));

        setExpandedEntities(prev => ({ ...prev, [entityId]: !prev[entityId] }));

        if (!fetchedFields[entityId]) {
            await fetchFieldsForEntity(entity.logicalname, entityId);
        }
    };

    const PasteToEditor = (
        e: React.MouseEvent<HTMLElement>,
        entityName: string,
        fieldName: string
    ) => {
        e.preventDefault();
        const editor = editorRef.current;
        if (editor) {
            const selected = editor.getSelected();
            if (selected) {
                selected.append(`{!${entityName}.${fieldName}}`);
                onClose();
            } else {
                onClose();
                console.error("No component selected.");
            }
        } else {
            console.error("Editor instance is not available");
        }
    };

    return (
        <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
            {currentSlide === 0 && (
                <>
                    <DialogTitle>Personalization</DialogTitle>
                    <DialogContent>
                        <input
                            className="form-control"
                            placeholder="Choose Attribute"
                            value={personalization}
                            onChange={(e) => setPersonalization(e.target.value)}
                        />
                        <Button onClick={() => setCurrentSlide(1)}>Next</Button>
                    </DialogContent>
                </>
            )}

            {currentSlide === 1 && (
                <>
                    <DialogTitle>Choose an Entity</DialogTitle>
                    <DialogContent>
                        {primaryEntities.map(entity => (
                            <div key={entity.id}>
                                <Button onClick={(e:any) => toggleFields(entity.id, e, entity, '1')}>
                                    {entity.displayName.localizedLabels[0]?.label || entity.logicalname}
                                </Button>
                                {expandedEntities[entity.id] && fetchedFields[entity.id]?.map(field => (
                                    <div key={field.metadataId}>
                                        <span>{field.displayName.localizedLabels[0]?.label}</span>
                                        <Button onClick={(e:any) => PasteToEditor(e, field.entityLogicalName, field.logicalName)}>
                                            Insert
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        ))}
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => setCurrentSlide(0)}>Back</Button>
                        <Button onClick={() => setCurrentSlide(2)}>Next</Button>
                    </DialogActions>
                </>
            )}
        </Dialog>
    );
};

export default MergeFieldModal;
