﻿import { Editor } from "@grapesjs/studio-sdk-plugins/dist/types.js";
import { createRoot } from "react-dom/client";
import React, { useState } from "react";

// React component typed for editor
interface CustomCodeEditorProps {
    editor: Editor;
}

const CustomCodeEditor: React.FC<CustomCodeEditorProps> = ({ editor }) => {
    const [code, setCode] = useState("<div>Hello, GrapesJS!</div>");

    const addCustomBlock = () => {
        editor.BlockManager.add("custom-code-block", {
            label: "Custom Code",
            content: code,
            category: "Custom",
        });
    };

    return (
        <div style={{ padding: "10px", borderTop: "1px solid #ccc" }}>
            <h4>Custom Code</h4>
            <textarea
                style={{ width: "100%", height: "100px" }}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Type your HTML/JSX..."
            />
            <button onClick={addCustomBlock} style={{ marginTop: "5px" }}>
                Add to Blocks
            </button>
        </div>
    );
};

// Main export: Register GrapesJS plugin
export default (editor: Editor) => {
    const panels = editor.Panels;

    // Add button to toggle panel
    panels.addButton("options", [
        {
            id: "toggle-custom-panel",
            className: "fa fa-code",
            command: "toggle-custom-panel",
            attributes: { title: "Toggle Custom Panel" },
        },
    ]);

    // Add panel, initially hidden
    panels.addPanel({
        id: "custom-code-panel",
        visible: false,
        buttons: [],
    });

    // Create a container for React content
    const panelContainer = document.createElement("div");
    panelContainer.id = "custom-code-container";

    // Attach container to the GrapesJS panel
    const panelView = editor.Panels.getPanel("custom-code-panel")?.view;
    if (panelView) {
        panelView.el.appendChild(panelContainer);
    }

    // ✅ React 18+ compatible rendering
    const root = createRoot(panelContainer);
    root.render(<CustomCodeEditor editor={editor} />);

    // Toggle panel command
    editor.Commands.add("toggle-custom-panel", {
        run(editor) {
            const panel = editor.Panels.getPanel("custom-code-panel");
            if (panel) {
                panel.set("visible", !panel.get("visible"));
            }
        },
    });
};
