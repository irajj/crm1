// Author: Deven
// Date: 2025-04-16
// Create a function to dynamically determine the "Email Address" field
// based on the selected grid type. Add a condition inside the function to handle this logic.

//===================================================================

// Author: Deven
// Date: 07-05-2025
// Convert the API into a common API service

// Date:28-05-2025
// fix the bug that pagination are not work from the frontend.
// add a select all button for select all the users or records
// show the count of the selected records
// change the import button name

// date:29-05-25
// add a garpej and add a div to show a emal body.
// changes into Message Type dropdown.

// Date:31-05-2025
// changes the button name
// fix or call the api call

// Date:02-06-2025
// Change the text of the title
// Changes into Ui Given by abhishek
// getAllMember api response pass as a array of the object


// Date:24-06-2025
// add a loader
// import button are disable until user select the audiance type

import { Button, Drawer, Empty, Form, Select, Space, Table, Spin, message } from "antd";
import { ColumnType } from "antd/es/table";
import React, { useEffect, useState, useCallback } from "react";
import apiService from "../../../services/ApiService";
import { debounce } from "lodash";

interface ImportDrawerProps {
  open: boolean;
  onClose: () => void;
  subgridType: string;
  onImport: (selectedRows: Record<string, any>[]) => void;
  importedRows: Record<string, any>[];
}

interface DataType {
  id: string;
  contactEmailAddress?: string;
  contactFullname?: string;
  statusLabel?: string;
  emailaddress1?: string;
  [key: string]: any;
}

const ImportDrawer: React.FC<ImportDrawerProps> = ({
  open,
  onClose,
  subgridType,
  onImport,
  importedRows,
}) => {
  const [data, setData] = useState<DataType[]>([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
  const [selectedRows, setSelectedRows] = useState<Record<string, any>[]>([]);
  const [selectedDropdown, setSelectedDropdown] = useState<string | undefined>(
    undefined
  );
  const [form] = Form.useForm();
  const [isLoading, setIsLoading] = useState(false);
  const [, setError] = useState<string | null>(null);
  const [localDropdownData, setLocalDropdownData] = useState<
    Record<string, any>[]
  >([]);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });

  // Fetch marketing data when drawer opens
  useEffect(() => {
    if (open && subgridType !== "none") {
      const fetchMarketingData = async () => {
        setIsLoading(true);
        try {
          const response = await apiService.get<any>(
            `/marketing/${subgridType}`
          );
          setLocalDropdownData(response?.data || []);
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        } catch (error) {
          setError("Failed to load marketing data");
        } finally {
          setIsLoading(false);
        }
      };
      fetchMarketingData();
    }
  }, [open, subgridType]);

  // Sync selected rows with importedRows
  useEffect(() => {
    setSelectedRows(importedRows);
    setSelectedRowKeys(importedRows.map((row) => row.id));
  }, [importedRows]);

  // Reset states when drawer closes
  useEffect(() => {
    if (!open) {
      setData([]);
      setSelectedRowKeys([]);
      setSelectedRows([]);
      setSelectedDropdown(undefined);
      form.resetFields();
      setPagination({ current: 1, pageSize: 10, total: 0 });
      setError(null);
    }
  }, [form, open]);

  // Dynamic column configuration based on subgridType
  const getColumns = (): ColumnType<DataType>[] => {
    let emailField = "";
    let fullnameField = "";
    let companyField = "";
    let statusField = "";
    let cityField = "";
    let phonenumber = "";
    let primarycontact = "";
    let contactfield = "";

    switch (subgridType) {
      case "Contact":
        emailField = "contactEmailAddress";
        fullnameField = "contactFullname";
        companyField = "company.name";
        statusField = "statusLabel";
        cityField = "contactAddressCity";
        break;
      case "Lead":
        emailField = "emailaddress1";
        fullnameField = "fullname";
        companyField = "company.name";
        contactfield = "contact.name";
        statusField = "company.statusLabel";
        cityField = "";
        break;
      case "Account":
        emailField = "accountemailaddress";
        fullnameField = "name";
        statusField = "statusLabel";
        phonenumber = "mobilephone";
        primarycontact = "contact.name";
        break;
      default:
        break;
    }

    const getValue = (obj: any, path: string) => {
      return path.split(".").reduce((acc, part) => acc && acc[part], obj) || "";
    };

    const columns: ColumnType<DataType>[] = [];

    if (emailField) {
      columns.push({
        title: "Email Address",
        dataIndex: emailField,
        render: (_: any, record: DataType) => getValue(record, emailField),
        sorter: (a, b) =>
          getValue(a, emailField).localeCompare(getValue(b, emailField)),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    if (fullnameField) {
      columns.push({
        title: "Full Name",
        dataIndex: fullnameField,
        render: (_: any, record: DataType) => getValue(record, fullnameField),
        sorter: (a, b) =>
          getValue(a, fullnameField).localeCompare(getValue(b, fullnameField)),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    if (companyField) {
      columns.push({
        title: "Company",
        dataIndex: companyField,
        render: (_: any, record: DataType) => getValue(record, companyField),
        sorter: (a, b) =>
          getValue(a, companyField).localeCompare(getValue(b, companyField)),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    if (contactfield) {
      columns.push({
        title: "Contact",
        dataIndex: contactfield,
        render: (_: any, record: DataType) => getValue(record, contactfield),
        sorter: (a, b) =>
          getValue(a, contactfield).localeCompare(getValue(b, contactfield)),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    if (primarycontact) {
      columns.push({
        title: "Primary Contact",
        dataIndex: primarycontact,
        render: (_: any, record: DataType) => getValue(record, primarycontact),
        sorter: (a, b) =>
          getValue(a, primarycontact).localeCompare(
            getValue(b, primarycontact)
          ),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    if (phonenumber) {
      columns.push({
        title: "Phone Number",
        dataIndex: phonenumber,
        render: (_: any, record: DataType) => getValue(record, phonenumber),
        sorter: (a, b) =>
          getValue(a, phonenumber).localeCompare(getValue(b, phonenumber)),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    if (cityField) {
      columns.push({
        title: "City",
        dataIndex: cityField,
        render: (_: any, record: DataType) => getValue(record, cityField),
        sorter: (a, b) =>
          getValue(a, cityField).localeCompare(getValue(b, cityField)),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    if (statusField) {
      columns.push({
        title: "Status",
        dataIndex: statusField,
        render: (_: any, record: DataType) => getValue(record, statusField),
        sorter: (a, b) =>
          getValue(a, statusField).localeCompare(getValue(b, statusField)),
        sortDirections: ["ascend", "descend"],
        showSorterTooltip: true,
      });
    }

    return columns;
  };

  // Debounced API call for fetching data
  const fetchData = useCallback(
    debounce(async (value: string) => {
      if (!subgridType || subgridType === "none") return;
      setIsLoading(true);
      setError(null);
      try {
        const response = await apiService.post<{ data: any[]; total: number }>(
          "/marketinglist/getAllMember",
          {
            ...JSON.parse(value),
            page: pagination.current,
            pageSize: pagination.pageSize,
          },
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        const responseData = Array.isArray(response.data) ? response.data : [];
        setData(responseData);
        setPagination((prev) => ({
          ...prev,
          total: response.total || responseData.length,
        }));
        if (responseData.length === 0) {
          setError("No data found.");
        }
      } catch (err: any) {
        setData([]);
        setError(err.message || "No data found.");
      } finally {
        setIsLoading(false);
      }
    }, 300),
    [subgridType, pagination.current, pagination.pageSize]
  );

  const handleDropdownChange = (value: string) => {
    setSelectedDropdown(value);
    setPagination((prev) => ({ ...prev, current: 1, pageSize: 10 }));
    fetchData(value);
  };

  const handleTableChange = (newPagination: any) => {
    const isPageSizeChanged = newPagination.pageSize !== pagination.pageSize;
    setPagination({
      ...newPagination,
      current: isPageSizeChanged ? 1 : newPagination.current,
    });
  };

  const onSelectChange = (
    newSelectedRowKeys: React.Key[],
    newSelectedRows: Record<string, any>[]
  ) => {
    setSelectedRowKeys(newSelectedRowKeys);
    setSelectedRows(newSelectedRows);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
  };

  const handleImport = () => {
    if (!subgridType || subgridType === "none") {
      message.warning("Please select an audience type before importing.");
      return;
    }
  
    if (!selectedDropdown) {
      message.warning("Please select a marketing list before importing.");
      return;
    }
  
    onImport(selectedRows);
    onClose();
  };
  
  

  return (
    <Drawer
      title={`${subgridType} `}
      width={720}
      onClose={onClose}
      open={open}
      extra={
        <Space>
          <Button onClick={onClose}>Cancel</Button>
          <Button type="primary" onClick={handleImport}>
            Import {subgridType.toLowerCase()}s
          </Button>
        </Space>
      }
    >
      {isLoading ? (
        <div style={{ textAlign: "center", padding: "40px 0" }}>
          <Spin size="large" tip="Loading..." />
        </div>
      ) : (
        <Form layout="vertical" form={form} className="import-drawer-form">
          <Form.Item label="Marketing List" name="marketing_list">
            <Select
              value={selectedDropdown}
              placeholder="Select"
              onChange={handleDropdownChange}
              options={(localDropdownData || []).map((record) => ({
                value: JSON.stringify(record),
                label: record.name,
                key: record.id,
              }))}
            />
          </Form.Item>
          {data.length > 0 ? (
            <>
              <div
                style={{
                  marginBottom: 16,
                  display: "flex",
                  alignItems: "center",
                  gap: "16px",
                }}
              >
                <Button
                  type="primary"
                  onClick={() => {
                    if (selectedRowKeys.length === data.length) {
                      setSelectedRowKeys([]);
                      setSelectedRows([]);
                    } else {
                      const allKeys = data.map((item) => item.id);
                      const allRows = data;
                      setSelectedRowKeys(allKeys);
                      setSelectedRows(allRows);
                    }
                  }}
                  disabled={data.length === 0}
                >
                  {selectedRowKeys.length === data.length
                    ? `Deselect All ${subgridType}s`
                    : `Select All ${subgridType}s`}
                </Button>
                <span style={{ fontSize: "14px", color: "#666" }}>
                  Selected: {selectedRowKeys.length}{" "}
                  {selectedRowKeys.length === 1
                    ? subgridType.toLowerCase()
                    : `${subgridType.toLowerCase()}s`}
                </span>
              </div>
              <Table
                rowSelection={rowSelection}
                dataSource={data}
                rowKey="id"
                columns={getColumns()}
                pagination={{
                  ...pagination,
                  showSizeChanger: true,
                  showTotal: (total) => `Total ${total} items`,
                }}
                onChange={handleTableChange}
                style={{ flexGrow: 1 }}
                scroll={{ y: "calc(100vh - 388px)", x: "none" }}
                showSorterTooltip={{ target: "sorter-icon" }}
              />
            </>
          ) : (
            selectedDropdown && (
              <div style={{ textAlign: "center", padding: "40px 0" }}>
                <Empty description="No data found for the selected list." />
              </div>
            )
          )}
        </Form>
      )}
    </Drawer>
  );
};

export default ImportDrawer;
