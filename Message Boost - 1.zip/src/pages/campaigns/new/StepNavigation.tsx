// Date: 30-04-2025
// Author: Deven
// - Added Ant Design icons to the Previous and Next buttons

// Date: 31-05-2025
// Author: Abhishek
// - Made UI changes:
//     • Adjusted spacing (margins and padding)

// Date: 30-06-2025
// Author: Deven
// - Replaced the "Done" button with a "Back" button on the last step when the status is "Scheduled"
// - Prevented multiple clicks on the "Done" button to avoid redundant API calls
// - Renamed "Back to Home" button to "Back All Campaign"
// Remove the Home icon in the 


import { LeftOutlined, RightOutlined } from "@ant-design/icons";
import { Button, Flex } from "antd";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const steps = [
    { title: "Define Audience" },
    { title: "Select Template" },
    { title: "Set Schedule" },
];

interface StepNavigationProps {
    current: number;
    next: () => void;
    prev: () => void;
    isSubmitting?: boolean;
    isNavigating?: boolean;
    isScheduled?: boolean; 
}

const StepNavigation: React.FC<StepNavigationProps> = ({
    current,
    next,
    prev,
    isSubmitting = false,
    isNavigating = false,
    isScheduled = false, 
}) => {
    const navigate = useNavigate();

    const [isDoneClick, setIsDoneClick] = useState(false);

    const handleDoneClick = () => {
        if (!isDoneClick) {
            setIsDoneClick(true);
            next();
        }
    }

    return (
        <Flex justify={current === 0 ? "end" : "space-between"} style={{ marginTop: "0.5rem", marginBottom: "0.5rem" }}>
            {current > 0 && (
                <Button onClick={prev} disabled={isSubmitting}>
                    <LeftOutlined /> Previous
                </Button>
            )}
            {current < steps.length - 1 && (
                <Button
                    type="primary"
                    onClick={next}
                    disabled={current === 0 ? isSubmitting || isNavigating : isSubmitting}
                    loading={current === 0 ? isNavigating : false}
                >
                    Next <RightOutlined />
                </Button>
            )}
            {current === steps.length - 1 && (
                isScheduled ? (
                    // Show Back to Home Page button for Scheduled campaigns
                    <Button
                        type="primary"
                        onClick={() => navigate("/campaigns")}
                        disabled={isSubmitting}
                    >
                         Back to All Campaign
                    </Button>
                ) : (
                    // Show Done button for non-Scheduled campaigns
                    <Button
                        type="primary"
                            onClick={handleDoneClick}
                            disabled={isSubmitting || isDoneClick}
                        loading={isSubmitting}
                    >
                        {isSubmitting ? "Creating..." : "Done"}
                    </Button>
                )
            )}
        </Flex>
    );
};

export default StepNavigation;