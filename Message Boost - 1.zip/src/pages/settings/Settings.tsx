//31-05-2025
// Author: Abhishek
// Made ui changes
//  - modified topbar design and made spacing changes like margins and padding



// import React, { useState, useRef } from "react";
// import { Tabs, Input,  Radio, Table, Button, Flex } from "antd";
import { Tabs, Input, Flex, Form } from "antd";
import type { TabsProps } from "antd";
// import { X } from "react-icons/x";
// import EmailValidator from "email-validator"; // Assuming you have this library
// import { X } from "react-feather";
import "./Setting.css";
import Title from "antd/es/typography/Title";
const onChange = (key: string) => {
  console.log(key);
};

// const columns: any = [
//   {
//     title: "Name",
//     dataIndex: "name",
//     key: "name",
//     sorter: (a: any, b: any) => a.name.localeCompare(b.name),
//     sortDirections: ["ascend", "descend"],
//   },
//   {
//     title: "Value",
//     dataIndex: "value",
//     key: "value",
//     sorter: (a: any, b: any) => a.name.localeCompare(b.name),
//     sortDirections: ["ascend", "descend"],
//   },
// ];

// const contactData = [
//   { key: "1", name: "John Doe", value: "john@example.com" },
//   { key: "2", name: "Jane Smith", value: "jane@example.com" },
// ];

// const leadData = [
//   { key: "1", name: "Lead 1", value: "Product A" },
//   { key: "2", name: "Lead 2", value: "Product B" },
// ];

// const accountData = [
//   { key: "1", name: "Account 1", value: "Active" },
//   { key: "2", name: "Account 2", value: "Inactive" },
// ];

const Settings: React.FC = () => {
  // const [emails, setEmails] = useState<string[]>([]);
  // const [inputValue, setInputValue] = useState("");
  // const [isFocused, setIsFocused] = useState(false);
  // const inputRef = useRef<HTMLInputElement>(null);
  // const containerRef = useRef<HTMLDivElement>(null);

  // const handleContainerClick = () => {
  //   inputRef.current?.focus();
  // };

  const items: TabsProps["items"] = [
    {
      key: "1",
      label: "General",
      children: (
        <>
          <Form
            name=""
            layout="vertical"
            labelCol={{ span:24,sm:24,md:12,lg:8 }}
            wrapperCol={{ span:24,sm:24,md:12,lg:8 }}
          >
            <Form.Item
              label="Max. Audience Allow"
              name="maxaudienceallow"
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="Default Subject"
              name="defaultsubject"
            >
              <Input />
            </Form.Item>
          </Form>
        </>
      ),
    },
    //{
    //  key: "2",
    //  label: "TESTING",
    //  children: (
    //    <>
    //      <div style={{ marginBottom: "16px" }}>
    //        <label>Enforcement Testing for message setup: </label>
    //        <Radio.Group defaultValue="yes" style={{ marginLeft: "16px" }}>
    //          <Radio value="yes">Yes</Radio>
    //          <Radio value="no">No</Radio>
    //        </Radio.Group>
    //      </div>
    //      <div style={{ marginBottom: "16px" }}>
    //        <Flex
    //          justify="space-between"
    //          align="center"
    //          style={{ marginBottom: "8px" }}
    //        >
    //          <h3>Contact Subgrid</h3>
    //          <Button type="primary">Add Contact</Button>
    //        </Flex>
    //        <Table columns={columns} dataSource={contactData} pagination={false} />
    //      </div>
    //      <div style={{ marginBottom: "16px" }}>
    //        <Flex
    //          justify="space-between"
    //          align="center"
    //          style={{ marginBottom: "8px" }}
    //        >
    //          <h3>Contact Subgrid</h3>
    //          <Button type="primary">Add Contact</Button>
    //        </Flex>
    //        <Table columns={columns} dataSource={leadData} pagination={false} />
    //      </div>
    //      <div style={{ marginBottom: "16px" }}>
    //        <Flex
    //          justify="space-between"
    //          align="center"
    //          style={{ marginBottom: "8px" }}
    //        >
    //          <h3>Contact Subgrid</h3>
    //          <Button type="primary">Add Contact</Button>
    //        </Flex>
    //        <Table columns={columns} dataSource={accountData} pagination={false} />
    //      </div>
    //    </>
    //  ),
    //},
    {
      key: "3",
      label: "RELATED",
      children: "Content of Privacy Settings",
    },
  ];

  return (
    <div
      style={{
          padding: "1rem",
          background: "white",
      }}
    >
      <Flex justify="space-between" align="center">
        <Title level={4}>Settings</Title>
      </Flex>

      <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
    </div>
  );
};

export default Settings;
