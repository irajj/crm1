import { useEffect, useState, useRef } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  Switch, Button, Input, Select, InputRef, Flex, notification, Form, Spin, Badge, Row,
  Col,
} from "antd";
import MessageModal from "../../../Components/Modals/MessageModal";
import "./CreateConnections.css";
import type { RefSelectProps } from "antd/es/select";
import { ArrowLeft } from "lucide-react";
import Title from "antd/es/typography/Title";

const CreateConnections = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // State Management
  const [defaultconnection, setDefaultConnection] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  // const [modalMessage, setModalMessage] = useState("");
  // const [modalColor, setModalColor] = useState("green");
  const [api, contextHolder] = notification.useNotification();
  const [messagingservices, setMessagingservices] = useState<number | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [testing, setTesting] = useState(false);
  const [hasFetched, setHasFetched] = useState(false);

  // Determine dynamic labels/placeholders
  // const isAzureEmail = messagingservices === 2;
  // const isMailJet = messagingservices === 3;
  const [authtype, setAuthtype] = useState<number | undefined>(undefined);
  const isAuthTypeConnectionString = authtype == 2;

  // const isAuthTypeKeySecret = authtype == 3 || messagingservices == 6;

  const [isAuthTypeKeySecret, setisAuthTypeKeySecret] = useState(Boolean);

  const keyNamePlaceholder = isAuthTypeConnectionString ? "Connection String Name" : "API Key Name";
  const keyValuePlaceholder = isAuthTypeConnectionString ? "Connection String" : "API Key Value";
  const [isKeySecret, setIsKeySecret] = useState(Boolean);
  // #region validadtion states
  const [msgservicename, setMsgservicename] = useState("");

  const [msgserviceapikeyname, setMsgserviceapikeyname] = useState("");
  const [apikeyvalue, setAPikeyvalue] = useState("");
  const [privatekey, setPrivatekeyvalue] = useState("");
  const messageServiceNameRef = useRef<InputRef>(null);
  const serviceProviderRef = useRef<RefSelectProps>(null);
  const authTypeRef = useRef<RefSelectProps>(null);
  const apiKeyNameRef = useRef<InputRef | null>(null);
  const apiKeyValue = useRef<InputRef | null>(null);
  const privateKeyValue = useRef<InputRef | null>(null);
  const isNotificationOpen = useRef(false);
  // const [isDirty, setIsDirty] = useState(false); // Track if form has unsaved changes


  // #endregion

  const { Option } = Select;

  useEffect(() => {
    // #region Edit Form stage

    if (id) {

      const fetchTemplate = async () => {
        try {
          setIsFetching(true);
          const response = await fetch(
            `https://emailboost.azurewebsites.net/api/messageingservice/${id}`
          );
          if (!response.ok) throw new Error("Failed to fetch template");

          const data = await response.json();
          setMsgservicename(data.data.msgservicename);

          setMessagingservices(Number(data.data.messagingservices));

          setAuthtype(Number(data.data.authtype));

          setisAuthTypeKeySecret(Number(data.data.authtype) == 3 ? true : false);
          setIsKeySecret(Number(data.data.authtype) == 3 ? true : false);
          if (Number(data.data.authtype) == 3) {
            setPrivatekeyvalue(data.data.privatekey)
          }

          setAPikeyvalue(data.data.apikeyvalue);
          setMsgserviceapikeyname(data.data.msgserviceapikeyname);
          setDefaultConnection(Boolean(data.data.defaultconnection));
          setIsActive(Boolean(data.data.defaultconnection));
          setHasFetched(true);

        } catch (error) {
          console.error("Error fetching template:", error);
        } finally {
          setIsFetching(false);  // stop fetch loading
        }
      };

      fetchTemplate();
    } else {

      setMsgservicename("");
      // setMessagingservices("");
      // setAuthtype("");
      setAPikeyvalue("");
      setMsgserviceapikeyname("");
      // setDefaultConnection(false);
      setIsActive(false);


    }
    // #endregion
  }, [id]);

  const showSingleWarning = (type: string, message: string, description: string) => {

    notification.destroy(); // instantly closes any existing ones

    if (isNotificationOpen.current) return;

    isNotificationOpen.current = true;

    api.open({
      message: message,
      description,
      type: type as 'success' | 'info' | 'warning' | 'error',
      // duration, // in seconds
      duration: 2,
      closable: true,
      onClose: () => {
        isNotificationOpen.current = false;
      },
    });

    // Fallback in case onClose isn't triggered (very rare)
    // setTimeout(() => {
    //   isNotificationOpen.current = false;
    // }, duration * 1000 + 100); // small buffer
  };

  const handleTestActive = async () => {

    // Validation before API call
    if (!messagingservices) {
      showSingleWarning('warning', '', 'Please select service provider!');
      serviceProviderRef.current?.focus();
      return;
    }

    if (!apikeyvalue) {
      showSingleWarning('warning', '', 'Please fill in the API key value!');
      apiKeyValue.current?.focus();
      return;
    }
    if (isAuthTypeKeySecret) {
      if (!privatekey) {
        showSingleWarning('warning', '', 'Please fill in the private key value!');
        privateKeyValue.current?.focus();
        return false;
      }
    }

    const payload = { messagingservices, apikeyvalue };
    setTesting(true);
    try {
      const response = await fetch(
        `https://emailboost.azurewebsites.net/api/messageingservice/testapikey`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );

      if (!response.ok) {
        // setModalMessage("Something went wrong with credentials");
        // setModalColor("red");
        showSingleWarning('error', '', "Something went wrong with credentials");
      } else {
        // setModalMessage("API Key test successful!");
        // setModalColor("green");
        showSingleWarning('success', '', 'API Key test successful!');
      }
      // setIsModalOpen(true);
    } catch (error) {
      console.error("Error testing API Key:", error);
    }
    finally {
      setTesting(false);
    }
  };

  const validateFields = () => {
    if (!msgservicename) {
      showSingleWarning('warning', '', 'Please fill message service name!');
      messageServiceNameRef.current?.focus();
      return false;
    }

    if (!messagingservices) {
      showSingleWarning('warning', '', 'Please select service provider!');
      serviceProviderRef.current?.focus();
      return false;
    }

    if (!authtype) {
      showSingleWarning('warning', '', 'Please select authentication type!');
      authTypeRef.current?.focus();
      return false;
    }

    if (!msgserviceapikeyname) {
      showSingleWarning('warning', '', 'Please fill API key name!');
      apiKeyNameRef.current?.focus();
      return false;
    }

    if (!apikeyvalue) {
      showSingleWarning('warning', '', 'Please fill in the API key value!');
      apiKeyValue.current?.focus();
      return false;
    }

    if (isAuthTypeKeySecret) {
      if (!privatekey) {
        showSingleWarning('warning', '', 'Please fill in the private key value!');
        privateKeyValue.current?.focus();
        return false;
      }
    }

    return true;
  };

  const handleSave = async () => {

    if (!validateFields()) {

      return;
    }

    const payload = {
      id: id || null,
      msgservicename,
      messagingservices,
      authtype,
      apikeyvalue,
      msgserviceapikeyname,
      defaultconnection,
      privatekey
    };

    setLoading(true);
    try {
      const response = await fetch(
        `https://emailboost.azurewebsites.net/api/messageingservice`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );

      if (!response.ok) {
        const result = await response.json();


        const message =
          typeof result.data === "string"
            ? result.data
            : result.data?.Message || "Unknown error occurred";

        showSingleWarning('error', '', message);

        setIsActive(false);
        setDefaultConnection(false);
        throw new Error("Error saving data");
        return false;
      }
      // setIsDirty(false)
      // const result = await response.json()
      if (id == '' || id == undefined) {
        navigate("/connections");
      }
      // else {
      //   navigate(`/createconnections/${result.data}`)
      // }
    } catch (error) {
      console.error("Error saving data:", error);
    }
    finally {
      setLoading(false);
    }
  };

  const handleToggleChange = (checked: boolean) => {
    if (defaultconnection == true) {
      setDefaultConnection(false);
    }
    else {
      setDefaultConnection(true);
    }
    setIsActive(checked);
  };


  const handleMessageServiceName = (msgservicename: string) => {
    // setIsDirty(true);
    setMsgservicename(msgservicename);
  }

  const handleCloseModal = () => setIsModalOpen(false);

  return (
    <div className="create-connections-container">
      <div
        className="menubar"
        style={{
          borderBottom: "1px solid #dde4e9",
          // boxShadow: "1px 1px 15px #dde4e9",
          padding: "0.4rem",
          background: "white",
          position: "sticky",
          top: "48px",
          zIndex: "2",
        }}
      >
        <Flex gap={'0.2rem'}>
          <Link to="/connections">
            <Button color="default" variant="link" size="middle">
              <ArrowLeft size={16} />
            </Button>
          </Link>
          <Button color="default" variant="filled" onClick={handleSave}>
            Save
          </Button>
          <Button color="default" variant="filled" onClick={handleTestActive}>
            Test and Active
          </Button>
        </Flex>
      </div>


      <div
        style={{
          // border: "1px solid #dde4e9",
          // boxShadow: "1px 1px 15px #dde4e9",
          padding: "1rem",
          // borderRadius: "0.6rem",
          background: "white",
          flexGrow:1
        }}
      >
        <Flex justify="space-between">
          <Title level={4}>{id ? 'Edit Connection' : 'Create Connection'}</Title>
          <Badge
            color={
              defaultconnection
                ? "green"
                : "red"
            }
            count={defaultconnection
              ? "Default"
              : "Inactive"} />
        </Flex>
        <div
          className="create-connections-form"
          style={{ marginTop: "24px" }}
        >


          <Spin
            spinning={loading || isFetching || testing}
            tip={
              testing
                ? "Testing..."
                : !hasFetched && id
                  ? "Loading..."
                  : id
                    ? "Updating..."
                    : "Creating..."
            }
          >
            <Form layout="vertical">

              <Row gutter={32}>
                <Col span={24} sm={24} md={16} lg={12} xl={12}>
                  {/* Message Service Name */}
                  <Form.Item
                    style={{ marginBottom: "0.5rem" }}
                    label="Name"
                    rules={[{ message: "Please enter a name!" }]}
                  >
                    <Input
                      ref={messageServiceNameRef}
                      placeholder="Name"
                      value={msgservicename}
                      onChange={(e) => handleMessageServiceName(e.target.value)}
                    // onChange={(e) => setMsgservicename(e.target.value)}
                    />
                  </Form.Item>
                </Col>
                <Col span={24} sm={24} md={16} lg={12} xl={12}>
                  {/* Service Provider Dropdown */}
                  <Form.Item
                    style={{ marginBottom: "0.5rem" }}
                    label="Service Provider"
                  >
                    <Select
                      ref={serviceProviderRef}
                      placeholder="Choose your Service Provider"
                      value={messagingservices}
                      onChange={(value) => {

                        setAuthtype(value == 6 ? 3 : value == 2 ? 2 : 1);
                        setMessagingservices(value);

                        setisAuthTypeKeySecret(value == 6 ? true : false);
                        setIsKeySecret(value == 6 ? true : false);
                      }}
                      style={{ width: "100%" }}
                    >
                      <Option value={6}>AWS</Option>
                      <Option value={2}>AzureEmail</Option>
                      <Option value={1}>SendGrid</Option>
                      <Option value={3} disabled>
                        MailJet
                      </Option>
                      <Option value={4} disabled>
                        Postmark
                      </Option>
                      <Option value={5} disabled>
                        ElasticEmail
                      </Option>
                    </Select>
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={32}>
                <Col span={24} sm={24} md={16} lg={12} xl={12}>
                  {/* Authentication Type */}
                  <Form.Item
                    style={{ marginBottom: "0.5rem" }}
                    label="Authentication Type"
                  >
                    <Select
                      ref={authTypeRef}
                      placeholder="Select Authentication Type"
                      value={authtype}
                      onChange={(value) => {

                        setAuthtype(value)
                        setIsKeySecret(value == 2 ? false : value == 1 ? false : true)

                        setisAuthTypeKeySecret(value == 3 ? true : false);

                      }}
                      style={{ width: "100%" }}
                    >
                      <Option value={1}>API Key</Option>
                      <Option value={2}>Connection String</Option>
                      <Option value={3}>Key Secret</Option>
                    </Select>
                  </Form.Item>
                </Col>
                <Col span={24} sm={24} md={16} lg={12} xl={12}>
                  {/* API Key Name */}
                  <Form.Item
                    style={{ marginBottom: "0.5rem" }}
                    label={keyNamePlaceholder}
                  >
                    <Input
                      ref={apiKeyNameRef}
                      placeholder={keyNamePlaceholder}
                      value={msgserviceapikeyname}
                      onChange={(e) => setMsgserviceapikeyname(e.target.value)}
                    />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={32}>
                <Col span={24} sm={24} md={16} lg={12} xl={12}>
                  {/* API Key Value */}
                  <Form.Item
                    style={{ marginBottom: "0.5rem" }}
                    label={keyValuePlaceholder}
                  >
                    <Input
                      ref={apiKeyValue}
                      placeholder={keyValuePlaceholder}
                      value={apikeyvalue}
                      onChange={(e) => setAPikeyvalue(e.target.value)}
                    />
                  </Form.Item>
                </Col>

                <Col span={24} sm={24} md={16} lg={12} xl={12}>
                  {/* Toggle */}
                  <div style={{ position: 'relative', top: '34px' }}>
                    <label style={{ marginRight: 10 }}>Set as Default</label>
                    <Switch checked={isActive} onChange={handleToggleChange} />
                    <span style={{ marginLeft: 10 }}>{isActive ? "Yes" : "No"}</span>
                  </div>
                </Col>

                {(isAuthTypeKeySecret || isKeySecret) && (
                  <Col span={24} sm={24} md={16} lg={12} xl={12}>
                    {/* Private Key (Only for MailJet) */}
                    <Form.Item
                      label="Private Key"
                    >
                      <Input
                        ref={privateKeyValue}
                        placeholder="Private Key"
                        value={privatekey}
                        onChange={(e) => setPrivatekeyvalue(e.target.value)}
                      />
                    </Form.Item>
                  </Col>
                )
                }
                {/* Toggle */}

              </Row>

            </Form>
          </Spin>


          {/* Modal */}
          {isModalOpen && (
            <MessageModal
              message={"Temp"}
              color={"modalColor" as "green" | "red" | "blue" | "yellow"}
              onClose={handleCloseModal}
            />
          )}
        </div>
      </div>


      {contextHolder}

    </div>
  );
};

export default CreateConnections;
