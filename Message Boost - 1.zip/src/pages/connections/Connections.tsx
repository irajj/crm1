import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
// import { FaPlus, FaTrash } from "react-icons/fa";
import { Table, Button, Flex, Modal, message } from "antd";
import Title from "antd/es/typography/Title";
import axios from "axios";
import "./Connection.css";
import { Plus } from "lucide-react";
import { createStyles } from "antd-style";
// import { Tooltip } from 'antd';
import { Power } from 'lucide-react'; // or use Pause/SlashCircle if more appropriate
import { Tag } from "antd";
import Search, { SearchProps } from "antd/es/input/Search";
// import type { TableColumnsType, TableProps } from "antd";

const useStyle = createStyles(({ css, token }) => {
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-expect-error
  const { antCls } = token;
  return {
    customTable: css`
      ${antCls}-table {
        ${antCls}-table-container {
          ${antCls}-table-body,
          ${antCls}-table-content {
            scrollbar-width: thin;
            scrollbar-color: #eaeaea transparent;
            scrollbar-gutter: stable;
          }
        }
      }
    `,
  };
});

interface ConnectionRow {
  id: string;
  msgservicename: string;
  messagingservices: string;
  authtype: string;
  createdon: string;
  defaultconnection: string;
  statusLabel: string;
  createdOnFormatted: string;
}


const Connections: React.FC = () => {

  const { styles } = useStyle();
  const navigate = useNavigate();
  const [rows, setRows] = useState<ConnectionRow[]>([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [openDeleteModal, setOpenDeleteModal] = useState<boolean>(false);
  const [loading, setLoading] = useState(false);
  // const [currentPage, setCurrentPage] = useState(1);
  const [searchText, setSearchText] = useState("");
  // const [data, setData] = useState<DataType[]>([]);
  const [originalData, setOriginalData] = useState<ConnectionRow[]>([]);

  const handleDeactivate = async () => {
    setLoading(true);

    const skippedConnections: string[] = [];
    const failedConnections: string[] = [];
    let successCount = 0;

    try {
      for (const id of selectedRowKeys) {
        const connection = originalData.find((item) => item.id === id);
        if (!connection) continue;

        if (connection.defaultconnection === "Yes") {
          skippedConnections.push(connection.msgservicename);
          continue;
        }

        const payload = {
          id,
          status: 1,
          messagingservices: 1,
          authtype: 1,
        };

        try {
          const response = await fetch("https://emailboost.azurewebsites.net/api/messageingservice", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });

          if (!response.ok) {
            failedConnections.push(connection.msgservicename);
            console.error(`Failed to deactivate ${connection.msgservicename}`);
            continue;
          }

          successCount++;
        } catch (error) {
          failedConnections.push(connection.msgservicename);
          console.error(`Error deactivating ${connection.msgservicename}:`, error);
        }
      }

      // Final summary messages
      if (successCount > 0) {
        message.success(`${successCount} connection${successCount > 1 ? "s" : ""} deactivated successfully.`);
      }

      if (skippedConnections.length > 0) {
        message.warning(
          `Skipped default connection${skippedConnections.length > 1 ? "s" : ""}: ${skippedConnections.join(", ")}.`
        );
      }

      if (failedConnections.length > 0) {
        message.error(
          `Failed to deactivate: ${failedConnections.join(", ")}. Please try again.`
        );
      }

      setSelectedRowKeys([]);
      fetchData(); // Refresh data
    } catch (error: any) {
      message.error("Unexpected error during deactivation. Please contact support.");
      console.error("Unexpected error:", error);
    } finally {
      setLoading(false);
    }
  };


  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        "https://emailboost.azurewebsites.net/api/messageingservice"
      );
      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const data = await response.json();

      const updatedRows = data?.data
        .filter((item: any) => item.status === 0) // Exclude inactive records
        .map((item: any) => ({
          id: item.id,
          msgservicename: item.msgservicename,
          messagingservices: item.messagingservices === 1 ? "SendGrid" : "AWS",
          authtype: item.authtype === 1 ? "API Key" : item.authtype === 2 ? "Connection String" : "Key Secret",
          defaultconnection: item.defaultconnection === true ? "Yes" : "No",
          statusLabel: item.statusLabel,
          createdon: item.createdOnFormatted,
        }));

      setRows(updatedRows);
      setOriginalData(updatedRows);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      setError((error as Error).message);
    }
  };

  const onSearch: SearchProps["onSearch"] = (value) => {

    setSearchText(value.trim());
    // setCurrentPage(1); // Reset to page 1 when searching
  };

  const showConfirm = () => {
    Modal.confirm({
      title: 'Are you sure you want to deactivate the selected records?',
      okText: 'Yes, Deactivate',
      okType: 'danger',
      cancelText: 'Cancel',
      onOk() {
        return handleDeactivate();
      },
    });
  };

  useEffect(() => {

    fetchData();
  }, []);

  useEffect(() => {
    if (searchText) {

      const filteredData = originalData.filter((item) =>
        item.msgservicename?.toLowerCase().includes(searchText.toLowerCase())
      );
      setRows(filteredData);
    } else {
      setRows(originalData);
    }
  }, [searchText, originalData]);

  const handleRowClick = (record: ConnectionRow) => {
    navigate(`/createconnections/${record.id}`);
  };

  const confirmDelete = async () => {
    try {
      await Promise.all(
        selectedRowKeys.map(async (id) => {
          await axios.delete(
            `https://emailboost.azurewebsites.net/api/messagetemplate/${id}`
          );
        })
      );
      setRows((prevRows) =>
        prevRows.filter((row) => !selectedRowKeys.includes(row.id))
      );
      message.success("Templates deleted successfully!");
    } catch (error) {
      console.error("Failed to delete templates", error);
      message.error("Failed to delete templates.");
    }
    setOpenDeleteModal(false);
    setSelectedRowKeys([]);
  };

  if (error) return <div>Error: {error}</div>;

  // const columns = [
  //   { title: "Name", dataIndex: "msgservicename", key: "msgservicename" },
  //   {
  //     title: "Service",
  //     dataIndex: "messagingservices",
  //     key: "messagingservices",
  //   },
  //   { title: "Authentication Type", dataIndex: "authtype", key: "authtype" },
  //   { title: "Is Default", dataIndex: "defaultconnection", key: "defaultconnection" },
  //   {
  //     title: "Status",
  //     dataIndex: "statusLabel",
  //     key: "statusLabel",
  //     render: (text: string) => (
  //       <Tag color={text === "Active" ? "green" : "red"}>{text}</Tag>
  //     ),
  //   },
  //   { title: "Created on", dataIndex: "createdon", key: "createdon" },
  // ];

  const columns = [
    {
      title: "Name",
      dataIndex: "msgservicename",
      key: "msgservicename",
      sorter: (a: ConnectionRow, b: ConnectionRow) => a.msgservicename.localeCompare(b.msgservicename),
    },
    {
      title: "Service",
      dataIndex: "messagingservices",
      key: "messagingservices",
      sorter: (a: ConnectionRow, b: ConnectionRow) => a.messagingservices.localeCompare(b.messagingservices),
    },
    {
      title: "Authentication Type",
      dataIndex: "authtype",
      key: "authtype",
      sorter: (a: ConnectionRow, b: ConnectionRow) => a.authtype.localeCompare(b.authtype),
    },
    {
      title: "Is Default",
      dataIndex: "defaultconnection",
      key: "defaultconnection",
      sorter: (a: ConnectionRow, b: ConnectionRow) => a.defaultconnection.localeCompare(b.defaultconnection),
      render: (text: string) => (
        <Tag color={text === "Yes" ? "green" : "red"}>{text}</Tag>
      ),
    },
    {
      title: "Status",
      dataIndex: "statusLabel",
      key: "statusLabel",
      sorter: (a: ConnectionRow, b: ConnectionRow) => a.statusLabel.localeCompare(b.statusLabel),
      render: (text: string) => (
        <Tag color={text === "Active" ? "green" : "red"}>{text}</Tag>
      ),
    },
    {
      title: "Created on",
      dataIndex: "createdon",
      key: "createdon",
      sorter: (a:ConnectionRow, b:ConnectionRow) => {
        const dateA = new Date(a.createdon).getTime() || 0;
        const dateB = new Date(b.createdon).getTime() || 0;
        return dateA - dateB;
      }

    },
  ];


  return (
    <div className="connections-container">
      <div
        className="menubar"
        style={{
          borderBottom: "1px solid #dde4e9",
          // boxShadow: "1px 1px 15px #dde4e9",
          padding: "0.4rem",
          background: "white",
          position: "sticky",
          top: "48px",
          zIndex: "2",
        }}
      >
        <Flex style={{ gap: '8px' }}>
          <Link to="/createconnections">
            <Button
              color="default" variant="filled" size="middle">
              <Plus size={16} />
              New
            </Button>
          </Link>
          {/* <Button
            color="default" variant="filled" size="middle"
            type="default"
            disabled={selectedRowKeys.length === 0}>
            {<Power size={16} />}
            Deactivate
          </Button> */}
          <Button
            type="default"
            icon={<Power size={16} />}
            disabled={selectedRowKeys.length === 0}
            loading={loading}
            onClick={showConfirm}
          >
            Deactivate
          </Button>
        </Flex>
      </div>

      <div
        style={{
          padding: "1rem",
          background: "white",
        }}
      >
        <Flex
          justify="space-between"
          align="center"
          style={{ marginBottom: "1rem" }}
        >
          <Title level={4}>Connections</Title>


          <Flex gap="middle" justify="end" align="center">
            <Search
              placeholder="Search connections"
              onSearch={onSearch}
              style={{ width: 200 }}
            />
          </Flex>
        </Flex>


        <Table
          className={styles.customTable}
          columns={columns}
          dataSource={rows}
          rowKey="id"
          loading={loading}
          pagination={{ pageSize: 5 }}
          // pagination={{
          //   current: currentPage,
          //   pageSize: pageSize,
          //   total: totalCount,
          //   showSizeChanger: true,
          //   pageSizeOptions: ["10", "20", "50", "100"],
          // }}
          showSorterTooltip={{ target: "sorter-icon" }}
          rowSelection={{
            selectedRowKeys,
            onChange: (selectedKeys) =>
              setSelectedRowKeys(selectedKeys as string[]),
          }}
          onRow={(record) => ({
            onDoubleClick: () => handleRowClick(record),
          })}
        />
      </div>
      <Modal
        title="Delete Confirmation"
        open={openDeleteModal}
        onOk={confirmDelete}
        onCancel={() => setOpenDeleteModal(false)}
        okText="Delete"
        cancelText="Cancel"
      >
        <p>Are you sure you want to delete the selected templates?</p>
      </Modal>
    </div>
  );
};

export default Connections;
