import React, { useEffect, useState, useRef } from "react";
import {
  Button,
  Flex,
  Form,
  Input,
  Select,
  notification,
  Spin,
  Row,
  Col,
} from "antd";
import GrapeJs from "./GrapeJs/GrapeJs";
import { ArrowLeft, Save } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import Title from "antd/es/typography/Title";
import { useNavigate } from "react-router-dom";

const onSearch = (value: string) => {
  console.log("search:", value);
};

const NewTemplates: React.FC = () => {
  const navigate = useNavigate();
  // const location = useLocation();

  let { id } = useParams();
  const [form] = Form.useForm();
  const [selectedEntityName, setSelectedEntityName] = useState("");
  const [selectedMessageType, setSelectedMessageType] = useState("Email");
  const [emailTemplateName, setEmailTemplateName] = useState("");
  const [emailSubject, setEmailSubject] = useState("");
  const [emailBody, setEmailBody] = useState("");
  const [api, contextHolder] = notification.useNotification();
  const [loading, setLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [hasFetched, setHasFetched] = useState(false);
  const isNotificationOpen = useRef(false);
  // const [isReadOnly, setIsReadOnly] = useState(false);

  // const [isPageLoading, setIsPageLoading] = useState(true);
  // const [isSaving, setIsSaving] = useState(false);
  // const [recordid, setId] = useState<string | null>(null);

  const validateFields = () => {
    if (!emailTemplateName) {
      showSingleWarning(
        "warning",
        "",
        "Please fill in the Template Name field!"
      );
      return false;
    }
    if (!selectedEntityName) {
      showSingleWarning("warning", "", "Please select a Template For field!");

      return false;
    }
    if (!emailSubject) {
      showSingleWarning("warning", "", "Please fill in the Subject field!");

      return false;
    }
    if (!emailBody) {
      showSingleWarning("warning", "", `Email Editor Can't be null!`);

      return false;
    }
    // if (!selectedMessageType) {
    //   showSingleWarning('warning', '', `Please fill in the MessageType!`);
    //   return false;
    // }
    else {
      console.log(selectedMessageType);
      return true;
    }
  };

  const showSingleWarning = (
    type: string,
    message: string,
    description: string
  ) => {
    notification.destroy(); // instantly closes any existing ones

    if (isNotificationOpen.current) return;

    isNotificationOpen.current = true;

    api.open({
      message: message,
      description,
      type: type as "success" | "info" | "warning" | "error",
      // duration, // in seconds
      duration: 2,
      closable: true,
      onClose: () => {
        isNotificationOpen.current = false;
      },
    });

    // Fallback in case onClose isn't triggered (very rare)
    // setTimeout(() => {
    //   isNotificationOpen.current = false;
    // }, duration * 1000 + 100); // small buffer
  };

  const handleSave = async (status: number) => {

    // if (isSaving || isDisabled) return;
    console.log("Button clicked with status:", status);

    if (!validateFields()) {
      return;
    }

    try {
      setLoading(true);
      // setIsSaving(true);
      if (id === "new") {
        id = undefined;
      }

      const payload = {
        id: id || null,
        emailtemplatename: form.getFieldValue("templatename").toLowerCase(),
        selectedentityname: form.getFieldValue("templatefor").toLowerCase(),
        emailsubject: form.getFieldValue("subject"),
        emailbody: emailBody,
        // status: status || 0,
        messagetype: form.getFieldValue("messagetype"),
        isactive: status == 0 ? true : false
      };
      console.log(payload);
      const url = `https://emailboost.azurewebsites.net/api/messagetemplate`;

      const method = "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error("Failed to save template");
      }
      console.log("Template saved successfully!");
      setLoading(false);
      const recordid = await response.json();

      navigate(`/templates/${recordid.data}`);
    } catch (error) {
      setLoading(false);
      console.error("Error saving template:", error);
    } finally {
      setLoading(false);

      // setIsSaving(false);
    }
  };

  const handleSaveAsDraft = async () => {
    await handleSave(0);

    // setIsReadOnly(false);
  };

  const handleSaveAndPublish = async () => {
    await handleSave(1); // save with status 1
    // setIsReadOnly(true); // set form as read-only after publish
  };

  // const handleSaveonly = async () => {
  //   if (!validateFields()) {
  //     return;
  //   }
  //   try {
  //     setLoading(true);
  //     // setIsSaving(true);
  //     if (id === "new") {
  //       id = undefined;
  //     }

  //     const payload = {
  //       id: id || null,
  //       emailtemplatename: form.getFieldValue("templatename").toLowerCase(),
  //       selectedentityname: form.getFieldValue("templatefor").toLowerCase(),
  //       emailsubject: form.getFieldValue("subject"),
  //       emailbody: emailBody,
  //       status: 0,
  //       messagetype: form.getFieldValue("messagetype"),
  //     };
  //     console.log(payload);
  //     const url = `https://emailboost.azurewebsites.net/api/messagetemplate`;

  //     const method = "POST";

  //     const response = await fetch(url, {
  //       method,
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify(payload),
  //     });

  //     if (!response.ok) {
  //       throw new Error("Failed to save template");
  //     }
  //     console.log("Template saved successfully!");
  //     setLoading(false);
  //     const recordid = await response.json();
  //     // navigate(`/template/${recordid.data}`);
  //     navigate(`/templates/${recordid.data}`, { replace: true });
  //   } catch (error) {
  //     setLoading(false);
  //     console.error("Error saving template:", error);
  //   } finally {
  //     setLoading(false);

  //     // setIsSaving(false);
  //   }
  // };

  // const handleSaveAndClose = async () => {
  //   if (!validateFields()) {
  //     return;
  //   }
  //   try {
  //     setLoading(true);
  //     // setIsSaving(true);
  //     if (id === "new") {
  //       id = undefined;
  //     }

  //     const payload = {
  //       id: id || null,
  //       emailtemplatename: form.getFieldValue("templatename").toLowerCase(),
  //       selectedentityname: form.getFieldValue("templatefor").toLowerCase(),
  //       emailsubject: form.getFieldValue("subject"),
  //       emailbody: emailBody,
  //       status: 0,
  //       messagetype: form.getFieldValue("messagetype"),
  //     };
  //     console.log(payload);
  //     const url = `https://emailboost.azurewebsites.net/api/messagetemplate`;

  //     const method = "POST";

  //     const response = await fetch(url, {
  //       method,
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify(payload),
  //     });

  //     if (!response.ok) {
  //       throw new Error("Failed to save template");
  //     }
  //     console.log("Template saved successfully!");
  //     setLoading(false);
  //     // const recordid = await response.json();
  //     navigate(`/templates/`);
  //   } catch (error) {
  //     setLoading(false);
  //     console.error("Error saving template:", error);
  //   } finally {
  //     setLoading(false);

  //     // setIsSaving(false);
  //   }
  // };

  useEffect(() => {
    const fetchTemplate = async () => {
      try {
        setIsFetching(true);
        // setIsPageLoading(true);

        const response = await fetch(
          `https://emailboost.azurewebsites.net/api/messagetemplate/${id}`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch template");
        }
        const data = await response.json();

        form.setFieldValue("templatename", data.data.emailtemplatename);
        form.setFieldValue("templatefor", data.data.selectedentityname);
        form.setFieldValue(
          "messagetype",
          data.data.messagetype == "496290001"
            ? "SMS"
            : data.data.messagetype == "496290000"
              ? "Email"
              : "WhatsApp"
        );
        form.setFieldValue("subject", data.data.emailsubject);
        setEmailSubject(data.data.emailsubject);
        setEmailTemplateName(data.data.emailtemplatename);

        setSelectedEntityName(data.data.selectedentityname.replace(/^./, (c: string) => c.toUpperCase()));
        setSelectedMessageType(data.data.messagetype);
        setEmailBody(data.data.emailbody);

        // if (data.data.status == 1) {
        //   setIsReadOnly(true);
        // } else {
        //   setIsReadOnly(false);
        // }
        setHasFetched(true);
      } catch (error) {
        console.error("Error fetching template:", error);
      } finally {
        setIsFetching(false); // stop fetch loading
        // setIsPageLoading(false);
      }
    };

    if (id) {
      fetchTemplate();
    } else {
      setEmailTemplateName("");
      setSelectedEntityName("");
      setEmailSubject("");
      setEmailBody("");
    }
  }, [id, form]);

  const getSpinTip = () => {
    if (!hasFetched && id) return "Loading..."; // Initial load with existing record
    if (loading || isFetching) {
      return id ? "Updating..." : "Creating..."; // Saving either new or existing
    }
    return ""; // or null/undefined if no spinTip is needed
  };

  return (
    <div className="new-template-container">
      <div
        className="menubar"
        style={{
          borderBottom: "1px solid #dde4e9",
          padding: "0.4rem",
          background: "white",
          position: "sticky",
          top: "48px",
          zIndex: "2",
        }}
      >
        <Flex gap={"0.2rem"}>
          <Link to="/templates">
            <Button color="default" variant="link" size="middle">
              <ArrowLeft size={16} />
            </Button>
          </Link>

          {/* <Button
            color="default"
            variant="filled"
            size="middle"
            onClick={() => {
              form.resetFields();
              setEmailBody("");
              setIsReadOnly(false);

              // Only navigate if not already on the new template page
              if (location.pathname !== "/template/new") {
                navigate("/template/new");
              }
            }}
          >
            <Plus size={16} />
            New
          </Button> */}

          {/* <Button
            style={{ display: id != undefined ? "none" : "flex" }}
            color="default"
            variant="filled"
            size="middle"
            onClick={handleSaveonly}
          >
            <Save size={16} />
            Save
          </Button> */}

          {/* <Button
            style={{ display: id != undefined ? "none" : "flex" }}
            color="default"
            variant="filled"
            size="middle"
            onClick={handleSaveAndClose}
          >
            <Save size={16} />
            Save & Close
          </Button> */}

          <Button

            color="default"
            variant="filled"
            size="middle"
            onClick={handleSaveAsDraft}
          >
            <Save size={16} />
            Save as draft
          </Button>
          <Button

            // disabled={isReadOnly}
            color="default"
            variant="filled"
            size="middle"
            onClick={handleSaveAndPublish}
          >
            <Save size={16} />
            Save and publish
          </Button>
        </Flex>
      </div>

      <Spin spinning={loading || isFetching} tip={getSpinTip()}>
        <div
          style={{
            padding: "1rem",
            background: "white",
          }}
        >
          {id == undefined && (
            <Flex justify="space-between">
              <Title level={4}>New Template</Title>
            </Flex>
          )}
          {/* 
          {isReadOnly && (
            <Alert
              message="This form is read-only"
              description="This record has been published and is now inactive. Editing is disabled."
              type="info"
              showIcon
              style={{ marginBottom: 24 }}
            />
          )} */}

          <Form layout="vertical" form={form}>
            <Row gutter={16}>
              {/* template name */}
              <Col span={24} sm={24} md={12} lg={8} xl={8}>
                <Form.Item
                  style={{ marginBottom: "0.5rem" }}
                  label="Template Name"
                  name="templatename"
                  rules={[
                    { required: true, message: "Please enter a template name" },
                  ]}
                >
                  <Input
                    // disabled={isReadOnly}
                    placeholder="Enter template name"
                    onChange={(e) => {
                      // This will pause execution in the browser dev tools
                      setEmailTemplateName(e.target.value);
                    }}
                  />
                </Form.Item>
              </Col>

              {/* template for*/}
              <Col span={24} sm={24} md={12} lg={8} xl={8}>
                <Form.Item
                  style={{ marginBottom: "0.5rem" }}
                  label="Template For"
                  name="templatefor"
                  rules={[
                    { required: true, message: "Please select a template" },
                  ]}
                >
                  <Select
                    // disabled={isReadOnly}
                    showSearch
                    placeholder="Select a Template"
                    optionFilterProp="label"
                    onSearch={onSearch}
                    style={{ width: "100%" }}
                    onChange={(value) => setSelectedEntityName(value)}
                    options={[
                      {
                        value: "contact",
                        label: "contact",
                      },
                      {
                        value: "lead",
                        label: "lead",
                      },
                      {
                        value: "account",
                        label: "account",
                      },
                    ]}
                  />
                </Form.Item>
              </Col>

              {/* message type */}
              <Col span={24} sm={24} md={12} lg={8} xl={8}>
                <Form.Item
                  style={{ marginBottom: "0.5rem" }}
                  label="Message Type"
                  name="messagetype"
                  initialValue="Email"
                  rules={[
                    { required: true, message: "Please select a template" },
                  ]}
                >
                  <Select
                    disabled
                    showSearch
                    placeholder="Select a Message Type"
                    onChange={(value) => setSelectedMessageType(value)}
                    optionFilterProp="label"
                    onSearch={onSearch}
                    style={{ width: "100%" }}
                    options={[
                      {
                        value: "Email",
                        label: "Email",
                      },
                      // {
                      //   value: "SMS",
                      //   label: "SMS",
                      // },
                      // {
                      //   value: "WhatsApp",
                      //   label: "WhatsApp",
                      // },
                    ]}
                  />
                </Form.Item>
              </Col>

              {/* subject */}
              <Col span={24} sm={24} md={12} lg={8} xl={8}>
                <Form.Item
                  style={{ marginBottom: "0.5rem" }}
                  label="Subject"
                  name="subject"
                  rules={[{ required: true, message: "Please enter subject" }]}
                >
                  <Input
                    // disabled={isReadOnly}
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                    placeholder="Enter Subject"
                  />
                </Form.Item>
              </Col>
            </Row>
          </Form>

          <GrapeJs
            emailTemplateName={emailTemplateName}
            setEmailBody={(body) => {

              console.log(body);
              setEmailBody(body);
            }}
            id={id}
            emailBody={emailBody}
          // readOnly={isReadOnly}
          />
          {contextHolder}
        </div>
      </Spin>
    </div>
  );
};

export default NewTemplates;
