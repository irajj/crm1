//31-05-2025
// Author: Abhishek
// Made ui changes
//  - modified topbar design and made spacing changes like margins and padding

import { Button, Flex, Table, Tag, Modal, message } from "antd";
import type { TableColumnsType, TableProps } from "antd";
import { TableRowSelection } from "antd/es/table/interface";
import Title from "antd/es/typography/Title";
import dayjs from "dayjs";
import { Plus, Trash } from "lucide-react";
import { useEffect, useState, useCallback } from "react";
import apiService from "../../services/ApiService";
import { Link } from "react-router-dom";
import Search, { SearchProps } from "antd/es/input/Search";
import "antd/dist/reset.css";
import "./Templates.css";

// import { createStyles } from "antd-style";
import { useNavigate } from "react-router-dom";

interface DataType {
  selectedentityname: string;
  statusLabel: string;
  key: string;
  emailtemplatename: string;
  msgsetupmessagestatuslable: string;
  id: string;
  name: string;
  date: string;
  createdon: string;
  createdOnFormatted: string;
  createdby: {
    EntityLogicalName: string;
    id: string;
    name: string;
  };
  isactive: boolean;
}

// const statusColors: Record<string, string> = {
//   Active: "green",
//   "In Progress": "orange",
//   Scheduled: "yellow",
//   Completed: "cyan",
//   Inactive: ""
// };

const columns: TableColumnsType<DataType> = [
  {
    title: "Template Name",
    dataIndex: "emailtemplatename",
    sorter: (a, b) =>
      (a.emailtemplatename || "").localeCompare(b.emailtemplatename || ""),
    sortDirections: ["ascend", "descend"],
  },
  {
    title: "Template For",
    dataIndex: "selectedentityname",
    sorter: (a, b) =>
      (a.selectedentityname || "").localeCompare(b.selectedentityname || ""),
    sortDirections: ["ascend", "descend"],
  },
  // {
  //   title: "Status",
  //   dataIndex: "statusLabel",
  //   sorter: (a, b) =>
  //     (a.statusLabel || "").localeCompare(
  //       b.statusLabel || ""
  //     ),
  //   sortDirections: ["ascend", "descend"],
  //   render: (status) => (
  //     <Tag color={statusColors[status] || "default"}>{status}</Tag>
  //   ),
  // },
  {
    title: "Status",
    dataIndex: "isactive",
    key: "isactive",
    sorter: (a, b) => Number(a.isactive) - Number(b.isactive),
    render: (text: boolean) => (
      <Tag color={text === true ? "green" : "red"}>{text == true ? "Draft" : "Published"}</Tag>
    ),
  },
  {
    title: "Created On",
    dataIndex: "createdOnFormatted",
    render: (text) => (dayjs(text).isValid() ? text : "N/A"), // Safe fallback for invalid date
    sorter: (a, b) =>
      (dayjs(a.createdOnFormatted).isValid()
        ? dayjs(a.createdOnFormatted).valueOf()
        : 0) -
      (dayjs(b.createdOnFormatted).isValid()
        ? dayjs(b.createdOnFormatted).valueOf()
        : 0),
    sortDirections: ["ascend", "descend"],
  },
  {
    title: "Created by",
    dataIndex: ["createdby", "name"],
    sorter: (a, b) =>
      (a.createdby?.name || "").localeCompare(b.createdby?.name || ""),
    sortDirections: ["ascend", "descend"],
  },
];

const Templates = () => {
  const navigate = useNavigate();
  const [data, setData] = useState<DataType[]>([]);
  const [originalData, setOriginalData] = useState<DataType[]>([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [isInitialLoad, setIsInitialLoad] = useState(true);

  const fetchData = useCallback(
    async (page: number, count: number) => {
      setLoading(true);
      try {
        const endpoint = isInitialLoad
          ? `/messagetemplate`
          : `/messagetemplate?PageNumber=${page}&count=${count}`;

        const response = await apiService.get<any>(endpoint);


        const items = isInitialLoad ? response.data : response.data?.items;

        const total = isInitialLoad
          ? Array.isArray(response.data)
            ? response.data.length
            : 0
          : response.data?.totalCount || 0;

        // below code is commented bu abhishek to fix data not showing
        // if (!Array.isArray(items)) {
        //     setData([]);
        //     setOriginalData([]);
        //     setTotalCount(0);
        //     return;
        // }
        const mappedData = items.map((item: any) => ({
          ...item,
          key: item.id,
          createdOnFormatted: dayjs(item.createdon).format("YYYY-MM-DD HH:mm"),
        }));
        setData(mappedData);
        setOriginalData(mappedData);
        setTotalCount(total);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    },
    [isInitialLoad]
  );

  const handleDelete = async () => {
    setLoading(true);

    try {
      const failedDeletes: string[] = [];

      for (const id of selectedRowKeys) {
        const connection = originalData.find(item => item.id === id);
        if (!connection) continue;

        try {
          const response = await fetch(`https://emailboost.azurewebsites.net/api/messagetemplate/${id}`, {
            method: "DELETE",
          });

          if (!response.ok) {
            console.error(`Failed to delete record with ID: ${id}`);
            failedDeletes.push(String(id));
          }
        } catch (error) {
          console.error(`Error deleting record with ID: ${id}`, error);
          failedDeletes.push(String(id));
        }
      }

      if (failedDeletes.length > 0) {
        message.warning(`${failedDeletes.length} record(s) failed to delete.`);
      } else {
        message.success("Record(s) deleted successfully.");
      }

      setSelectedRowKeys([]);

      const response = await apiService.get<any>(`/messagetemplate`);
      const items = response.data;
      const total = isInitialLoad
        ? Array.isArray(response.data)
          ? response.data.length
          : 0
        : response.data?.totalCount || 0;

      // below code is commented bu abhishek to fix data not showing
      // if (!Array.isArray(items)) {
      //     setData([]);
      //     setOriginalData([]);
      //     setTotalCount(0);
      //     return;
      // }
      const mappedData = items.map((item: any) => ({
        ...item,
        key: item.id,
        createdOnFormatted: dayjs(item.createdon).format("YYYY-MM-DD HH:mm"),
      }));
      setData(mappedData);
      setOriginalData(mappedData);
      setTotalCount(total);
    } catch (error) {
      console.error("Unexpected error during deletion:", error);
      message.error("Unexpected error during deletion. Please contact support.");
    } finally {
      setLoading(false);
    }
  };





  const showConfirm = () => {
    Modal.confirm({
      title: 'Are you sure you want to deactivate the selected records?',
      okText: 'Yes, Delete',
      okType: 'danger',
      cancelText: 'Cancel',
      onOk() {
        return handleDelete();
      },
    });
  };

  useEffect(() => {

    const loadData = async () => {

      await fetchData(currentPage, pageSize);
      if (isInitialLoad) setIsInitialLoad(false);
    };
    loadData();
  }, [currentPage, pageSize, fetchData, isInitialLoad]);

  useEffect(() => {
    if (searchText) {
      const filteredData = originalData.filter((item) =>
        item.emailtemplatename?.toLowerCase().includes(searchText.toLowerCase())
      );
      setData(filteredData);
    } else {
      setData(originalData);
    }
  }, [searchText, originalData]);

  const onSelectChange = (newSelectedRowKeys: React.Key[]) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };

  const rowSelection: TableRowSelection<DataType> = {
    selectedRowKeys,
    onChange: onSelectChange,
  };

  // const hasSelected = selectedRowKeys.length > 0;

  const onSearch: SearchProps["onSearch"] = (value) => {

    setSearchText(value.trim());
    setCurrentPage(1); // Reset to page 1 when searching
  };

  const handleTableChange: TableProps<DataType>["onChange"] = (pagination) => {
    if (pagination.current !== currentPage) {
      setCurrentPage(pagination.current!);
    }
    if (pagination.pageSize !== pageSize) {
      setPageSize(pagination.pageSize!);
      setCurrentPage(1);
    }
  };
  const handleRowDoubleClick = (record: DataType) => {
    console.log(record);
    navigate(`/templates/${record.id}`);
  };

  return (
    <Flex vertical style={{ height: "100%" }}>
      <div
        className="menubar"
        style={{
          borderBottom: "1px solid #dde4e9",
          // boxShadow: "1px 1px 15px #dde4e9",
          padding: "0.4rem",
          background: "white",
          position: "sticky",
          top: "48px",
          zIndex: "2",
        }}
      >
        <Flex gap={"0.2rem"}>
          <Link to="new">
            <Button color="default" variant="filled" size="middle">
              <Plus size={16} />
              New
            </Button>
          </Link>
          <Button
            size="middle"
            color="danger"
            variant="text"
            disabled={selectedRowKeys.length === 0}
            onClick={showConfirm}
          >
            <Trash size={16} />
            Delete
          </Button>
        </Flex>
      </div>
      <Flex
        vertical
        style={{
          padding: "1rem",
          background: "white",
          flexGrow: "1",
        }}
      >
        <Flex
          justify="space-between"
          align="center"
          style={{ marginBottom: "1rem" }}
        >
          <Title level={4}>Templates</Title>

          <Flex gap="middle" justify="end" align="center">
            <Search
              placeholder="Search templates"
              onSearch={onSearch}
              style={{ width: 200 }}
            />
          </Flex>
        </Flex>

        <Table<DataType>
          style={{ flexGrow: 1 }}
          // className={styles.customTable}
          columns={columns}
          dataSource={data}
          onChange={handleTableChange}
          loading={loading}
          rowSelection={rowSelection}
          onRow={(record: DataType) => ({
            onDoubleClick: () => handleRowDoubleClick(record),
          })}
          // below line is added by abhishek to make the height of table fill the screen
          scroll={{ y: "calc(100vh - 299px )", x: "none" }}
          pagination={{
            current: currentPage,
            pageSize: pageSize,
            total: totalCount,
            showSizeChanger: true,
            pageSizeOptions: ["10", "20", "50", "100"],
          }}
          showSorterTooltip={{ target: "sorter-icon" }}
        />
      </Flex>
    </Flex>
  );
};

export default Templates;
