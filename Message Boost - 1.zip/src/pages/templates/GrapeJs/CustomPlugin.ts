import { Editor } from "@grapesjs/studio-sdk-plugins/dist/types.js";

const CustomPlugin = (editor: Editor) => {
    console.log("Registering custom plugin...");
    
    const panelExists = editor.Panels.getPanel("views");
    if (!panelExists) {
        console.warn("Panel 'views' not found, creating it manually...");
        editor.Panels.addPanel({ id: "views", buttons: [] });
    }

    editor.Panels.addButton("views", {
        id: "open-popup",
        className: "fa fa-window-maximize",
        command: "open-popup-command",
        attributes: { title: "Open Popup" },
    });

    editor.Commands.add("open-popup-command", {
        run(editor, sender) {
            sender?.set("active", false);
            console.log("Popup command triggered!");
            const event = new CustomEvent("openGrapesPopup");
            window.dispatchEvent(event);
        },
    });

};

export default CustomPlugin;
