import React, { useEffect, useState, useRef, useCallback } from "react";
import StudioEditor from "@grapesjs/studio-sdk/react";
import "@grapesjs/studio-sdk/style";
import CustomPlugin from "./CustomPlugin";

import MergeFieldModal from "./../../../Components/Modals/MergeFieldModal";

// Define props interface for type safety
interface OverviewProps {
    emailTemplateName: string;
    setEmailBody: (body: string) => void;
    emailBody: string;
    id?: string | null;
    templateName?: string;
    readOnly?: boolean; // ✅ Add this prop

}

const Overview: React.FC<OverviewProps> = ({
    emailTemplateName,
    setEmailBody,
    emailBody,
    id,
    // readOnly
}) => {

    // const [storeTemplate, setStoreTemplate] = useState<string>(emailTemplateName);
    const [projectData, setProjectData] = useState<any>(null); // Can be better typed based on the structure of `projectData`
    // //@ts-ignore
    // const [editorReady, setEditorReady] = useState<boolean>(false);
    const [showModal, setShowModal] = useState<boolean>(false);
    const editorRef = useRef<any>(null); // Type can be improved if you know the editor's type

    // Fetch the email template by id when reopening the record
    const fetchEmailTemplateById = useCallback(async (templateId: string) => {
        try {

            const response = await fetch(
                `https://emailboost.azurewebsites.net/api/messagetemplate/${templateId}`
            );
            if (response.ok) {
                const data = await response.json();
                return data?.data?.emailbody || "<p>No content available</p>"; // Assuming this is where the saved HTML content is returned
            } else {
                console.error("Failed to fetch the email template:", response.status);
                return null;
            }
        } catch (error) {
            console.error("Error fetching email template:", error);
            return null;
        }
    }, []);




    useEffect(() => {

        // Listen for the event triggered by the GrapesJS button
        const handlePopup = () => setShowModal(true);
        window.addEventListener("openGrapesPopup", handlePopup);

        const loadTemplate = async () => {
            
            let contentToLoad = emailBody; // Default to the passed emailBody

            // Fetch the saved template content if we have an id
            if (id) {
                const savedContent = await fetchEmailTemplateById(id);
                if (savedContent) {
                    contentToLoad = savedContent;
                }
            }

            if (contentToLoad) {

                setProjectData({
                    pages: [{ name: "body", component: contentToLoad }],
                });

            } else {

                // Fallback to no content available if no body exists
                setProjectData({
                    pages: [{ name: "body", component: "<p>No content available</p>" }],
                });
            }

            // setStoreTemplate(emailTemplateName || "New Template");
        };



        loadTemplate();

        return () => {
            window.removeEventListener("openGrapesPopup", handlePopup);
        };
    }, [id, emailTemplateName, emailBody, fetchEmailTemplateById]);


    // async (): Promise<any> => {
    //     return new Promise((resolve) => {
    //         const checkEditor = () => {
    //             if (editorRef.current?.editor) {
    //                 resolve(editorRef.current.editor);
    //             } else {
    //                 setTimeout(checkEditor, 100); // Retry after 100ms if editor is not ready
    //             }
    //         };
    //         checkEditor(); // Start checking for editor availability
    //     });
    // };

    // Assuming you're using grapesjs instance


    // const handleSave = useCallback(
    //     async (emaileditor: any) => {
    //         try {
    //             const fullHtml = `
    //     <html>
    //       <head>
    //         <style>${emaileditor.editor.getCss()}</style>
    //       </head>
    //       <body>
    //         ${emaileditor.editor.getHtml()}
    //       </body>
    //     </html>`;

    //             // const emailTemplateToSave = storeTemplate;

    //             // const payload = JSON.stringify({
    //             //     emailbody: fullHtml,
    //             //     id: id || null,
    //             //     emailTemplateName: emailTemplateToSave,
    //             // });

    //             // Make sure to add any logic for saving the payload here
    //         } catch (error) {
    //             console.error("Error saving project:", error);
    //         }
    //     },
    //     [id, storeTemplate, editorReady]
    // );

    // Assuming you're using grapesjs instance
    // useEffect(() => {
    //     
    //     const editor = editorRef.current;

    //     // Make sure editor is defined and has required methods
    //     if (
    //         editor &&
    //         typeof editor.getHtml === "function" &&
    //         typeof editor.setComponents === "function"
    //     ) {
    //         // Only update if the content is different
    //         if (emailBody !== editor.getHtml()) {
    //             editor.setComponents(emailBody || "");
    //             editor.setStyle("");
    //         }
    //     }
    // }, [emailBody]);

    // useEffect(() => {

    //     const editorInstance = editorRef.current;
    //     if (!editorInstance) return;

    //     try {
    //         const canvasBody = editorInstance.Canvas.getBody();
    //         const frameDoc = editorInstance.Canvas.getFrameEl().contentDocument;

    //         if (readOnly) {
    //             if (canvasBody) canvasBody.style.pointerEvents = 'none';
    //             if (frameDoc?.body) frameDoc.body.setAttribute('contenteditable', 'false');

    //             editorInstance.getModel().set('editable', false);

    //             // Optionally remove panels/buttons to lock UI
    //             editorInstance.Panels.getPanels().forEach((panel: any) => {
    //                 panel.set('buttons', []);
    //             });
    //             editorInstance.Panels.removePanel('options');
    //             editorInstance.Panels.removePanel('views');
    //         } else {
    //             if (canvasBody) canvasBody.style.pointerEvents = 'auto';
    //             if (frameDoc?.body) frameDoc.body.setAttribute('contenteditable', 'true');

    //             editorInstance.getModel().set('editable', true);

    //             // Re-add panels if needed (optional)
    //             editorInstance.Panels.addPanel({
    //                 id: 'options',
    //                 buttons: []
    //             });
    //             editorInstance.Panels.addPanel({
    //                 id: 'views',
    //                 buttons: []
    //             });
    //         }
    //     } catch (error) {
    //         console.error("Error updating readOnly mode dynamically:", error);
    //     }
    // }, [readOnly]);


    return (
        <div
            id="gjs"
            style={{ display: "flex", flexDirection: "column", height: "100vh" }}
        >
            {projectData && (
                <StudioEditor
                    ref={editorRef}
                    setEmailBody={setEmailBody}
                    options={{
                        licenseKey: "a424b71617804ad7a2fa40cdda9774cdd4cab6a26030432c90106bac08d815d2",
                        theme: "dark",
                        project: projectData,
                        storage: {
                            type: "self",
                            onSave: async () => {

                                // const editor = editorRef.current;
                                // if (editor) {
                                //     const html = editor.getHtml();
                                //     setEmailBody(html);
                                //     // handleSave(editor);
                                // }

                                const editor = editorRef.current;
                                if (editor) {
                                    const html = editor.getHtml();
                                    const css = editor.getCss();

                                    const fullHtml = `
                                    <html>
                                    <head>
                                    <style>${css}</style>
                                    </head>
                                    <body>
                                    ${html}
                                    </body>
                                    </html>`;

                                    setEmailBody(fullHtml);
                                }
                            },
                            onLoad: async () => {

                                return { project: projectData };
                            },
                            autosaveChanges: 100,
                            autosaveIntervalMs: 10000,
                        },
                        plugins: ["gjs-blocks-basic", CustomPlugin],

                        pluginOptions: {
                            "gjs-blocks-basic": { blocks: ["image"] },
                            imageUploader: (file: File) => {
                                const formData = new FormData();
                                formData.append("file", file);
                                return fetch("/upload", {
                                    method: "POST",
                                    body: formData,
                                })
                                    .then((res) => res.json())
                                    .then((data) => data.url)
                                    .catch((error) => console.error("Upload failed", error));
                            },
                        },
                    }}
                    onReady={(editorInstance) => {
                        editorRef.current = editorInstance;

                        // if (readOnly) {
                        //     try {
                        //         const canvasBody = editorInstance.Canvas.getBody();
                        //         const frameDoc = editorInstance.Canvas.getFrameEl().contentDocument;

                        //         if (canvasBody) canvasBody.style.pointerEvents = 'none';
                        //         if (frameDoc?.body) frameDoc.body.setAttribute('contenteditable', 'false');

                        //         editorInstance.getModel().set('editable', false);

                        //         // Remove panels/buttons to lock UI
                        //         editorInstance.Panels.getPanels().forEach((panel: any) => {
                        //             panel.set('buttons', []);
                        //         });
                        //         editorInstance.Panels.removePanel('options');
                        //         editorInstance.Panels.removePanel('views');
                        //     } catch (error) {
                        //         console.error("Error applying read-only mode:", error);
                        //     }
                        // }
                    }}
                />

            )}


            <div
                id="gjs"
            >
                <MergeFieldModal
                    editorRef={editorRef}
                    showModal={showModal}
                    setShowModal={setShowModal}
                />

            </div>
        </div>

    );
};

export default Overview;
