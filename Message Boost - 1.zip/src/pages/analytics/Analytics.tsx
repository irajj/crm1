// Modify by : Deven Bhimani
// Date: 13-08-2025

// Description: This file contains the Analytics component for the email marketing dashboard, including campaign statistics, visitor data, traffic sources, conversion rates, and bounce rates.
// event and campaign data are fetched from the API.
// build

//===================================================

// date:21-08-2025
// add campaign/{id} Api for the particular campaigns data.
// remove some unnecessary events in the Ui side.
// Add a loader when the data is loading or user change the campaign.
// Add a fallback data for the campaign data.
// merge the Processed into delivered.
// arrange the cards.

// rearrange the cards in the Analytics page for better UI/UX.
// change the event into email metrics graphs.
// change the logic of the bounce rate calculation to include deferred emails.

//===================================================
//date: 22-08-2025
// fix the issue into bounce rate chart.
// add a button refresh the campaign data.
// add a tooltip for the refresh button to inform users about the refresh limit.

//===================================================
// date: 25-08-2025
// add a api for the refresh the campaign data.
// solve the refresh button issue.

import { SelectProps } from 'antd';
import React, { useEffect, useState, useRef } from 'react';
import { Card, Row, Col, Statistic, Select, Spin, Button, Tooltip } from 'antd';
import { Line } from '@ant-design/plots';
import { InfoCircleOutlined, ReloadOutlined, ArrowRightOutlined } from '@ant-design/icons';
import styled from 'styled-components';
import apiService from '../../services/ApiService';
import moment from 'moment-timezone';
import ReactApexChart from 'react-apexcharts';

const { Option } = Select;

interface Campaign {
  id: string;
  name: string;
  totalBounces: number;
  totalClicks: number;
  totalOpens: number;
  totalDropped: number;
  totalProcessed: number;
  totalDeferred: number;
  totalUnsubscribed: number;
  totalDelivered: number;
  modifiedon?: string;
}

interface StyledCardProps {
  bgColor?: string;
}

interface WebhookData {
  dropped: number;
  processed: number;
  deferred: number;
  delivered: number;
  bounce: number;
  click: number;
  open: number;
  unsubscribe: number;
  delta: {
    dropped: number;
    processed: number;
    deferred: number;
    delivered: number;
    bounce: number;
    click: number;
    open: number;
    unsubscribe: number;
  };
}

interface BounceRate {
  date: string;
  rate: number;
}

interface RefreshData {
  count: number;
  startTime: string;
}

const fallbackData: WebhookData = {
  delivered: 0,
  bounce: 0,
  dropped: 0,
  open: 0,
  click: 0,
  unsubscribe: 0,
  processed: 0,
  deferred: 0,
  delta: {
    delivered: 0,
    bounce: 0,
    dropped: 0,
    open: 0,
    click: 0,
    unsubscribe: 0,
    processed: 0,
    deferred: 0,
  },
};

// Fallback bounce rate data for initial load
const fallbackBounceRates: BounceRate[] = [
  {
    date: moment().tz('Asia/Kolkata').format('YYYY-MM-DD'),
    rate: 0,
  },
];

const DashboardContainer = styled.div`
  padding: 24px;
  background: #f5f7fa;
  position: relative;
`;

const Title = styled.h2`
  margin-bottom: 16px;
  color: #1a1a1a;
`;

const ChartTitle = styled.h3`
  color: #1a1a1a;
  font-weight: 600;
  margin-bottom: 16px;
`;

const StyledCard = styled(Card) <StyledCardProps>`
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border: none !important;
  transition: all 0.3s ease;
  border-radius: 12px;
  text-align: center;
  background: ${({ bgColor }) => `linear-gradient(135deg, ${bgColor}22, #ffffff)`};

  &:hover {
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    transform: scale(1.03);
  }

  .ant-card-body {
    padding: 20px;
  }

  .ant-statistic-title {
    color: #4a4a4a !important;
    font-size: 16px !important;
  }

  .ant-statistic-content {
    font-size: 24px !important;
    font-weight: 600 !important;
  }
`;

const StyledSelect = styled(Select) <SelectProps<string>>`
  .ant-select-selector {
    border-radius: 8px !important;
    border: 1px solid #e8ecef !important;
    background: #fff !important;
    padding: 8px !important;
    font-size: 14px !important;
  }
`;

const RefreshButton = styled(Button)`
  border-radius: 8px;
  border: 1px solid #e8ecef;
  background: #fff;
  height: 40px;
  margin-left: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

  &:hover {
    background: #f5f7fa;
    border-color: #1890ff;
    color: #1890ff;
  }

  &.ant-btn-disabled {
    .anticon-reload {
      margin-right: 4px;
    }
    .anticon-arrow-right {
      display: inline-block;
    }
  }

  .anticon-arrow-right {
    display: none;
  }
`;

const InfoButton = styled(Button)`
  border-radius: 8px;
  border: 1px solid #e8ecef;
  background: #fff;
  height: 40px;
  margin-left: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

  &:hover {
    background: #f5f7fa;
    border-color: #1890ff;
    color: #1890ff;
  }
`;

const MessageContainer = styled.div`
  background: linear-gradient(135deg, #ffffff, #e8ecef);
  border: 1px solid #e8ecef;
  border-radius: 12px;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
  padding: 40px 24px;
  text-align: center;
  margin: 32px auto;
  max-width: 600px;
  animation: scaleFade 0.5s ease-in-out;

  @keyframes scaleFade {
    from {
      opacity: 0;
      transform: scale(0.95);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  @media (max-width: 576px) {
    padding: 24px 16px;
    margin: 24px 16px;
  }
`;

const MessageIcon = styled(InfoCircleOutlined)`
  font-size: 40px;
  color: #1890ff;
  margin-bottom: 16px;
`;

const MessageTitle = styled.h3`
  color: #1a1a1a;
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 8px;
`;

const MessageText = styled.p`
  color: #6b7280;
  font-size: 15px;
  margin: 0;
`;

const LoaderContainer = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.8);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ChartLoaderContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 300px;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
`;

const Analytics: React.FC = () => {
  const [webhookStats, setWebhookStats] = useState<WebhookData>(fallbackData);
  const [bounceRates, setBounceRates] = useState<BounceRate[]>(fallbackBounceRates);
  const [selectedCampaign, setSelectedCampaign] = useState<string>('');
  const [campaignList, setCampaignList] = useState<Campaign[]>([]);
  const [isAllCampaigns, setIsAllCampaigns] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Function to manage refresh counts in localStorage
  const getRefreshData = (campaignId: string): RefreshData => {
    const data = localStorage.getItem(`refresh_${campaignId}`);
    return data ? JSON.parse(data) : { count: 0, startTime: '' };
  };

  const setRefreshData = (campaignId: string, data: RefreshData) => {
    localStorage.setItem(`refresh_${campaignId}`, JSON.stringify(data));
  };

  // Check if refresh is allowed (max 3 times in 24 hours)
  // const canRefreshCampaign = (campaignId: string): boolean => {
  //   const refreshData = getRefreshData(campaignId);
  //   const now = moment().tz('Asia/Kolkata');
  //   const startTime = refreshData.startTime ? moment(refreshData.startTime) : null;
  //   const hoursSinceStart = startTime ? now.diff(startTime, 'hours') : null;

  //   // Reset count if 24 hours have passed
  //   if (hoursSinceStart && hoursSinceStart >= 24) {
  //     setRefreshData(campaignId, { count: 0, startTime: '' });
  //     return true;
  //   }

  //   // Allow refresh if count is less than 3
  //   return refreshData.count < 3;
  // };
  const canRefreshCampaign = (campaignId: string): boolean => {
    const refreshData = getRefreshData(campaignId);
    const now = moment().tz('Asia/Kolkata');
    const startTime = refreshData.startTime ? moment(refreshData.startTime) : null;
    const hoursSinceStart = startTime ? now.diff(startTime, 'hours') : null;

    const campaign = campaignList.find(c => c.id === campaignId);
    if (!campaign || !campaign.modifiedon) {
      console.warn(`Campaign ${campaignId} not found or missing modifiedon date`);
      return false;
    }

    const modifiedOn = moment.tz(campaign.modifiedon, 'Asia/Kolkata').utc();
    const refreshCutoff = modifiedOn.add(8, 'hours');
    const currentUTCTime = moment.utc();
    const isAfterCutoff = currentUTCTime.isSameOrAfter(refreshCutoff);

    if (!isAfterCutoff) {
      return false;
    }

    if (hoursSinceStart && hoursSinceStart >= 24) {
      setRefreshData(campaignId, { count: 0, startTime: '' });
      return true;
    }

    return refreshData.count < 3;
  };

  // Get remaining refreshes for tooltip
  // const getRemainingRefreshes = (campaignId: string): string => {
  //   const refreshData = getRefreshData(campaignId);
  //   const now = moment().tz('Asia/Kolkata');
  //   const startTime = refreshData.startTime ? moment(refreshData.startTime) : null;
  //   const hoursSinceStart = startTime ? now.diff(startTime, 'hours') : null;

  //   if (hoursSinceStart && hoursSinceStart >= 24) {
  //     return '3 refreshes available';
  //   }

  //   const remaining = 3 - refreshData.count;
  //   if (remaining <= 0) {
  //     const resetTime = startTime ? startTime.add(24, 'hours').format('YYYY-MM-DD HH:mm:ss') : '24 hours';
  //     return `Refresh limit reached. Try again after ${resetTime}.`;
  //   }
  //   return `${remaining} refresh${remaining === 1 ? '' : 'es'} remaining until ${startTime ? startTime.add(24, 'hours').format('YYYY-MM-DD HH:mm:ss') : '24 hours'}`;
  // };
  const getRemainingRefreshes = (campaignId: string): string => {
    const refreshData = getRefreshData(campaignId);
    const now = moment().tz('Asia/Kolkata');
    const startTime = refreshData.startTime ? moment(refreshData.startTime) : null;
    const hoursSinceStart = startTime ? now.diff(startTime, 'hours') : null;

    // Find the campaign to get its modifiedon date
    const campaign = campaignList.find(c => c.id === campaignId);
    if (!campaign || !campaign.modifiedon) {
      return 'Select a valid campaign to refresh';
    }

    // Check if current UTC time is before modifiedon + 8 hours
    const refreshCutoff = moment.tz(campaign.modifiedon, 'Asia/Kolkata').utc().add(8, 'hours');
    const currentUTCTime = moment.utc();
    if (!currentUTCTime.isSameOrAfter(refreshCutoff)) {
      return `Refresh available after ${refreshCutoff.tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss')} IST`;
    }

    if (hoursSinceStart && hoursSinceStart >= 24) {
      return '3 refreshes available';
    }

    const remaining = 3 - refreshData.count;
    if (remaining <= 0) {
      const resetTime = startTime ? startTime.add(24, 'hours').format('YYYY-MM-DD HH:mm:ss') : '24 hours';
      return `Refresh limit reached. Try again after ${resetTime}.`;
    }
    return `${remaining} refresh${remaining === 1 ? '' : 'es'} remaining until ${startTime ? startTime.add(24, 'hours').format('YYYY-MM-DD HH:mm:ss') : '24 hours'}`;
  };


  // Increment refresh count
  const incrementRefreshCount = (campaignId: string) => {
    const refreshData = getRefreshData(campaignId);
    const now = moment().tz('Asia/Kolkata').toISOString();

    if (refreshData.count === 0 || !refreshData.startTime) {
      setRefreshData(campaignId, { count: 1, startTime: now });
    } else {
      setRefreshData(campaignId, { count: refreshData.count + 1, startTime: refreshData.startTime });
    }
  };

  // Function to calculate totals for campaigns
  const calculateCampaignTotals = (campaigns: Campaign[]): WebhookData => {
    return campaigns.reduce(
      (acc, campaign) => ({
        delivered: acc.delivered + (campaign.totalDelivered || 0) + (campaign.totalProcessed || 0),
        bounce: acc.bounce + (campaign.totalBounces || 0) + (campaign.totalDeferred || 0),
        dropped: acc.dropped + (campaign.totalDropped || 0),
        open: acc.open + (campaign.totalOpens || 0),
        click: acc.click + (campaign.totalClicks || 0),
        unsubscribe: acc.unsubscribe + (campaign.totalUnsubscribed || 0),
        processed: 0,
        deferred: 0,
        delta: {
          delivered: 0,
          bounce: 0,
          dropped: 0,
          open: 0,
          click: 0,
          unsubscribe: 0,
          processed: 0,
          deferred: 0,
        },
      }),
      {
        delivered: 0,
        bounce: 0,
        dropped: 0,
        open: 0,
        click: 0,
        unsubscribe: 0,
        processed: 0,
        deferred: 0,
        delta: {
          delivered: 0,
          bounce: 0,
          dropped: 0,
          open: 0,
          click: 0,
          unsubscribe: 0,
          processed: 0,
          deferred: 0,
        },
      }
    );
  };

  // Calculate bounce rates from campaigns
  const calculateBounceRates = (campaigns: Campaign[], isSingleCampaign: boolean = false, modifiedDate?: string): BounceRate[] => {
    if (isSingleCampaign && campaigns.length === 1) {
      const campaign = campaigns[0];
      const totalDelivered = (campaign.totalDelivered || 0) + (campaign.totalProcessed || 0);
      const totalBounce = (campaign.totalBounces || 0) + (campaign.totalDeferred || 0);
      const bounceRate = totalDelivered > 0 ? (totalBounce / totalDelivered * 100) : 0;
      return [{
        date: campaign.modifiedon ?? modifiedDate ?? moment().tz('Asia/Kolkata').format('YYYY-MM-DD'),
        rate: parseFloat(bounceRate.toFixed(2)),
      }];
    }

    const bounceRatesMap: { [date: string]: { totalBounce: number; totalDelivered: number } } = {};
    campaigns.forEach(campaign => {
      const date = moment(campaign.modifiedon ?? moment().tz('Asia/Kolkata')).format('YYYY-MM-DD');
      const totalDelivered = (campaign.totalDelivered || 0) + (campaign.totalProcessed || 0);
      const totalBounce = (campaign.totalBounces || 0) + (campaign.totalDeferred || 0);

      if (!bounceRatesMap[date]) {
        bounceRatesMap[date] = { totalBounce: 0, totalDelivered: 0 };
      }
      bounceRatesMap[date].totalBounce += totalBounce;
      bounceRatesMap[date].totalDelivered += totalDelivered;
    });

    return Object.entries(bounceRatesMap)
      .map(([date, { totalBounce, totalDelivered }]) => ({
        date,
        rate: totalDelivered > 0 ? parseFloat((totalBounce / totalDelivered * 100).toFixed(2)) : 0,
      }))
      .sort((a, b) => moment(a.date).diff(moment(b.date)))
      .slice(-10);
  };

  // Fetch all campaigns
  const fetchAllCampaigns = async () => {
    setLoading(true);
    try {
      console.log('Fetching all campaigns...');
      const response = await apiService.get<{ data: any[] }>('/campaignanalysis');
      console.log('All campaigns API response:', response);

      if (Array.isArray(response.data) && response.data.length > 0) {
        const mappedData = response.data.map(item => {
          if (!item.id) {
            console.warn('Campaign data missing id:', item);
          }
          return {
            id: item.id || `temp-id-${Math.random().toString(36).substr(2, 9)}`,
            name: item.advicCampaign?.name || item.advicName || 'Unknown Campaign',
            totalBounces: item.totalBounces || 0,
            totalClicks: item.totalClicks || 0,
            totalOpens: item.totalOpens || 0,
            totalDropped: item.totalDropped || 0,
            totalProcessed: item.totalProcessed || 0,
            totalDeferred: item.totalDeferred || 0,
            totalUnsubscribed: item.totalUnsubscribed || 0,
            totalDelivered: item.totalDelivered || 0,
            modifiedon: item.modifiedon || moment().tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss'),
          };
        });
        console.log('Mapped campaign data:', mappedData);

        setCampaignList(mappedData);
        const totalStats = calculateCampaignTotals(mappedData);
        setWebhookStats(totalStats);
        const newBounceRates = calculateBounceRates(mappedData);
        setBounceRates(newBounceRates.length > 0 ? newBounceRates : fallbackBounceRates);
      } else {
        console.error('All campaigns API response is not an array or is empty:', response.data);
        setCampaignList([]);
        setWebhookStats(fallbackData);
        setBounceRates(fallbackBounceRates);
      }
    } catch (error) {
      console.error('Failed to fetch all campaigns:', error);
      setCampaignList([]);
      setWebhookStats(fallbackData);
      setBounceRates(fallbackBounceRates);
    } finally {
      setLoading(false);
    }
  };

  // Fetch data for a specific campaign
  const fetchCampaignById = async (campaignId: string) => {
    setLoading(true);
    try {
      //console.log(`Fetching campaign data for ID: ${campaignId}`);
      const response = await apiService.get<{ data: any }>(`/campaignanalysis/${campaignId}`);
      //console.log('Campaign API response:', response);

      const item = response.data;
      if (!item.id) {
        console.warn('Campaign data missing id:', item);
      }
      const campaignData: Campaign = {
        id: item.id || `temp-id-${Math.random().toString(36).substr(2, 9)}`,
        name: item.advicCampaign?.name || item.advicName || 'Unknown Campaign',
        totalBounces: item.totalBounces || 0,
        totalClicks: item.totalClicks || 0,
        totalOpens: item.totalOpens || 0,
        totalDropped: item.totalDropped || 0,
        totalProcessed: item.totalProcessed || 0,
        totalDeferred: item.totalDeferred || 0,
        totalUnsubscribed: item.totalUnsubscribed || 0,
        totalDelivered: item.totalDelivered || 0,
        modifiedon: item.modifiedon || moment().tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss'),
      };

      const totalStats = {
        delivered: campaignData.totalDelivered + (campaignData.totalProcessed || 0),
        bounce: campaignData.totalBounces + (campaignData.totalDeferred || 0),
        dropped: campaignData.totalDropped,
        open: campaignData.totalOpens || 0,
        click: campaignData.totalClicks || 0,
        unsubscribe: campaignData.totalUnsubscribed,
        processed: 0,
        deferred: 0,
        delta: {
          delivered: 0,
          bounce: 0,
          dropped: 0,
          open: 0,
          click: 0,
          unsubscribe: 0,
          processed: 0,
          deferred: 0,
        },
      };
      setWebhookStats(totalStats);
      const newBounceRates = calculateBounceRates([campaignData], true, campaignData.modifiedon);
      setBounceRates(newBounceRates.length > 0 ? newBounceRates : fallbackBounceRates);
    } catch (error) {
      console.error(`Failed to fetch campaign data for ID ${campaignId}:`, error);
      setWebhookStats(fallbackData);
      setBounceRates(fallbackBounceRates);
    } finally {
      setLoading(false);
    }
  };

  const scheduleNextFetch = () => {
    const now = moment().tz('Asia/Kolkata');
    const scheduleTimes = ['00:00', '06:00', '12:00', '18:00'];
    let nextTime: moment.Moment | null = null;
    for (const time of scheduleTimes) {
      const [hours, minutes] = time.split(':').map(Number);
      const candidate = moment.tz(now.format('YYYY-MM-DD'), 'Asia/Kolkata').set({ hour: hours, minute: minutes, second: 0, millisecond: 0 });
      if (candidate.isAfter(now)) {
        nextTime = candidate;
        break;
      }
    }

    if (!nextTime) {
      nextTime = moment.tz(now.format('YYYY-MM-DD'), 'Asia/Kolkata')
        .add(1, 'day')
        .set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
    }

    const delay = nextTime.diff(now);
    console.log(`Scheduling next fetch at ${nextTime.format('YYYY-MM-DD HH:mm:ss')} (in ${delay} ms)`);

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      if (selectedCampaign && !isAllCampaigns) {
        fetchCampaignById(selectedCampaign);
      } else {
        fetchAllCampaigns();
      }
      scheduleNextFetch();
    }, delay);
  };

  // Handle refresh button click
  // it work like this user can refresh their chosen campaign only 3 times in 24 hours.
  // and pass the id and count pass to the api and backend logic are valiadted.
  const handleRefresh = async () => {
    if (selectedCampaign && !isAllCampaigns && canRefreshCampaign(selectedCampaign)) {
      setLoading(true);
      const startTime = Date.now();
      try {
        console.log(`Refreshing campaign data for ID: ${selectedCampaign}`);
        const refreshData = getRefreshData(selectedCampaign);
        console.log('Current refresh data:', refreshData);
        const currentRefreshCount = refreshData.count;
        console.log('Current refresh count:', currentRefreshCount);

        const payload = {
          id: selectedCampaign,
          refreshcount: currentRefreshCount + 1,
        };

        await apiService.post('/RecaculateCampaignAnalatics', payload);
        console.log('Refresh API call successful:', payload);

        incrementRefreshCount(selectedCampaign);

        await fetchCampaignById(selectedCampaign);
        console.log(`Campaign ${selectedCampaign} data refreshed successfully.`);

        const elapsedTime = Date.now() - startTime;
        const minDelay = 1500;
        if (elapsedTime < minDelay) {
          await new Promise(resolve => setTimeout(resolve, minDelay - elapsedTime));
        }

        scheduleNextFetch();
      } catch (error) {
        console.error(`Failed to refresh campaign ${selectedCampaign}:`, error);
      } finally {
        setLoading(false);
      }
    } else {
      console.log(`Refresh limit reached for campaign ${selectedCampaign}`);
    }
  };

  useEffect(() => {
    fetchAllCampaigns();
    scheduleNextFetch();

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (selectedCampaign && !isAllCampaigns) {
      fetchCampaignById(selectedCampaign);
    } else {
      fetchAllCampaigns();
    }
  }, [selectedCampaign]);

  const handleCampaignChange = (value: string | undefined) => {
    setSelectedCampaign(value || '');
    setIsAllCampaigns(!value);
  };

  const renderSummaryCards = () => {
    const stats = [
      { key: 'delivered', title: 'Delivered', value: webhookStats.delivered, delta: webhookStats.delta?.delivered, color: '#2ecc71' },
      { key: 'bounce', title: 'Bounced', value: webhookStats.bounce, delta: webhookStats.delta?.bounce, color: '#e74c3c' },
      { key: 'dropped', title: 'Dropped', value: webhookStats.dropped, delta: webhookStats.delta?.dropped, color: '#7f8c8d' },
      { key: 'open', title: 'Opened', value: webhookStats.open, delta: webhookStats.delta?.open, color: '#1abc9c' },
      { key: 'click', title: 'Clicked', value: webhookStats.click, delta: webhookStats.delta?.click, color: '#3498db' },
      { key: 'unsubscribe', title: 'Unsubscribed', value: webhookStats.unsubscribe, delta: webhookStats.delta?.unsubscribe, color: '#e67e22' },
    ];

    return (
      <Row gutter={[16, 16]} justify="center">
        {stats.map((stat) => (
          <Col xs={24} sm={12} md={8} key={stat.key}>
            <StyledCard bgColor={stat.color}>
              <Statistic title={stat.title} value={stat.value} />
            </StyledCard>
          </Col>
        ))}
      </Row>
    );
  };

  const renderVisitorChart = () => {
    const deliveredValue = webhookStats.delivered || 0;
    const bounceValue = webhookStats.bounce || 0;
    const total = deliveredValue + bounceValue;

    const series = [deliveredValue, bounceValue];

    const options: ApexCharts.ApexOptions = {
      chart: {
        type: 'radialBar',
        height: 350,
      },
      plotOptions: {
        radialBar: {
          hollow: {
            size: '40%',
          },
          dataLabels: {
            name: {
              fontSize: '16px',
            },
            value: {
              fontSize: '14px',
              formatter: (val: number) => `${val}`,
            },
            total: {
              show: true,
              label: 'Total',
              formatter: () => `${total}`,
            },
          },
        },
      },
      labels: ['Delivered', 'Bounce'],
      colors: ['#2ecc71', '#e74c3c'],
    };

    return (
      <div style={{ marginTop: 24 }}>
        <ChartTitle>Delivered vs Bounce</ChartTitle>
        <ReactApexChart options={options} series={series} type='radialBar' height={350} />
      </div>
    );
  };

  const renderEmailMetricsChart = () => {
    const series = [
      webhookStats.delivered || 0,
      webhookStats.dropped || 0,
      webhookStats.unsubscribe || 0,
    ];

    const options: ApexCharts.ApexOptions = {
      chart: {
        type: 'polarArea',
      },
      labels: ['Delivered', 'Dropped', 'Unsubscribed'],
      stroke: {
        colors: ['#fff'],
      },
      fill: {
        opacity: 0.8,
      },
      legend: {
        position: 'bottom',
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 250,
            },
            legend: {
              position: 'bottom',
            },
          },
        },
      ],
      colors: ['#2ecc71', '#7f8c8d', '#e67e22'],
    };

    return (
      <div style={{ marginTop: 24 }}>
        <ChartTitle>Email Metrics</ChartTitle>
        <ReactApexChart options={options} series={series} type='polarArea' height={350} />
      </div>
    );
  };

  const renderBounceRateChart = () => {
    if (loading) {
      return (
        <div style={{ marginTop: 24 }}>
          <ChartTitle>Bounce Rate Over Time</ChartTitle>
          <ChartLoaderContainer>
            <Spin size="large" tip="Loading bounce rate data..." />
          </ChartLoaderContainer>
        </div>
      );
    }

    const config = {
      data: bounceRates,
      xField: 'date',
      yField: 'rate',
      color: '#ff4d4f',
      lineStyle: { strokeWidth: 2 },
      point: { size: 5, shape: 'circle' },
      xAxis: { label: { autoRotate: true } },
      yAxis: { label: { formatter: (v: number) => `${v}%` } },
      height: 300,
    };

    return (
      <div style={{ marginTop: 24 }}>
        <ChartTitle>Bounce Rate Over Time</ChartTitle>
        <Line {...config} />
      </div>
    );
  };

  return (
    <DashboardContainer>
      <Title>Email Marketing Dashboard</Title>
      <Row gutter={16} style={{ marginBottom: 24 }}>
        <Col xs={24} sm={12} md={8} style={{ display: 'flex', alignItems: 'center' }}>
          <StyledSelect
            placeholder='Select Campaign'
            style={{ flex: 1 }}
            onChange={handleCampaignChange}
            value={selectedCampaign || undefined}
            allowClear
          >
            <Option value=''>All Campaigns</Option>
            {Array.isArray(campaignList) && campaignList.length > 0 ? (
              campaignList.map((c) => (
                <Option key={c.id} value={c.id}>
                  {c.name}
                </Option>
              ))
            ) : (
              <Option disabled>No campaigns available</Option>
            )}
          </StyledSelect>
          <Tooltip title={selectedCampaign && !isAllCampaigns ? getRemainingRefreshes(selectedCampaign) : 'Select a campaign to refresh'}>
            <RefreshButton
              icon={<><ReloadOutlined /><ArrowRightOutlined /></>}
              onClick={handleRefresh}
              disabled={loading || isAllCampaigns || !selectedCampaign || !canRefreshCampaign(selectedCampaign)}
            />
          </Tooltip>
          <Tooltip title="Users can refresh their chosen campaign only 3 times in 24 hours">
            <InfoButton icon={<InfoCircleOutlined />} />
          </Tooltip>
        </Col>
      </Row>
      {loading && campaignList.length === 0 ? (
        <LoaderContainer>
          <Spin size="large" tip="Loading campaign data..." />
        </LoaderContainer>
      ) : campaignList.length === 0 ? (
        <MessageContainer>
          <MessageIcon />
          <MessageTitle>No Campaign Data Available</MessageTitle>
          <MessageText>Please check back later or ensure the campaign data is properly configured.</MessageText>
        </MessageContainer>
      ) : (
        <>
          {renderSummaryCards()}
          <Row gutter={[16, 16]}>
            <Col xs={24} md={12}>
              {renderVisitorChart()}
            </Col>
            <Col xs={24} md={12}>
              {renderEmailMetricsChart()}
            </Col>
            <Col xs={24}>
              {renderBounceRateChart()}
            </Col>
          </Row>
        </>
      )}
    </DashboardContainer>
  );
};

export default Analytics;