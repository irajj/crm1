// Date:05-08-2025
// impelemet the serch bar 
import { useRef } from "react";
import { Col, Flex, Row, Typography, Spin, Modal, Button, notification, message, Breadcrumb } from "antd";
import { Copy, SearchIcon } from "lucide-react";
import { useEffect, useState } from "react";
import "./MergeFieldModel.css";
import { RightOutlined, DownOutlined } from "@ant-design/icons"

import { Waypoints, TypeIcon, List, Glasses, Fingerprint, Map, Type, SquareCheck, CalendarCheck, DollarSign, Image as ImageIcon, Move, User, Grid, PersonStanding, Flag, Signal } from "lucide-react";
import Search from "antd/es/input/Search";

const { Text } = Typography;

interface MergeFieldModalProps {
    editorRef: React.RefObject<any>;
    showModal: boolean;
    setShowModal: React.Dispatch<React.SetStateAction<boolean>>;
    // primaryEntities: any[];
    // otherEntities: any[];
    // isPrimaryEntityOpen: boolean;
    // isOtherEntityOpen: boolean;
    // expandedEntities: Record<string, boolean>;
    // togglePrimaryEntity: (event: React.MouseEvent<HTMLDivElement>) => void;
    // toggleOtherEntity: () => void;
    // toggleFields: (id: string, e: React.MouseEvent, entity: any, path: string) => void;
    // renderToggleIcon: (isOpen: boolean) => React.ReactNode;
    // renderFields: (entity: any) => React.ReactNode;
    selectedEntityName?: string;
}

interface Entity {
    id: string;
    logicalname: string;
    [key: string]: any; // optional if entity has more dynamic properties
}

interface primaryEntity {
    id: string; // or number, based on your actual data
    displayname?: string;
    logicalname: string;

}

interface EntityMergeField {
    logicalname: string;
    displayname?: string;
    // Add this:
    id: string;
}

interface DepthEntityState {
    toggled: boolean;
    entityRef: string;
    fieldRef: any; // You can make this more specific later
}

type DepthLevelEntitiesState = {
    [key: string]: DepthEntityState;
};

type Field = {
    displayName?: {
        localizedLabels?: { label?: string }[];
    };
    logicalName?: string;
    // Add other properties if needed
};

interface FieldDepthfetch {
    displayName: {
        localizedLabels: any[]; // You can make this more specific
    };
    // add other properties if needed
}

interface FieldsApiResponse {
    data: FieldDepthfetch[];
}

interface FieldRF {
    metadataId: string;
    attributeTypeName?: { value?: string };
    entityLogicalName: string;
    logicalName: string;
    displayName?: { localizedLabels: { label: string }[] };
    targets?: string[];

}

interface EntityRF {
    id: string;
    name: string;
}


const MergeFieldModal: React.FC<MergeFieldModalProps> = ({
    editorRef,
    showModal,
    setShowModal
}) => {
    const [api, contextHolder] = notification.useNotification();
    const [currentSlide, setCurrentSlide] = useState(0);
    const [primaryEntities, setPrimaryEntities] = useState<EntityMergeField[]>([]);
    const [otherEntities, setOtherEntities] = useState<EntityMergeField[]>([]);
    const [isPrimaryEntityOpen, setPrimaryEntityOpen] = useState(false);
    const [isOtherEntityOpen, setOtherEntityOpen] = useState(false);
    const [expandedEntities, setExpandedEntities] = useState<{ [key: string]: boolean }>({});
    const [fetchedFields, setFetchedFields] = useState<{ [entityId: string]: FieldRF[] }>({});
    const [DepthLevelEntities, setDepthLevelEntities] = useState<DepthLevelEntitiesState>({});;
    const [fetchedDepthFields, setFetchedDepthFields] = useState<{ [key: string]: FieldDepthfetch[] | boolean }>({});
    const [firstLevelEntitySelected, setFirstlevelEntity] = useState("");
    const [secondLevelEntitySelected, setSecondlevelEntity] = useState("");
    const [thirdLevelEntitySelected, setThirdlevelEntity] = useState("");
    const [displayName, setDisplayName] = useState<string>('');

    const [breadcrumbs, setBreadcrumbs] = useState<string[]>([]);

    const [firstLevelSelectedField, setfirstLevelSelectedField] = useState<string>('');
    const [secondLevelSelectedField, setsecondLevelSelectedField] = useState<string>('');
    const [thirdLevelSelectedField, setthirdLevelSelectedField] = useState<string>('');
    const [fourthLevelSelectedField, setfourthLevelSelectedField] = useState<string>('');
    const [searchQuery, setSearchQuery] = useState<string>('');

    const hasFetched = useRef(false); // tracks if fetchEntities has been called

    // const MAX_SLIDE_INDEX = 3;
    // const [open, setOpen] = useState<boolean>(false);

    const handleSave = () => {
        if (!displayName.trim()) {
            message.error('display name is required.');
            return;
        }
        pasteDefaultValue(displayName)
    };

    const handleBreadcrumbClick = (index: number) => {

        if (index === 0) {
            setBreadcrumbs([]);
            setCurrentSlide(1);
            return;
        }
        setCurrentSlide(index + 1);
        // setBreadcrumbs(prev => prev.slice(0, index + 1));
        // setCurrentSlide(index + 1); // Slide is one-based
        const updatedTrail = breadcrumbs.slice(0, index + 1); // Keep up to clicked breadcrumb
        setBreadcrumbs(updatedTrail);
    };

    const handleCancel = () => {
        setDisplayName('');
        setSearchQuery('');
        setShowModal(false);
    };

    const togglePrimaryEntity = (e: React.MouseEvent<HTMLDivElement>) => {
        e.preventDefault();
        setPrimaryEntityOpen(!isPrimaryEntityOpen);
    };

    const toggleFields = async (entityId: string,
        e: React.MouseEvent<HTMLElement>,
        entity: Entity,
        nextslide: string) => {
        e.preventDefault();
        if (nextslide != "") {
            setCurrentSlide(Number(nextslide));
        }

        setExpandedEntities((prev) => ({
            ...prev,
            [entityId]: !prev[entityId],
        }));



        // Fetch fields only if not already fetched
        if (!fetchedFields[entityId]) {
            await fetchFieldsForEntity(entity.logicalname, entityId);
        }
    };

    const toggleOtherEntity = (e: any) => {
        e.preventDefault(); // Prevent the URL update
        setOtherEntityOpen(!isOtherEntityOpen);
    };

    const url_get_all_entity = "https://emailboost.azurewebsites.net/api/entity";

    useEffect(() => {
        if (!hasFetched.current) {
            hasFetched.current = true;
            fetchEntities();
        }
    });


    const fetchEntities = async () => {
        try {
            const response = await fetch(url_get_all_entity);
            if (!response.ok) throw new Error("Network response was not ok");
            const allEntity = await response.json();
            filterEntitiesByEntityLogicalName(allEntity.data);
        } catch (error) {
            console.error("Error fetching entities:", error);
        }
    };

    const filterEntitiesByEntityLogicalName = (data: EntityMergeField[]) => {
        const primaryEntities: EntityMergeField[] = [];
        const otherEntities: EntityMergeField[] = [];

        data.forEach((entity) => {
            if (
                ["contact", "account", "lead", "opportunity"].includes(
                    entity.logicalname
                )
            ) {
                primaryEntities.push(entity);
            } else {
                otherEntities.push(entity);
            }
        });
        setPrimaryEntities(primaryEntities);
        setOtherEntities(otherEntities);
    };

    const fetchFieldsForEntity = async (entityLogicalName: string, entityId: string) => {

        try {
            const response = await fetch(
                `https://emailboost.azurewebsites.net/api/entity/${entityLogicalName}`
            );
            if (!response.ok) throw new Error("Failed to fetch fields");

            const jsonFields = await response.json();

            const fields = jsonFields.data.filter((field: Field) => {
                const hasValidLabel =
                    field.displayName &&
                    Array.isArray(field.displayName.localizedLabels) &&
                    field.displayName.localizedLabels.length > 0 &&
                    field.displayName.localizedLabels[0].label?.trim() !== "";

                const hasLogicalName = !!field.logicalName?.trim();

                return hasValidLabel || hasLogicalName;
            });


            setFetchedFields((prev) => ({
                ...prev,
                [entityId]: fields,
            }));
        } catch (error) {
            console.error("Error fetching fields:", error);
        }
    };

    const iconFinder = (type: string | undefined | null) => {
        switch (type?.toLowerCase()) {
            case "lookuptype":
                return <Waypoints size={16} />;
                break;
            case "stringtype":
                return <TypeIcon size={16} />;
                break;
            case "picklisttype":
                return <List size={16} />;
                break;
            case "virtualtype":
                return <Glasses size={16} />;
                break;
            case "uniqueidentifiertype":
                return <Fingerprint size={16} />;
                break;
            case "memotype":
                return <Map size={16} />;
                break;
            case "doubletype":
                return <Type size={16} />;
                break;
            case "integertype":
                return <Type size={16} />;
                break;
            case "decimaltype":
                return <Type size={16} />;
                break;
            case "booleantype":
                return <SquareCheck size={16} />;
                break;
            case "datetimetype":
                return <CalendarCheck size={16} />;
                break;
            case "moneytype":
                return <DollarSign size={16} />;
                break;
            case "imagetype":
                return <ImageIcon size={16} />;
                break;
            case "biginttype":
                return <Move size={16} />;
                break;
            case "ownertype":
                return <User size={16} />;
                break;
            case "entitynametype":
                return <Grid size={16} />;
                break;
            case "customertype":
                return <PersonStanding size={16} />;
                break;
            case "statetype":
                return <Flag size={16} />;
                break;
            case "statustype":
                return <Signal size={16} />;
            default:
                return <Type size={16} />;
                break;
        }
    };

    // #fn Paste To Editor
    const pasteToEditor = (e: React.SyntheticEvent,
        entityName: string,
        fieldName: string) => {

        e.preventDefault();
        const placeholder = `{!${entityName}.${fieldName}}`;
        const editor = editorRef.current;
        if (editor) {
            const selected = editor.getSelected();
            if (selected) {

                selected.append(placeholder);
                setShowModal(false)
            } else {
                // setShowModal(false)
                api.open({
                    message: '',
                    description: 'No component is selected. Please select a component to add content..',
                    type: 'warning',
                    showProgress: true,
                    pauseOnHover: true,
                });
            }
        } else {
            console.error("Editor instance is not available");
        }
    };

    const pasteDefaultValue = (displayname: string) => {

        // e.preventDefault();
        const placeholder = `{{${displayname}}}`;
        const editor = editorRef.current;
        if (editor) {
            const selected = editor.getSelected();
            if (selected) {

                selected.append(placeholder);

                setShowModal(false);
                setDisplayName('');
                // setDefaultValue('');
                setSearchQuery('');
            } else {
                // setShowModal(false)
                api.open({
                    message: '',
                    description: 'No component is selected. Please select a component to add content..',
                    type: 'warning',
                    showProgress: true,
                    pauseOnHover: true,
                });
            }
        } else {
            console.error("Editor instance is not available");
        }
    }

    const PasteToEditorForDepthEntity = (e: React.MouseEvent, entityName: string, fieldName: string) => {

        e.preventDefault();
        let placeholder = `{!${entityName}.${fieldName}}`;
        if (currentSlide == 2) {
            placeholder = `{!${breadcrumbs[0]}.${firstLevelSelectedField}.${fieldName}}`;
            // placeholder = `{!${breadcrumbs.join('.')}.${fieldName}}`;
        }
        if (currentSlide == 3) {
            placeholder = `{!${breadcrumbs[0]}.${firstLevelSelectedField}.${secondLevelSelectedField}.${fieldName}}`;
            // placeholder = `{!${breadcrumbs.join('.')}.${fieldName}}`
        }
        if (currentSlide == 4) {
            placeholder = `{!${breadcrumbs[0]}.${firstLevelSelectedField}.${secondLevelSelectedField}.${thirdLevelSelectedField}.${fieldName}}`;
            // placeholder = `{!${breadcrumbs.join('.')}.${fieldName}}`
        }
        if (currentSlide == 5) {
            placeholder = `{!${breadcrumbs[0]}.${firstLevelSelectedField}.${secondLevelSelectedField}.${thirdLevelSelectedField}.${fourthLevelSelectedField}.${fieldName}}`;
            // placeholder = `{!${breadcrumbs.join('.')}.${fieldName}}`
        }
        const editor = editorRef.current;
        if (editor) {
            const selected = editor.getSelected();
            if (selected) {

                selected.append(placeholder);
                setShowModal(false);
                setSearchQuery('');
            } else {
                api.open({
                    message: '',
                    description: 'No component is selected. Please select a component to add content..',
                    type: 'warning',
                    showProgress: true,
                    pauseOnHover: true,
                });
            }

        } else {
            console.error("Editor instance is not available");
        }
    }
    // #region Depth Entity Logic

    const toggleDepthFields = async (fieldlogicalname: string,
        e: React.MouseEvent<HTMLElement>,
        nextslide: string,
        entityref: any,
        fieldref: any): Promise<void> => {

        e.preventDefault();
        if (nextslide != "") {
            setCurrentSlide(Number(nextslide));
        }
        if (nextslide == '2') {
            setFirstlevelEntity(fieldlogicalname);
        }
        if (nextslide == "3") {
            setSecondlevelEntity(fieldlogicalname)
        }
        if (nextslide == "4") {
            setThirdlevelEntity(fieldlogicalname)
        }

        setDepthLevelEntities((prev) => ({
            ...prev,
            [fieldlogicalname]: {
                toggled: !prev[fieldlogicalname]?.toggled, // Toggle previous boolean value
                entityRef: entityref, // Ensure entityref is an array
                fieldRef: fieldref, // Ensure fieldref is an array
            },
        }));

        // Fetch fields only if not already fetched
        if (!fetchedDepthFields[fieldlogicalname]) {
            await fetchFieldsForDepthEntity(fieldlogicalname);
        }
    };

    const fetchFieldsForDepthEntity = async (fieldLogicalName: string) => {
        try {
            const response = await fetch(
                `https://emailboost.azurewebsites.net/api/entity/${fieldLogicalName}`
            );
            if (!response.ok) throw new Error("Failed to fetch fields");

            const jsonFields: FieldsApiResponse = await response.json();


            const fields = jsonFields.data.filter(
                (field) => field.displayName.localizedLabels.length > 0
            );

            setFetchedDepthFields((prev) => ({
                ...prev,
                [fieldLogicalName]: fields,
            }));
        } catch (error) {
            console.error("Error fetching fields:", error);
        }
    };

    // Search bar logic

    const filterEntities = (entities: EntityMergeField[]) => {
        if (!searchQuery.trim()) return entities;
        const query = searchQuery.toLowerCase();
        const filtered = entities.filter((entity) =>
            (entity.displayname?.toLowerCase().includes(query) || entity.logicalname.toLowerCase().includes(query))
        );
        return filtered.sort((a, b) => {
            const aDisplayName = a.displayname?.toLowerCase() || '';
            const aLogicalName = a.logicalname.toLowerCase();
            const bDisplayName = b.displayname?.toLowerCase() || '';
            const bLogicalName = b.logicalname.toLowerCase();

            const aIsExact = aDisplayName === query || aLogicalName === query;
            const bIsExact = bDisplayName === query || bLogicalName === query;

            if (aIsExact && !bIsExact) return -1;
            if (!aIsExact && bIsExact) return 1;
            if (aDisplayName.includes(query) && !bDisplayName.includes(query)) return -1;
            if (!aDisplayName.includes(query) && bDisplayName.includes(query)) return 1;
            return aDisplayName.localeCompare(bDisplayName);
        });
    };

    const filterFields = (fields: FieldRF[]) => {
        if (!searchQuery.trim()) return fields;
        const query = searchQuery.toLowerCase();
        const filtered = fields.filter((field) =>
            (field.displayName?.localizedLabels[0]?.label?.toLowerCase().includes(query) || field.logicalName.toLowerCase().includes(query))
        );
        return filtered.sort((a, b) => {
            const aDisplayName = a.displayName?.localizedLabels[0]?.label?.toLowerCase() || '';
            const aLogicalName = a.logicalName.toLowerCase();
            const bDisplayName = b.displayName?.localizedLabels[0]?.label?.toLowerCase() || '';
            const bLogicalName = b.logicalName.toLowerCase();

            const aIsExact = aDisplayName === query || aLogicalName === query;
            const bIsExact = bDisplayName === query || bLogicalName === query;

            if (aIsExact && !bIsExact) return -1;
            if (!aIsExact && bIsExact) return 1;
            if (aDisplayName.includes(query) && !bDisplayName.includes(query)) return -1;
            if (!aDisplayName.includes(query) && bDisplayName.includes(query)) return 1;
            return aDisplayName.localeCompare(bDisplayName);
        });
    };

    // const renderFields = (entity: EntityRF | primaryEntity) => {
    //     const entityName = 'name' in entity ? entity.name : "default-name";
    //     const filteredFields = filterFields(fetchedFields[entity.id] || []);
    //     return (
    //         <div className="list-group" style={{ width: "100%" }} id={`${entityName}-field-items`}>
    //             {filteredFields.length ? (
    //                 filteredFields.map((field: FieldRF) => (
    //                     <Row key={field.metadataId} align="middle" style={{ padding: "6px 15px" }}>
    //                         <Col span={20} style={{ padding: "6px 0" }}>
    //                             <Flex align="center" gap={8}>
    //                                 <span>{iconFinder(field.attributeTypeName?.value?.toLowerCase())}</span>
    //                                 <Text
    //                                     className="list-group-item test"
    //                                     data-entitylogicalname={field.entityLogicalName}
    //                                     data-datatype={field.attributeTypeName?.value?.toLowerCase()}
    //                                     data-fieldlogicalname={field.logicalName}
    //                                     style={{ margin: 0 }}
    //                                 >
    //                                     {field.displayName?.localizedLabels[0]?.label || field.logicalName}
    //                                     {field.displayName?.localizedLabels[0]?.label && field.logicalName ? (
    //                                         <Text type="secondary" style={{ marginLeft: 8, fontSize: 12 }}>
    //                                             ({field.logicalName})
    //                                         </Text>
    //                                     ) : null}
    //                                 </Text>
    //                             </Flex>
    //                         </Col>
    //                         <Col span={4} style={{ textAlign: "end", padding: "6px 0" }}>
    //                             {field.attributeTypeName?.value?.toLowerCase() === "lookuptype" ? (
    //                                 <RightOutlined
    //                                     style={{ cursor: "pointer" }}
    //                                     onClick={(e) => {
    //                                         e.preventDefault();
    //                                         const newSlide = currentSlide + 1;
    //                                         setBreadcrumbs(prev => [
    //                                             ...prev,
    //                                             ...(field.targets && field.targets.length > 0 ? [field.targets[0]] : [])
    //                                         ]);
    //                                         setfirstLevelSelectedField(field.logicalName);
    //                                         setCurrentSlide(newSlide);
    //                                         if (field.targets && field.targets.length > 0) {
    //                                             toggleDepthFields(field.targets[0], e, "2", entity, field);
    //                                         } else {
    //                                             console.warn("No targets available for this field");
    //                                         }
    //                                     }}
    //                                     size={16}
    //                                 />
    //                             ) : (
    //                                 <Copy
    //                                     style={{ cursor: "pointer" }}
    //                                     onClick={(e) => {
    //                                         e.preventDefault();
    //                                         pasteToEditor(e, field.entityLogicalName, field.logicalName);
    //                                     }}
    //                                     size={16}
    //                                 />
    //                             )}
    //                         </Col>
    //                     </Row>
    //                 ))
    //             ) : (
    //                 <Col span={24} style={{ textAlign: "center", padding: "16px 0" }}>
    //                     {fetchedFields[entity.id]?.length ? (
    //                         <Text>No fields match your search for "{searchQuery}" in {(entity.displayname || entity.logicalname).replace(/^./, (c) => c.toUpperCase())}</Text>
    //                     ) : (
    //                         <Spin tip="Loading fields..." size="small" />
    //                     )}
    //                 </Col>
    //             )}
    //         </div>
    //     );
    // };

    const renderFields = (entity: EntityRF | primaryEntity) => {
        const entityName = 'name' in entity ? entity.name : entity.logicalname;
        const displayName = 'displayname' in entity && entity.displayname ? entity.displayname : entityName;
        const filteredFields = filterFields(fetchedFields[entity.id] || []);
        return (
            <div className="list-group" style={{ width: "100%" }} id={`${entityName}-field-items`}>
                {filteredFields.length ? (
                    filteredFields.map((field: FieldRF) => (
                        <Row key={field.metadataId} align="middle" style={{ padding: "6px 15px" }}>
                            <Col span={20} style={{ padding: "6px 0" }}>
                                <Flex align="center" gap={8}>
                                    <span>{iconFinder(field.attributeTypeName?.value?.toLowerCase())}</span>
                                    <Text
                                        className="list-group-item test"
                                        data-entitylogicalname={field.entityLogicalName}
                                        data-datatype={field.attributeTypeName?.value?.toLowerCase()}
                                        data-fieldlogicalname={field.logicalName}
                                        style={{ margin: 0 }}
                                    >
                                        {field.displayName?.localizedLabels[0]?.label || field.logicalName}
                                        {field.displayName?.localizedLabels[0]?.label && field.logicalName ? (
                                            <Text type="secondary" style={{ marginLeft: 8, fontSize: 12 }}>
                                                ({field.logicalName})
                                            </Text>
                                        ) : null}
                                    </Text>
                                </Flex>
                            </Col>
                            <Col span={4} style={{ textAlign: "end", padding: "6px 0" }}>
                                {field.attributeTypeName?.value?.toLowerCase() === "lookuptype" ? (
                                    <RightOutlined
                                        style={{ cursor: "pointer" }}
                                        onClick={(e) => {
                                            e.preventDefault();
                                            const newSlide = currentSlide + 1;
                                            setBreadcrumbs(prev => [
                                                ...prev,
                                                ...(field.targets && field.targets.length > 0 ? [field.targets[0]] : [])
                                            ]);
                                            setfirstLevelSelectedField(field.logicalName);
                                            setCurrentSlide(newSlide);
                                            if (field.targets && field.targets.length > 0) {
                                                toggleDepthFields(field.targets[0], e, "2", entity, field);
                                            } else {
                                                console.warn("No targets available for this field");
                                            }
                                        }}
                                        size={16}
                                    />
                                ) : (
                                    <Copy
                                        style={{ cursor: "pointer" }}
                                        onClick={(e) => {
                                            e.preventDefault();
                                            pasteToEditor(e, field.entityLogicalName, field.logicalName);
                                        }}
                                        size={16}
                                    />
                                )}
                            </Col>
                        </Row>
                    ))
                ) : (
                    <Col span={24} style={{ textAlign: "center", padding: "16px 0" }}>
                        {fetchedFields[entity.id]?.length ? (
                            <Text>No fields match your search for "{searchQuery}" in {displayName.replace(/^./, (c: string) => c.toUpperCase())}</Text>
                        ) : (
                            <Spin tip="Loading fields..." size="small" />
                        )}
                    </Col>
                )}
            </div>
        );
    };

    const renderToggleIcon = (isOpen: boolean) =>
        isOpen ? <DownOutlined style={{ fontSize: 12 }} /> : <RightOutlined style={{ fontSize: 12 }} />;

    return (

        <Modal
            title="Personalization"
            open={showModal}
            onCancel={() => setShowModal(false)}
            footer={
                currentSlide === 0 ? (
                    <Flex justify="flex-end" gap={10}>
                        <Button type="primary" onClick={handleSave} disabled>
                            Save
                        </Button>
                        <Button onClick={handleCancel}>Cancel</Button>
                    </Flex>
                ) : (
                    <Flex justify="space-between">
                        <Button
                            onClick={() => {

                                setCurrentSlide((prev) => Math.max(0, prev - 1))
                                setBreadcrumbs(prev => {
                                    if (prev.length > 1) {
                                        const updated = prev.slice(0, -1);
                                        setCurrentSlide(updated.length);
                                        return updated;
                                    }
                                    return prev;
                                });
                            }
                            }
                            disabled={currentSlide === 0}
                        >
                            &larr; Back
                        </Button>
                        {/* <Button
                            type="primary"
                            onClick={() => setCurrentSlide((prev) => Math.min(MAX_SLIDE_INDEX, prev + 1))}
                            disabled={currentSlide === MAX_SLIDE_INDEX}
                        >
                            Next &rarr;
                        </Button> */}
                    </Flex>
                )
            }
            destroyOnClose
            width={520} // or any width you prefer
            style={{ top: 50 }} // keeps modal slightly below top
            styles={{
                body: {
                    maxHeight: '60vh',
                    overflowY: 'auto',
                    padding: '0 24px',
                },
            }}
        >
            <Search
                placeholder="Search entities or fields..."
                prefix={<SearchIcon size={16} />}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onSearch={(value) => setSearchQuery(value)}
                style={{ margin: '16px 24px', width: 'calc(100% - 48px)' }}
                enterButton
            />

            {contextHolder}

            {
                currentSlide >= 2 && (
                    <Breadcrumb separator=">">
                        {breadcrumbs.map((label, index) => (
                            <Breadcrumb.Item key={index}>
                                <a onClick={() => handleBreadcrumbClick(index)}>
                                    {label.charAt(0).toUpperCase() + label.slice(1)}
                                </a>
                            </Breadcrumb.Item>
                        ))}
                    </Breadcrumb>

                )
            }

            {/* Choose Attribute + Save and Cancel button */}
            {currentSlide === 0 && (
                <>
                    {/* <h3 style={{ marginBottom: 16 }}>Personalization</h3> */}

                    <div style={{ padding: "0 24px", marginTop: 16 }}>
                        <h4>The personalization info comes from</h4>
                        <div style={{ display: "flex", gap: 0 }}>
                            <Button
                                onClick={() => setCurrentSlide(1)}
                                style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    padding: '0 12px',
                                    borderRadius: '6px',
                                    border: '1px solid #d9d9d9',
                                    backgroundColor: '#ffffff',
                                    color: '#000000',
                                    gap: '8px',
                                    boxShadow: 'none',
                                    width: '100%'
                                }}
                            >
                                Choose Attribute
                                <RightOutlined />
                            </Button>
                        </div>
                        {/* Input Fields Section */}
                        <div style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                            {/* <div>
                                <label style={{ display: 'block', marginBottom: '4px' }}>Display Name</label>
                                <Input
                                    placeholder="Enter display name"
                                    value={displayName}
                                    onChange={(e) => setDisplayName(e.target.value)}
                                />
                            </div> */}
                            {/* <div>
                                <label style={{ display: 'block', marginBottom: '4px' }}>Default Value (shown when no data is available)</label>
                                <Input
                                    placeholder="Enter default value"
                                    value={defaultValue}
                                    onChange={(e) => setDefaultValue(e.target.value)}
                                />
                            </div> */}
                        </div>
                    </div>
                </>
            )}

            {/* Audience and Other Tables + Eg Audience > Contact > Fields (FIrst Level) */}
            {currentSlide === 1 && (
                <div style={{ maxHeight: "60vh", overflowY: "auto", padding: "0 24px" }}>
                    <Row gutter={[0, 8]}>
                        <Col span={24}>
                            <div
                                onClick={togglePrimaryEntity}
                                style={{
                                    display: "flex",
                                    alignItems: "center",
                                    cursor: "pointer",
                                    fontSize: 14,
                                    padding: "6px 0",
                                }}
                            >
                                {renderToggleIcon(isPrimaryEntityOpen)}&nbsp;Audience
                            </div>
                        </Col>
                        {isPrimaryEntityOpen && (
                            <Col span={24}>
                                {primaryEntities.length ? (
                                    primaryEntities.map((entity: primaryEntity) => (
                                        <div key={entity.id} style={{ marginBottom: 8 }}>
                                            <div
                                                style={{
                                                    cursor: "pointer",
                                                    padding: "6px 15px",
                                                    background: "transparent",
                                                }}
                                                onClick={(e) => toggleFields(entity.id, e, entity, "")}
                                            >
                                                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                                    {renderToggleIcon(expandedEntities[entity.id])}
                                                    <span>
                                                        {(entity.displayname || entity.logicalname).replace(/^./, (c) => c.toUpperCase())}
                                                    </span>
                                                </div>
                                            </div>
                                            {expandedEntities[entity.id] && renderFields(entity)}
                                        </div>
                                    ))
                                ) : (
                                    <Col span={24} style={{ textAlign: "center", padding: "16px 0" }}>
                                        <Text>No entities available</Text>
                                    </Col>
                                )}
                            </Col>
                        )}
                        <Col span={24}>
                            <div
                                onClick={toggleOtherEntity}
                                style={{
                                    display: "flex",
                                    alignItems: "center",
                                    cursor: "pointer",
                                    fontSize: 14,
                                    padding: "6px 0",
                                }}
                            >
                                {renderToggleIcon(isOtherEntityOpen)}&nbsp;Other&nbsp;Tables
                            </div>
                        </Col>
                        {isOtherEntityOpen && (
                            <Col span={24}>
                                {otherEntities.length ? (
                                    otherEntities.map((entity: primaryEntity) => (
                                        <div key={entity.id} style={{ marginBottom: 8 }}>
                                            <div
                                                style={{
                                                    cursor: "pointer",
                                                    padding: "6px 15px",
                                                    background: "transparent",
                                                }}
                                                onClick={(e) => toggleFields(entity.id, e, entity, "")}
                                            >
                                                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                                    {renderToggleIcon(expandedEntities[entity.id])}
                                                    <span>
                                                        {(entity.displayname || entity.logicalname).replace(/^./, (c) => c.toUpperCase())}
                                                    </span>
                                                </div>
                                            </div>
                                            {expandedEntities[entity.id] && renderFields(entity)}
                                        </div>
                                    ))
                                ) : (
                                    <Col span={24} style={{ textAlign: "center", padding: "16px 0" }}>
                                        <Text>No entities available</Text>
                                    </Col>
                                )}
                            </Col>
                        )}
                    </Row>
                </div>
            )}

            {/* Account > All Field (Seconed Level) */}
            {currentSlide === 2 && (
                <>
                    {Array.isArray(fetchedDepthFields[firstLevelEntitySelected]) && filterFields(fetchedDepthFields[firstLevelEntitySelected] as FieldRF[]).length > 0 ? (
                        filterFields(fetchedDepthFields[firstLevelEntitySelected] as FieldRF[]).map((field: FieldRF) => (
                            <Row key={field.metadataId} align="middle" style={{ padding: "6px 15px" }}>
                                <Col span={20} style={{ padding: "6px 0" }}>
                                    <div className="list-group" style={{ width: "100%" }} id={`${field.metadataId}-field-items`}>
                                        <Flex align="center" gap={8}>
                                            <span>{iconFinder(field.attributeTypeName?.value?.toLowerCase())}</span>
                                            <Text
                                                className="list-group-item test"
                                                data-entitylogicalname={field.entityLogicalName}
                                                data-datatype={field.attributeTypeName?.value?.toLowerCase()}
                                                data-fieldlogicalname={field.logicalName}
                                                style={{ margin: 0 }}
                                            >
                                                {field.displayName?.localizedLabels[0]?.label || field.logicalName}
                                                {field.displayName?.localizedLabels[0]?.label && field.logicalName ? (
                                                    <Text type="secondary" style={{ marginLeft: 8, fontSize: 12 }}>
                                                        ({field.logicalName})
                                                    </Text>
                                                ) : null}
                                            </Text>
                                        </Flex>
                                    </div>
                                </Col>
                                <Col span={4} style={{ textAlign: "end", padding: "6px 0" }}>
                                    {field.attributeTypeName?.value?.toLowerCase() === "lookuptype" ? (
                                        <RightOutlined
                                            style={{ cursor: "pointer" }}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                const newSlide = currentSlide + 1;
                                                setBreadcrumbs(prev => [
                                                    ...prev,
                                                    ...(field.targets && field.targets.length > 0 ? [field.targets[0]] : [])
                                                ]);
                                                setsecondLevelSelectedField(field.logicalName);
                                                setCurrentSlide(newSlide);
                                                if (field.targets && field.targets.length > 0) {
                                                    toggleDepthFields(field.targets[0], e, "3", DepthLevelEntities[field.entityLogicalName].entityRef, field);
                                                } else {
                                                    console.warn("field.targets is undefined or empty");
                                                }
                                            }}
                                            size={16}
                                        />
                                    ) : (
                                        <Copy
                                            style={{ cursor: "pointer" }}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                PasteToEditorForDepthEntity(e, field.entityLogicalName, field.logicalName);
                                            }}
                                            size={16}
                                        />
                                    )}
                                </Col>
                            </Row>
                        ))
                    ) : (
                        <Col span={24} style={{ textAlign: "center", padding: "16px 0" }}>
                            {Array.isArray(fetchedDepthFields[firstLevelEntitySelected]) && fetchedDepthFields[firstLevelEntitySelected].length ? (
                                <Text>No fields match your search for "{searchQuery}" in {firstLevelEntitySelected}</Text>
                            ) : (
                                <Spin tip="Loading fields..." size="small" />
                            )}
                        </Col>
                    )}
                </>
            )}

            {/* Third Level */}
            {currentSlide === 3 && (
                <>
                    {Array.isArray(fetchedDepthFields[secondLevelEntitySelected]) && filterFields(fetchedDepthFields[secondLevelEntitySelected] as FieldRF[]).length > 0 ? (
                        filterFields(fetchedDepthFields[secondLevelEntitySelected] as FieldRF[]).map((field: FieldRF) => (
                            <Row key={field.metadataId} align="middle" style={{ padding: "6px 15px" }}>
                                <Col span={20} style={{ padding: "6px 0" }}>
                                    <div className="list-group" style={{ width: "100%" }} id={`${field.metadataId}-field-items`}>
                                        <Flex align="center" gap={8}>
                                            <span>{iconFinder(field.attributeTypeName?.value?.toLowerCase())}</span>
                                            <Text
                                                className="list-group-item test"
                                                data-entitylogicalname={field.entityLogicalName}
                                                data-datatype={field.attributeTypeName?.value?.toLowerCase()}
                                                data-fieldlogicalname={field.logicalName}
                                                style={{ margin: 0 }}
                                            >
                                                {field.displayName?.localizedLabels[0]?.label || field.logicalName}
                                                {field.displayName?.localizedLabels[0]?.label && field.logicalName ? (
                                                    <Text type="secondary" style={{ marginLeft: 8, fontSize: 12 }}>
                                                        ({field.logicalName})
                                                    </Text>
                                                ) : null}
                                            </Text>
                                        </Flex>
                                    </div>
                                </Col>
                                <Col span={4} style={{ textAlign: "end", padding: "6px 0" }}>
                                    {field.attributeTypeName?.value?.toLowerCase() === "lookuptype" ? (
                                        <RightOutlined
                                            style={{ cursor: "pointer" }}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                const newSlide = currentSlide + 1;
                                                setBreadcrumbs(prev => [
                                                    ...prev,
                                                    ...(field.targets && field.targets.length > 0 ? [field.targets[0]] : [])
                                                ]);
                                                setthirdLevelSelectedField(field.logicalName);
                                                setCurrentSlide(newSlide);
                                                if (field.targets?.length) {
                                                    toggleDepthFields(field.targets[0], e, "4", DepthLevelEntities[field.entityLogicalName].entityRef, field);
                                                } else {
                                                    console.warn("field.targets is undefined or empty");
                                                }
                                            }}
                                            size={16}
                                        />
                                    ) : (
                                        <Copy
                                            style={{ cursor: "pointer" }}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                PasteToEditorForDepthEntity(e, field.entityLogicalName, field.logicalName);
                                            }}
                                            size={16}
                                        />
                                    )}
                                </Col>
                            </Row>
                        ))
                    ) : (
                        <Col span={24} style={{ textAlign: "center", padding: "16px 0" }}>
                            {Array.isArray(fetchedDepthFields[secondLevelEntitySelected]) && fetchedDepthFields[secondLevelEntitySelected].length ? (
                                <Text>No fields match your search for "{searchQuery}" in {secondLevelEntitySelected}</Text>
                            ) : (
                                <Spin tip="Loading fields..." size="small" />
                            )}
                        </Col>
                    )}
                </>
            )}

            {/* Fourth Level */}
            {currentSlide === 4 && (
                <>
                    {Array.isArray(fetchedDepthFields[thirdLevelEntitySelected]) && filterFields(fetchedDepthFields[thirdLevelEntitySelected] as FieldRF[]).length > 0 ? (
                        filterFields(fetchedDepthFields[thirdLevelEntitySelected] as FieldRF[]).map((field: FieldRF) => (
                            <Row key={field.metadataId} align="middle" style={{ padding: "6px 15px" }}>
                                <Col span={20} style={{ padding: "6px 0" }}>
                                    <div className="list-group" style={{ width: "100%" }} id={`${field.metadataId}-field-items`}>
                                        <Flex align="center" gap={8}>
                                            <span>{iconFinder(field.attributeTypeName?.value?.toLowerCase())}</span>
                                            <Text
                                                className="list-group-item test"
                                                data-entitylogicalname={field.entityLogicalName}
                                                data-datatype={field.attributeTypeName?.value?.toLowerCase()}
                                                data-fieldlogicalname={field.logicalName}
                                                style={{ margin: 0 }}
                                            >
                                                {field.displayName?.localizedLabels[0]?.label || field.logicalName}
                                                {field.displayName?.localizedLabels[0]?.label && field.logicalName ? (
                                                    <Text type="secondary" style={{ marginLeft: 8, fontSize: 12 }}>
                                                        ({field.logicalName})
                                                    </Text>
                                                ) : null}
                                            </Text>
                                        </Flex>
                                    </div>
                                </Col>
                                <Col span={4} style={{ textAlign: "end", padding: "6px 0" }}>
                                    {field.attributeTypeName?.value?.toLowerCase() === "lookuptype" ? (
                                        <RightOutlined
                                            style={{ cursor: "pointer" }}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                const newSlide = currentSlide + 1;
                                                setBreadcrumbs(prev => [
                                                    ...prev,
                                                    ...(field.targets && field.targets.length > 0 ? [field.targets[0]] : [])
                                                ]);
                                                setfourthLevelSelectedField(field.logicalName);
                                                setCurrentSlide(newSlide);
                                                if (field.targets && field.targets.length > 0) {
                                                    toggleDepthFields(field.targets[0], e, "5", DepthLevelEntities[field.entityLogicalName]?.entityRef, field);
                                                } else {
                                                    console.warn("field.targets is undefined or empty");
                                                }
                                            }}
                                            size={16}
                                        />
                                    ) : (
                                        <Copy
                                            style={{ cursor: "pointer" }}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                PasteToEditorForDepthEntity(e, field.entityLogicalName, field.logicalName);
                                            }}
                                            size={16}
                                        />
                                    )}
                                </Col>
                            </Row>
                        ))
                    ) : (
                        <Col span={24} style={{ textAlign: "center", padding: "16px 0" }}>
                            {Array.isArray(fetchedDepthFields[thirdLevelEntitySelected]) && fetchedDepthFields[thirdLevelEntitySelected].length ? (
                                <Text>No fields match your search for "{searchQuery}" in {thirdLevelEntitySelected}</Text>
                            ) : (
                                <Spin tip="Loading fields..." size="small" />
                            )}
                        </Col>
                    )}
                </>
            )}

            {
                currentSlide === 5 && (
                    <>
                        <div style={{ textAlign: "center", padding: "50px 0" }}>
                            <h2>Work in Progress</h2>
                            <p>We're building this section. Stay tuned!</p>
                        </div>
                    </>
                )
            }
        </Modal >

    );
};

export default MergeFieldModal;
