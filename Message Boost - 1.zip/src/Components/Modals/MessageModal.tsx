import React from "react";
import { motion } from "framer-motion";
import "./MessageModal.css"; // Import the CSS file

interface MessageModalProps {
    message: string;
    color: "red" | "green" | "blue" | "yellow"; // Adjust colors as needed
    onClose: () => void;
}

const MessageModal: React.FC<MessageModalProps> = ({ message, color, onClose }) => {
    return (
        <div className="modal-overlay">
            <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="modal-container"
            >
                <div className={`modal-message ${color}-text`}>{message}</div>
                <button className={`modal-button ${color}-button`} onClick={onClose}>
                    Close
                </button>
            </motion.div>
        </div>
    );
};

export default MessageModal;
