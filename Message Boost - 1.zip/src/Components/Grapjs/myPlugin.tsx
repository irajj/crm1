import { Editor } from "grapesjs";

export default function myPlugin(editor: Editor): void {
    const panelId = "options";

    // Add button directly using the recommended API
    editor.Panels.addButton(panelId, {
        id: "open-popup",
        className: "fa fa-window-maximize",
        command: "open-popup-command",
        attributes: { title: "Open Popup" },
    });

    // Add the command that triggers your popup
    editor.Commands.add("open-popup-command", {
        run(_, sender) {
            sender?.set("active", false);
            const event = new CustomEvent("openGrapesPopup");
            window.dispatchEvent(event);
        },
    });

}
