// import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import PagesLayout from "./layouts/PagesLayout";

import Campaigns from "./pages/campaigns/Campaigns";
import Connections from "./pages/connections/Connections";
import Settings from "./pages/settings/Settings";
import Templates from "./pages/templates/Templates";
import NewTemplates from "./pages/templates/NewTemplates";
import Analytics from "./pages/analytics/Analytics";
import NewCampaign from "./pages/campaigns/new/NewCampaign";
import CreateConnections from "./pages/connections/createconnections/CreateConnections";

const AppRoutes = () => {
    return (
        <HashRouter>
            <Routes>
                <Route path="/" element={<PagesLayout />}>
                    <Route index element={<Navigate to="analytics" replace />} />
                    <Route path="analytics" element={<Analytics />} />
                    <Route path="campaigns" element={<Campaigns />} />
                    <Route path="campaigns/new" element={<NewCampaign />} />
                    <Route path="campaigns/:id" element={<NewCampaign />} />
                    <Route path="connections" element={<Connections />} />
                    <Route path="createconnections" element={<CreateConnections />} />
                    <Route path="createconnections/:id" element={<CreateConnections />} />
                    <Route path="settings" element={<Settings />} />
                    <Route path="templates" element={<Templates />} />
                    <Route path="templates/new" element={<NewTemplates />} />
                    <Route path="templates/:id" element={<NewTemplates />} />
                </Route>
            </Routes>
        </HashRouter>
    );
};

export default AppRoutes;
