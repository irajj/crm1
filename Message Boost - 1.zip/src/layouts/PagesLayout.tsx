// Date:28-04-25
// Changed the button of sidebar collapse and positioned it in top
import { Layout, Menu, theme } from "antd";
import { Link, Outlet, useLocation } from "react-router-dom";
import {
  Users,
  Settings,
  LayoutTemplate,
  RefreshCcwDot,
  ChartColumn,
  MenuIcon,
  LinkIcon,
} from "lucide-react";
// import { FrownOutlined } from "@ant-design/icons";
import { Footer } from "antd/es/layout/layout";
import { useState } from "react";

const { Header, Content, Sider } = Layout;

const siderStyle: React.CSSProperties = {
  overflow: "auto",
  height: "100vh",
  position: "sticky",
  insetInlineStart: 0,
  top: 0,
  bottom: 0,
  scrollbarWidth: "thin",
  background: "#ffffff",
  // scrollbarGutter: 'stable',
};

const PagesLayout = () => {
  const {
    token: { colorBgContainer },
  } = theme.useToken();

  const [collapsed, setCollapsed] = useState(false);

  const items = [
    {
      key: "analytics",
      name: "Analytics",
      icon: <ChartColumn size={16} />,
      path: "/analytics",
    },
    {
      key: "campaigns",
      name: "Campaigns",
      icon: <RefreshCcwDot size={16} />,
      path: "/campaigns",
    },
    {
      key: "templates",
      name: "Templates",
      icon: <LayoutTemplate size={16} />,
      path: "/templates",
    },
    {
      key: "connections",
      name: "Connections",
      icon: <LinkIcon size={16} />,
      path: "/connections",
    },
    // {
    //   key: "test",
    //   name: "Test",
    //   icon: <FlaskConical size={16} />,
    //   path: "/test",
    // },

    // {
    //   key: "settings",
    //   name: "Settings",
    //   icon: <Settings size={16} />,
    //   path: "/settings",
    // },
  ];

  const location = useLocation();
  // const [userId, setUserId] = useState<string | null>(null);
  // useEffect(() => {
  //   try {
  //     function handleMessage(event: MessageEvent) {
  //       if (event.data?.type === "SET_CONTEXT") {
  //         setUserId(event.data.userId);
  //         console.log("Received context from parent:", event.data.userId);
  //         console.log("Received context from parent:", event.data.userName);
  //       }
  //     }
  //     if (import.meta.env.DEV) {
  //       console.log("Dev mode: setting dummy user");
  //       setUserId("dev-user");
  //     }

  //     window.addEventListener("message", handleMessage);
  //     return () => window.removeEventListener("message", handleMessage);
  //   }
  //   catch (ex) {
  //     console.log(ex);
  //   }
  // }, []);

  // return !userId ? (
  //   <div style={{ padding: "2rem" }}>
  //     <Result
  //       status="403"
  //       icon={<FrownOutlined style={{ color: "#ff4d4f", fontSize: "3rem" }} />}
  //       title="Unauthorized Access"
  //       subTitle="Sorry, you are not authorized to access this page. Please contact your administrator."
  //       extra={
  //         <Button type="primary" onClick={() => window.location.reload()}>
  //           Retry
  //         </Button>
  //       }
  //     />
  //   </div>
  // ) :
  return (
    <Layout style={{ minHeight: "100vh" }}>
      <div style={{ borderRight: "1px solid #dde4e9" }}>
        <Sider
          collapsible
          collapsed={collapsed}
          onCollapse={(value) => setCollapsed(value)}
          theme="light"
          breakpoint="lg"
          style={siderStyle}
          trigger={null}
        >
          <div
            className="demo-logo-vertical"
            style={{
              height: "64px",
              maxHeight: "3rem",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: "bold",
              fontSize: "1.4rem",
              borderBottom: "1px solid #dde4e9",
            }}
          >
            {!collapsed && (
              <Link
                to="/"
                style={{
                  textDecoration: "none",
                  color: "inherit",
                  cursor: "pointer",
                }}
              >
                EMAILBOOST
              </Link>
            )}
            {collapsed && (
              <Link
                to="/"
                style={{
                  textDecoration: "none",
                  color: "inherit",
                  cursor: "pointer",
                }}
              >
                EB
              </Link>
            )}
          </div>

          {/* menu for collapse button */}
          <Menu style={{ border: "none" }} mode="inline" selectedKeys={[]}>
            <Menu.Item
              onClick={() => {
                setCollapsed(!collapsed);
              }}
              key={"collapse"}
              icon={<MenuIcon size={16} />}
            ></Menu.Item>
          </Menu>

          {/* menu for page routes */}
          <Menu
            style={{ border: "none" }}
            mode="inline"
            selectedKeys={[location.pathname]}
            items={items.map(({ name, icon, path }) => ({
              key: path,
              icon,
              label: <Link to={path}>{name}</Link>,
            }))}
          />
        </Sider>
      </div>
      <Layout>
        <Header
          style={{
            background: colorBgContainer,
            position: "sticky",
            top: 0,
            zIndex: 10,
            width: "100%",
            maxHeight: "3rem",
            borderBottom: "1px solid #dde4e9",
          }}
        >
          {/* <div style={{ fontSize: "0.9rem" }}>
            Logged in as: <strong>{userId}</strong>
          </div> */}
        </Header>
        <Content>
          <Outlet />
        </Content>
        {/* <Footer style={{ textAlign: "center", padding: "0.5rem 1rem " }}>
          EmailBoost ©{new Date().getFullYear()} Created by Advic
        </Footer> */}
      </Layout>
    </Layout>
  );
};

export default PagesLayout;
