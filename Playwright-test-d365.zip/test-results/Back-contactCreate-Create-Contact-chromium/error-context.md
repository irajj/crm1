# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Back-contactCreate.spec.js >> Create Contact
- Location: tests\Back-contactCreate.spec.js:17:5

# Error details

```
Error: locator.click: Target page, context or browser has been closed
Call log:
  - waiting for locator('[data-id=\'email.fieldControl-mail-text-input\']')

```

# Test source

```ts
  1  | // Name: Create a Contact
  2  | // Description: Test to create a new Contact from UI
  3  | //      1. Open Dynamics 365 App
  4  | //      2. Navigate to the Site Map and Select Contacts
  5  | //      3. Click on New Contact
  6  | //      4. Fill the Contact details
  7  | //      5. Save Contact
  8  | // App: Dynamics 365 CRM
  9  | // =====================================================================
  10 | 
  11 | import { test, expect } from '@playwright/test';
  12 | import dotenv from 'dotenv';
  13 | dotenv.config();
  14 | import { subAreaMenuSelectors, FormControlSelectors, CommandBarFormButtonsSelectors } from "../selectors/commonselectors.json";
  15 | import { navigateToApps, stringFormat, waitUntilAppIdle } from '../utils/common';
  16 | 
  17 | test('Create Contact', async ({ page }) => {
  18 |   // Navigating to the App (replace with your AppId for Sales Hub or main app)
  19 |   let appId = process.env.CONTACT_APPID;
  20 |   await navigateToApps(page, stringFormat(appId), 'Contacts');
  21 |   // End of Navigation
  22 | 
  23 |   // Opening Sub Area - Contacts
  24 |   await page.locator(stringFormat(subAreaMenuSelectors.DynamicSubAreaMenuSelector, "New Group", "Contacts")).click();
  25 | 
  26 |   // Click on New Contact
  27 |   await page.locator(stringFormat(CommandBarFormButtonsSelectors.DynamicCommandBarButtonSelector, 'New')).click();
  28 | 
  29 |   // Prepare data
  30 |   const firstName = 'John';
  31 |   const lastName = `Doe${Date.now()}`;
  32 |   const email = `john.${Date.now()}@example.com`;
  33 |   const phone = '9876543210';
  34 | 
  35 |   // Fill Contact First Name
  36 |   await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_firstname')).click();
  37 |   await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_firstname')).fill(firstName);
  38 | 
  39 |   // Fill Contact Last Name
  40 |   await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_lastname')).click();
  41 |   await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_lastname')).fill(lastName);
  42 | 
  43 |   // Fill Contact Email
> 44 |   await page.locator(stringFormat(FormControlSelectors.MailTextBox, 'email')).click();
     |                                                                               ^ Error: locator.click: Target page, context or browser has been closed
  45 |   await page.locator(stringFormat(FormControlSelectors.MailTextBox, 'email')).fill(email);
  46 | 
  47 |   // Fill Contact Phone
  48 |   await page.locator(stringFormat(FormControlSelectors.PhoneTextBox, 'mobilephone')).click();
  49 |   await page.locator(stringFormat(FormControlSelectors.PhoneTextBox, 'mobilephone')).fill(phone);
  50 | 
  51 |   // Save Contact
  52 |   await page.locator(stringFormat(CommandBarFormButtonsSelectors.SaveButton)).click();
  53 | 
  54 |   await waitUntilAppIdle(page);
  55 | 
  56 |   // Verify Contact fullname is visible after save
  57 |   await page.locator(stringFormat(FormControlSelectors.TextBoxValueSelector, 'fullname')).waitFor({ state: 'visible' });
  58 |   let contactName = await page.locator(stringFormat(FormControlSelectors.TextBoxValueSelector, 'fullname')).inputValue();
  59 |   // Accept either 'First Last' or 'Last, First' formats
  60 |   expect(contactName).toMatch(new RegExp(`${firstName}.*${lastName}|${lastName}.*${firstName}`));
  61 |   console.log(stringFormat('CREATED A NEW CONTACT: {0}', contactName));
  62 | });
  63 | 
```