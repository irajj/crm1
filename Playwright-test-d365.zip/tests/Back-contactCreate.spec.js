// Name: Create a Contact
// Description: Test to create a new Contact from UI
//      1. Open Dynamics 365 App
//      2. Navigate to the Site Map and Select Contacts
//      3. Click on New Contact
//      4. Fill the Contact details
//      5. Save Contact
// App: Dynamics 365 CRM
// =====================================================================

import { test, expect } from '@playwright/test';
import dotenv from 'dotenv';
dotenv.config();
import { subAreaMenuSelectors, FormControlSelectors, CommandBarFormButtonsSelectors } from "../selectors/commonselectors.json";
import { navigateToApps, stringFormat, waitUntilAppIdle } from '../utils/common';

test('Create Contact', async ({ page }) => {
  // Navigating to the App (replace with your AppId for Sales Hub or main app)
  let appId = process.env.CONTACT_APPID;
  await navigateToApps(page, stringFormat(appId), 'Contacts');
  // End of Navigation

  // Opening Sub Area - Contacts
  await page.locator(stringFormat(subAreaMenuSelectors.DynamicSubAreaMenuSelector, "New Group", "Contacts")).click();

  // Click on New Contact
  await page.locator(stringFormat(CommandBarFormButtonsSelectors.DynamicCommandBarButtonSelector, 'New')).click();

  // Prepare data
  const firstName = 'John';
  const lastName = `Doe${Date.now()}`;
  const email = `john.${Date.now()}@example.com`;
  const phone = '9876543210';

  // Fill Contact First Name
  await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_firstname')).click();
  await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_firstname')).fill(firstName);

  // Fill Contact Last Name
  await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_lastname')).click();
  await page.locator(stringFormat(FormControlSelectors.TextBox, 'fullname_compositionLinkControl_lastname')).fill(lastName);

  // Fill Contact Email
  await page.locator(stringFormat(FormControlSelectors.MailTextBox, 'email')).click();
  await page.locator(stringFormat(FormControlSelectors.MailTextBox, 'email')).fill(email);

  // Fill Contact Phone
  await page.locator(stringFormat(FormControlSelectors.PhoneTextBox, 'mobilephone')).click();
  await page.locator(stringFormat(FormControlSelectors.PhoneTextBox, 'mobilephone')).fill(phone);

  // Save Contact
  await page.locator(stringFormat(CommandBarFormButtonsSelectors.SaveButton)).click();

  await waitUntilAppIdle(page);

  // Verify Contact fullname is visible after save
  await page.locator(stringFormat(FormControlSelectors.TextBoxValueSelector, 'fullname')).waitFor({ state: 'visible' });
  let contactName = await page.locator(stringFormat(FormControlSelectors.TextBoxValueSelector, 'fullname')).inputValue();
  // Accept either 'First Last' or 'Last, First' formats
  expect(contactName).toMatch(new RegExp(`${firstName}.*${lastName}|${lastName}.*${firstName}`));
  console.log(stringFormat('CREATED A NEW CONTACT: {0}', contactName));
});
