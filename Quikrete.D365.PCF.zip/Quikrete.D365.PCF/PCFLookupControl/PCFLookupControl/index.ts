import * as React from "react";
import {  IInputs, IOutputs } from "./generated/ManifestTypes";
import { DynamicLookup, IDynamicLookupProps } from "./DynamicLookup";
import { createRoot, Root } from 'react-dom/client';
import { webLightTheme } from "@fluentui/tokens";

export class QuikreteLookupControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _context: ComponentFramework.Context<IInputs>;

    private _container: HTMLDivElement;
    private _reactRoot: Root;
    private _notifyOutputChanged: () => void;
    private _guidValue: string | undefined;
    private _nameValue: string | undefined;


    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this._context = context;
        this._notifyOutputChanged = notifyOutputChanged;
        this._container = container;
        this._reactRoot = createRoot(this._container);
        // Initialize values from bound fields
        this._guidValue = context.parameters.guidField.raw || undefined;
        this._nameValue = context.parameters.nameField.raw || undefined;

    }

    
    public updateView(context: ComponentFramework.Context<IInputs>) {
        const props: IDynamicLookupProps = {
            context: context,
            targetEntity: context.parameters.targetEntity.raw || "",
            primaryId: context.parameters.primaryId.raw || "",
            primaryName: context.parameters.primaryName.raw || "",
            guidValue: context.parameters.guidField.raw || "",
            nameValue: context.parameters.nameField.raw || "",
            
            parentFilterEntity: context.parameters.parentFilterEntity.raw || "",
            filterValue: context.parameters.filterValue.raw || "",
            
            isDisabled: context.mode.isControlDisabled,
            isVisible: context.mode.isVisible,
            onSelectionChange: this.onSelectionChange.bind(this),
            theme: context.fluentDesignLanguage?.tokenTheme || webLightTheme
        };
        const element =  React.createElement(DynamicLookup, props);
        this._reactRoot.render(element);
    }

    private onSelectionChange(guid: string | undefined, name: string | undefined): void {
        this._guidValue = guid;
        this._nameValue = name;
        this._notifyOutputChanged();
    }

    public getOutputs(): IOutputs {
        return {
            guidField: this._guidValue,
            nameField: this._nameValue
        };
    }

    public destroy(): void {
        // Clean up
    }
}