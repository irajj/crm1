import * as React from "react";
import {
    FluentProvider,
    Combobox,
    Option,
    Theme,
    makeStyles,
} from "@fluentui/react-components";
import { IInputs } from "./generated/ManifestTypes";

export interface IDynamicLookupProps {
    context: ComponentFramework.Context<IInputs>;
    targetEntity: string;
    primaryId: string;
    primaryName: string;
    guidValue: string;
    nameValue: string;

    parentFilterEntity: string;
    filterValue: string;

    isDisabled: boolean;
    isVisible: boolean;
    onSelectionChange: (guid: string | undefined, name: string | undefined) => void;
    theme?: Theme;
}

interface ILookupRecord {
    id: string;
    name: string;
}

const useStyles = makeStyles({
    container: {
        width: "100%",
        minWidth: "200px"
    },
    combobox: {
        width: "100%"
    }
});

export const DynamicLookup: React.FC<IDynamicLookupProps> = (props) => {
    const styles = useStyles();
    const [options, setOptions] = React.useState<ILookupRecord[]>([]);
    const [isLoading, setIsLoading] = React.useState(false);
    const [searchText, setSearchText] = React.useState(props.nameValue || "");
    const [selectedValue, setSelectedValue] = React.useState<string>(props.nameValue || "");

    // Update search text when prop changes
    React.useEffect(() => {
        if (props.nameValue !== searchText) {
            setSearchText(props.nameValue || "");
            setSelectedValue(props.nameValue || "");
        }
    }, [props.nameValue]);

    // Search function with debounce
    const searchRecords = React.useCallback(
        async (searchTerm: string, override = false) => {

            console.log(`Called searchRecords for ${props.targetEntity}`);

            if (!override) {
                if (!searchTerm || searchTerm.length < 2 || !props.targetEntity || !props.primaryId || !props.primaryName) {
                    setOptions([]);
                    return;
                }
            }

            setIsLoading(true);
            try {
                // Build filter criteria
                let filterCriteria = `startswith(${props.primaryName},'${searchTerm}')`;

                // Add parent filter if filterValue and parentFilterEntity fields are provided
                if (props.filterValue && props.parentFilterEntity && props.parentFilterEntity != props.targetEntity) {
                    filterCriteria += ` and _${props.parentFilterEntity}_value eq ${props.filterValue}`;
                }

                const query = `?$select=${props.primaryId},${props.primaryName}&$filter=${filterCriteria}&$top=10`;
                const result = await props.context.webAPI.retrieveMultipleRecords(props.targetEntity, query);

                const records: ILookupRecord[] = result.entities.map((entity: any) => ({
                    id: entity[props.primaryId],
                    name: entity[props.primaryName] || ""
                }));

                setOptions(records);
            } catch (error) {
                console.error("Error searching records:", error);
                setOptions([]);
            } finally {
                setIsLoading(false);
            }
        },
        [props.context, props.targetEntity, props.primaryId, props.primaryName, props.filterValue, props.parentFilterEntity]
    );

    // Debounced search
    React.useEffect(() => {
        const timeoutId = setTimeout(() => {
            searchRecords(searchText);
        }, 300);

        return () => clearTimeout(timeoutId);
    }, [searchText, searchRecords]);

    // // Trigger search when filterValue changes (parent filter changes)
    // React.useEffect(() => {
    //     if (searchText && searchText.length >= 2) {
    //         searchRecords(searchText);
    //     }
    // }, [props.filterValue, searchRecords]);

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
        if(!selectedValue && options.length == 0)
            searchRecords("", true);
    };

    const handleInputChange = React.useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
        const value = event.target.value;
        setSearchText(value);
        setSelectedValue(value);

        // If user clears the input, clear the selection
        if (!value) {
            props.onSelectionChange(undefined, undefined);
        }
    }, [props.onSelectionChange]);

    const handleSelectionChange = React.useCallback((event: any, data: any) => {
        if (data.optionValue && data.optionText) {
            setSelectedValue(data.optionText);
            setSearchText(data.optionText);
            props.onSelectionChange(data.optionValue, data.optionText);
        }
    }, [props.onSelectionChange]);

    if (!props.isVisible) {
        return null;
    }

    return (
        <FluentProvider theme={props.theme} className={styles.container}>
            <Combobox
                className={styles.combobox}
                placeholder={`Search ${props.targetEntity}...`}
                value={selectedValue}
                onInput={handleInputChange}
                onOptionSelect={handleSelectionChange}
                onClick={handleClick}
                disabled={props.isDisabled}
                appearance="filled-darker"
            >
                {options.map((option) => (
                    <Option key={option.id} value={option.id} text={option.name}>
                        {option.name}
                    </Option>
                ))}
                {isLoading && (
                    <Option value="loading" disabled>
                        Loading...
                    </Option>
                )}
                {searchText.length >= 2 && options.length === 0 && !isLoading && (
                    <Option value="no-results" disabled>
                        No results found
                    </Option>
                )}
            </Combobox>
        </FluentProvider>
    );
};