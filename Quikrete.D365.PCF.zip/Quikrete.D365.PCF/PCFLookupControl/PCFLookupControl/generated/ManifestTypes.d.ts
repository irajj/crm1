/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    targetEntity: ComponentFramework.PropertyTypes.StringProperty;
    primaryId: ComponentFramework.PropertyTypes.StringProperty;
    primaryName: ComponentFramework.PropertyTypes.StringProperty;
    nameField: ComponentFramework.PropertyTypes.StringProperty;
    guidField: ComponentFramework.PropertyTypes.StringProperty;
    parentFilterEntity: ComponentFramework.PropertyTypes.StringProperty;
    filterValue: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    nameField?: string;
    guidField?: string;
    filterValue?: string;
}
