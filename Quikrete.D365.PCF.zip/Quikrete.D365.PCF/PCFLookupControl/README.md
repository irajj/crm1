# Quikrete Lookup Control (PCF)

A lightweight Fluent UI-based lookup for Dataverse model-driven apps with typeahead search and optional dependent lookup filtering.

The control searches the target table using Dataverse Web API with a startswith filter on the configured primary text column. When configured for dependency, it also filters by a parent lookup value from the current form.

## Features
- Typeahead search over a target table using startswith on the primary text column
- Select up to 10 results (configurable via code) with smooth keyboard/mouse navigation
- Write-back of both selected record name and GUID to bound fields
- Optional dependent lookup filter (child filtered by parent field on the form)

## Requirements
- Node.js 18+
- Power Apps CLI (`pac`) with PCF tooling (installed by `pcf-scripts`)
- A Dataverse environment to test/deploy

## Install and Build
```bash
npm install
npm run build
# optional during development
npm run start
```

Packaging a solution zip:
```bash
npm run package
# Output found under out/controls/QuikreteLookupControl
```

You can also use the provided solution under `Solutions/` for distribution.

## Add to a Model-Driven Form
1. Add two text columns to your table if you do not already have storage for both values:
   - GUID column to store the selected record id (text, 36 chars)
   - Name column to store the selected record name (text)
2. Add both columns to the form.
3. Insert the control on either column and configure the properties below.
4. Save and publish.

## Properties (ControlManifest)
- `targetEntity` (required, input): Logical name of the table to search. Example: `account`.
- `primaryId` (required, input): Primary key logical name of the target table. Example: `accountid`.
- `primaryName` (required, input): Primary text column logical name used for search and display. Example: `name`.
- `nameField` (required, bound): Form field bound to the selected record name (text column).
- `guidField` (required, bound): Form field bound to the selected record id (text column storing GUID).
- `parentFilterEntity` (required for dependency, input): Lookup attribute schema name on the target table that points to the parent record you want to filter by. Example: if contacts are filtered by their account, use `parentcustomerid` or the specific lookup attribute on your target table.
- `filterValue` (required for dependency, bound): Form field whose value is the parent record GUID used to filter. Bind this to a hidden text column on the form that mirrors the parent lookup value.

Notes:
- The control uses Dataverse OData filtering and will issue a query like:
  - `?$select={primaryId},{primaryName}&$filter=startswith({primaryName},'term')`
  - With dependency: `... and _{parentFilterLookupAttribute}_value eq {filterValue}`
- The search triggers after 2 characters by default and debounces for 300ms.

## Dependent Lookup Configuration
Use this to filter child records by a parent selected on the form (e.g., Contacts by Account).

1. Ensure your target table has a lookup column to the parent (for example, contacts have `parentcustomerid`).
2. Create a text column on the form to hold the parent GUID value (or reuse one if you already mirror it). Ensure it’s populated from your parent lookup field using a business rule, workflow, or form script.
3. Set control properties:
   - `targetEntity`: `contact`
   - `primaryId`: `contactid`
   - `primaryName`: `fullname`
   - `parentFilterEntity`: the child’s lookup attribute schema name referencing the parent, e.g., `parentcustomerid` (not the table logical name)
   - `filterValue`: bind to the text field that contains the parent GUID (e.g., the Account id)

Example effective filter built by the control:
`startswith(fullname,'jo') and _parentcustomerid_value eq 00000000-0000-0000-0000-000000000000`

## How It Works (Implementation Overview)
- UI is built with Fluent UI `Combobox` for consistent, accessible UX
- Queries Dataverse via `context.webAPI.retrieveMultipleRecords(targetEntity, query)`
- Search uses `startswith(primaryName,'term')` and returns `{primaryId, primaryName}` for the first 10 matches
- When dependency is configured, the filter adds `_{lookupAttribute}_value eq {filterValue}`
- Selected option writes back to both bound fields (`guidField` and `nameField`)

## Development
- `npm run start`: local harness if configured by `pcf-scripts`
- `npm run watch`: rebuild on change
- `npm run debug`: debug with PCF tooling
- `npm run clean`: clean artifacts

## Folder Structure
- `QuikreteLookupControl/index.ts`: PCF control wrapper and lifecycle
- `QuikreteLookupControl/DynamicLookup.tsx`: React component and Web API calls
- `QuikreteLookupControl/ControlManifest.Input.xml`: PCF manifest and properties
- `out/controls/QuikreteLookupControl`: build output

## License
MIT

