/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    buttonField: ComponentFramework.PropertyTypes.StringProperty;
    buttonType: ComponentFramework.PropertyTypes.WholeNumberProperty;
    buttonLabel: ComponentFramework.PropertyTypes.StringProperty;
    buttonIcon: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    buttonField?: string;
}
