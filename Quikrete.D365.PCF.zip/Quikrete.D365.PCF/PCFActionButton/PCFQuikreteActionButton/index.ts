import * as React from "react";
import * as ReactDOM from "react-dom";
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { ButtonControl, IButtonControlProps } from "./ButtonControl";

export class PCFActionButton implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private container: HTMLDivElement;
    private notifyOutputChanged: () => void;
    private buttonText: string;
    private buttonValue: string;
    private buttonType: number;

    constructor() { }

    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this.container = container;
        this.notifyOutputChanged = notifyOutputChanged;
        this.buttonText = context.parameters.buttonLabel.raw ?? "";
        this.buttonType = context.parameters.buttonType.raw ?? 0;
    }

    private GenerateControl(context: ComponentFramework.Context<IInputs>): void {

        const buttonProps: IButtonControlProps = {
            disabled: context.mode.isControlDisabled,
            btnChoice: this.buttonType,
            btnText:
                context.parameters.buttonLabel.raw ??
                (this.buttonType != 3 && this.buttonText == ""
                    ? context.parameters.buttonField.attributes?.DisplayName ?? "Quikrete"
                    : this.buttonText),
            btnIcon:
                context.parameters.buttonIcon.raw ??
                (this.buttonType == 3 ? "Add" : ""),
            checked: false,
            onClick: () => {
                this.notifyOutputChanged();
            },
        };

        // const buttonProps: IButtonControlProps = {
        //     disabled: context.mode.isControlDisabled,
        //     btnChoice: this.buttonType,
        //     btnText:
        //         context.parameters.buttonLabel.raw ??
        //         (this.buttonType !== 3 && this.buttonText === ""
        //             ? context.parameters.buttonField.attributes?.DisplayName ?? "Quikrete"
        //             : this.buttonText),
        //     btnIcon:
        //         context.parameters.buttonIcon.raw ??
        //         (this.buttonType === 3 ? "Add" : ""),
        //     checked: this.buttonValue, // ✅ Pass boolean
        //     onClick: () => {
        //         // Toggle Yes/No value when button clicked
        //         this.buttonValue = !this.buttonValue;
        //         this.notifyOutputChanged();
        //     },
        // };

        ReactDOM.render(
            React.createElement(ButtonControl, buttonProps),
            this.container
        );
    }


    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this.GenerateControl(context);
        this.buttonValue = this.buttonText != "" ? this.buttonText : "Clicked";
    }

    public getOutputs(): IOutputs {
        // TODO use the checked feature, dynamically set value from code
        return {
            buttonField: this.buttonValue,
        };
    }

    public destroy(): void {
        // Add code to cleanup control if necessary
        ReactDOM.unmountComponentAtNode(this.container);
    }
}
