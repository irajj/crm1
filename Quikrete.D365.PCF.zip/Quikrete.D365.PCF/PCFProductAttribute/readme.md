﻿# PCF Control

This Power Apps Component Framework (PCF) control is designed to help you creating pcf controls.
---

## 📁 Project Initialization

```bash
pac pcf init --namespace <Controlname> --name <projectname> --template <field or template>
```

---

## ⚙️ Install Dependencies

Run the following command to install all required packages:

```bash
npm install
```

If using additional libraries (example):

```bash
npm install @fluentui/react lodash
```

---

## 🛠 Development Commands

### Build the control:

```bash
npm run build
```

### Start the control in the preview window:

```bash
npm run start
```

### Watch mode (auto-reloads on code changes):

```bash
npm run start:watch
```

---

## 🔐 Authentication

Login to your Power Platform environment:

```bash
pac auth create --url <Environment Url>
```

---

## 🚀 Deploy the Control

Push the control to your environment:

```bash
pac pcf push --publisher-prefix <prefix>
```

---

## 🧰 Tools Required

- [Node.js](https://nodejs.org/) (v14 or later recommended)
- [Power Platform CLI (`pac`)](https://learn.microsoft.com/en-us/power-platform/developer/cli/introduction)

Install `pac` globally if not already installed:

```bash
npm install -g pac
```

---

## 📁 Folder Structure (Typical)

```
PCFProductAttributeFluent/
├── ControlManifest.Input.xml
├── index.ts
├── PCFProductAttributeFluent.ts
├── node_modules/
├── package.json
└── README.md
```

---

## 📚 References

- [PCF Documentation – Microsoft Docs](https://learn.microsoft.com/en-us/power-apps/developer/component-framework/overview)
- [Fluent UI React](https://react.fluentui.dev/)
- [Power Platform CLI Docs](https://learn.microsoft.com/en-us/power-platform/developer/cli/introduction)