/* eslint-disable no-debugger */


/* eslint-disable @typescript-eslint/no-explicit-any */
/* ProductAttributeSelector.css */

import * as React from "react";
import { IInputs, IOutputs } from "../generated/ManifestTypes";
import { useEffect, useState, useRef } from "react";
import {
    FluentProvider, Input, Checkbox, Textarea, webLightTheme, Label, Dropdown, Option, Button,
    Dialog,
    DialogSurface,
    DialogBody,
    DialogTitle,
    DialogContent,
    DialogActions
} from '@fluentui/react-components';
import { renderAttributeControl } from "./utils/renderAttributeControl";
import "./css/ProductSelector.css"; // Assuming you have a CSS file for styles
import {
    PAM_PRODUCT_TYPE,
    DynamicAttributeBaseAttribute,
    DynamicAttributeoptions,
    DynamicAttribute,
    PamProductList,
    CRMProductEntity,
    ValidationResult
} from "./types/commonType";

import {
    extractValueFromPartNo,
    getTypeSubTypeFromFamily,
    getTypeFromSubType,
    getProductTypeFromSubType,
    extractBaseAttributeValueFromPartNo,
    MarkFormDirty,
    validateAttributes,
    updatePassAttributetoJDE
} from "./utils/CRMHelper";

import * as APIHelper from "./utils/CRMApi";


import {
    getSubTypes,
    getFamiliesFromType,
    getFamilies,
    getProductsForCombination,
    getAllAttribute,
    getPamProductConfigDetails,
    generatePartInfoFromControls,
    getProductFromPartNumber,
    searchProductByPartNumber,
    getPamProductbyMainOptions
} from "./utils/CRMApi";

import ProductSearchModal from "./utils/ProductSearchModal";
import { buildKeytipConfigMap } from "@fluentui/react";

interface Props {
    existingValues: {
        type?: string;
        subType?: string;
        family?: string;
        partNumber?: string;
        crmEntityData: Record<string, string>;
        pamEntityData: Record<string, string>;
    };
    businessUnitId: string;
    typesOptions: { key: string; text: string }[];
    subTypesOptions: { key: string; text: string }[];
    familyOptions: { key: string; text: string }[];
    formContext: any;
    onChange?: (val: { productId: string | null; attributeValues: Record<string, string> }) => void;
    context: ComponentFramework.Context<IInputs>;
}

export const ProductAttributeSelector: React.FC<Props> = (
    { existingValues,
        businessUnitId,
        typesOptions,
        subTypesOptions,
        familyOptions,
        formContext,
        context,
        onChange
    }) => {

    const [types, setTypes] = useState<{ key: string; text: string }[]>([]);
    const [subTypes, setSubTypes] = useState<{ key: string; text: string }[]>([]);
    const [families, setFamilies] = useState<{ key: string; text: string }[]>([]);

    const [products, setProducts] = useState<PamProductList[]>([]);

    const [selectedType, setSelectedType] = useState<string>("");
    const [selectedSubType, setSelectedSubType] = useState<string>("");
    const [selectedFamily, setSelectedFamily] = useState<string>("");
    const [selectedPartNumber, setSelectedPartNumber] = useState<string>("");

    const [baseAttributes, setBaseAttributes] = useState<DynamicAttributeBaseAttribute[]>([]);
    const [baseAttributesValues, setBaseAttrValues] = useState<Record<string, string>>({});
    const [visibleBaseAttributes, setVisibleBaseAttributes] = useState<DynamicAttributeBaseAttribute[]>([]);

    const [pendingAttributes, setPendingAttributes] = useState<DynamicAttribute[]>([]);
    const [attributeValues, setAttributeValues] = useState<Record<string, string>>({});

    const baseAttributesRef = useRef<DynamicAttributeBaseAttribute[]>([]);
    const visibleBaseAttrsRef = useRef<DynamicAttributeBaseAttribute[]>([]);
    const pendingAttributesRef = useRef<DynamicAttribute[]>([]);
    const selectedPartNumberRef = useRef("");

    const [finalProduct, setFinalProduct] = useState<any>();
    const hasInitializedRef = useRef(false); // to prevent re-triggering on first render
    const hasSuggestiondNumberRef = useRef(false); // to prevent re-triggering on first render

    const pamProductIdRef = useRef<string | null>(existingValues?.pamEntityData?.productId ?? null);

    const [crmProductEntity, setCrmProductEntity] = useState<CRMProductEntity>();
    const crmProductEntityRef = useRef<CRMProductEntity>();
    const finalProductRef = useRef<any>();

    const baseAttributesValuesRef = useRef<Record<string, string>>({});
    const attributeValuesRef = useRef<Record<string, string>>({});

    // #region Product NUmber Dropdown Configuration
    const [hoveredSuggestion, setHoveredSuggestion] = useState<string | null>(null);

    // Change type of suggestions to: Array<{ label: string, data: any }>
    const [suggestions, setSuggestions] = useState<{ partnumber: string, data: any }[]>([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    // #endregion

    const isReverseLogicRef = useRef(false);

    const lengthMultiplerfieldRef = useRef<any>();

    const [isSearchModalOpen, setIsSearchModalOpen] = React.useState(false);

    // Type Changed Manually
    const isTypeChangedManuallyRef = useRef(false);
    const [isTypeChangedManually, setisTypeChangedManually] = useState<boolean>(false);

    // Partnumber changed manually
    useEffect(() => {
        // if (Boolean(isReverseLookupLogic) == false) return;
        isTypeChangedManuallyRef.current = Boolean(isTypeChangedManually);
    }, [isTypeChangedManually])

    // When crmProductEntity changes, update ref
    useEffect(() => {
        crmProductEntityRef.current = crmProductEntity;
    }, [crmProductEntity]);

    // When finalProduct changes, update ref
    useEffect(() => {

        const product =
            Array.isArray(finalProduct) ? finalProduct[0] : finalProduct;

        const pamProductId = product?.productId ?? product?.crmgp_productid ?? null;

        pamProductIdRef.current = pamProductId;
        finalProductRef.current = finalProduct;
    }, [finalProduct]);

    useEffect(() => {
        baseAttributesRef.current = baseAttributes;
    }, [baseAttributes]);

    useEffect(() => {
        pendingAttributesRef.current = pendingAttributes;
    }, [pendingAttributes]);

    useEffect(() => {
        baseAttributesValuesRef.current = baseAttributesValues;
    }, [baseAttributesValues]);

    useEffect(() => {
        attributeValuesRef.current = attributeValues;
    }, [attributeValues]);

    // Load Types once
    useEffect(() => {

        setTypes(typesOptions);
        setSubTypes(subTypesOptions);
        setFamilies(familyOptions);

        if (existingValues?.type) {
            setSelectedType(existingValues.type);
        }
        if (existingValues?.partNumber) {
            setSelectedPartNumber(existingValues.partNumber);
        }

        // if (!hasInitializedRef.current && existingValues?.type) {
        //     setSelectedType(existingValues.type);
        // }
        // if (!hasInitializedRef.current && existingValues?.partNumber) {
        //     setSelectedPartNumber(existingValues.partNumber);
        // }

        //Register this function on parent so we can call it from main javascript file.
        (window as any).pcfAPI = {
            validatepcf: () => {
                return validateBaseAttributesFromRefs();
            },
            save: async (parentEntity: string, parentId: string) => {
                await saveProductAttributesWithParent(parentEntity, parentId);
            }
        };
    }, []);

    // On Type → Load SubTypes
    useEffect(() => {

        if (!selectedType) return;

        if (existingValues?.subType)
            setSelectedSubType(existingValues.subType);

    }, [selectedType]);

    // On SubType → Load Families
    useEffect(() => {

        if (!selectedSubType) return;
        if (existingValues?.family)
            setSelectedFamily(existingValues?.family);

    }, [selectedSubType]);

    // On Family Selection → Just Clear Base Attribute and Attribute 
    useEffect(() => {
        if (selectedFamily != "") {
            // Clear previous state
            setBaseAttributes([]);
            setVisibleBaseAttributes([]);
            setFinalProduct(null);
            setPendingAttributes([]);
            if (existingValues.type && existingValues.subType && existingValues.family) {
                loadDataOnExistingValue(existingValues.type, existingValues.subType, existingValues.family)
            }
        };

        // Check If Existing things have value


    }, [selectedFamily]);

    // On Part Number
    useEffect(() => {

        // if (!selectedPartNumber) return;

        // // Reset suggestions if part number is cleared
        // // if (existingValues?.partNumber) {
        // //     setSelectedPartNumber(existingValues.partNumber);
        // // }
        selectedPartNumberRef.current = selectedPartNumber;
    }, [selectedPartNumber]);

    useEffect(() => {

        const valuesToUse = { ...baseAttributesValues };

        if (Object.keys(existingValues.crmEntityData || {}).length > 0) {
            // setPendingAttributes([]);
            // Only set values that match your base attributes
            visibleBaseAttributes.forEach(attr => {
                const field = attr.cmrfieldname;
                const val = existingValues.crmEntityData[field];


                // Only update if value is not already set
                if (val && valuesToUse[field] == null) {
                    valuesToUse[field] = val;
                }

            });
            setBaseAttrValues(valuesToUse);

            // Get index of last populated attribute
            const lastFilledIndex = baseAttributes.findIndex(
                attr => !valuesToUse[attr.cmrfieldname]
            );

            const nextIndex = lastFilledIndex === -1
                ? baseAttributes.length
                : lastFilledIndex;


            // resolveBaseAttributeStep(baseAttributes, nextIndex, products, valuesToUse, visibleBaseAttributes);
        }
        visibleBaseAttrsRef.current = visibleBaseAttributes;
    }, [visibleBaseAttributes]);

    // #region : Existing Value
    const loadDataOnExistingValue = async (type?: string, subtype?: string, family?: string, partNumber = "", onPartNumberChange = false) => {
        if (!type || !subtype || !family) return;
        const baseAttributesList = await getProductsForCombination(formContext, type, subtype, family);
        const productList = baseAttributesList.pamProductListData || [];
        setProducts(productList);
        const baseAttrs: DynamicAttributeBaseAttribute[] = baseAttributesList.getBaseAttributeContols;

        // Get Base Attribute Values
        const pamProductRef = context.parameters.PAMProductReference?.raw;
        let pamProductId = '';
        if (pamProductRef.length > 0) {
            pamProductId = pamProductRef[0]?.id;
            // eslint-disable-next-line @typescript-eslint/prefer-for-of
            for (let i = 0; i < baseAttrs.length; i++) {
                const baseattribute = baseAttrs[i];
                const baseAttrValue = await formContext.retrieveMultipleRecords("crmgp_baseproductattribute", `?$select=crmgp_attributevalue,crmgp_crmfieldname,_crmgp_productid_value&$filter=(_crmgp_productid_value eq ${pamProductId} and crmgp_crmfieldname eq '${baseattribute.cmrfieldname}' and crmgp_isactive eq true)`);
                baseattribute.selectedBaseValue = baseAttrValue[0]?.crmgp_attributevalue;
            }
        }

        setBaseAttributes(baseAttrs);
        setVisibleBaseAttributes([]);
        setBaseAttrValues({});
        if (baseAttrs.length > 0) {
            await resolveBaseAttributeOnExistingValue(baseAttrs, 0, productList, {}, baseAttrs, partNumber, onPartNumberChange);
        }
        else {
            await renderAttributeFromFamily(type, subtype, family, partNumber, onPartNumberChange);
        }
    };

    const resolveBaseAttributeOnExistingValue = async (
        baseAttributes: DynamicAttributeBaseAttribute[],
        nextIndex: number,
        productList: any[],
        selectedBaseAttrValues: Record<string, string>,
        currentVisibleAttrs: DynamicAttributeBaseAttribute[],
        partnumber?: string, onPartNumberChange?: boolean
    ) => {
        if (baseAttributes.length > 0) {
            let filteredProducts = [...productList];

            filteredProducts = filteredProducts.filter(product => {
                return baseAttributes.every(attr => {
                    const field = attr.cmrfieldname;
                    const selectedValue = attr.selectedBaseValue;
                    return product[field] === selectedValue;
                });
            });

            // Check for final match
            if (filteredProducts.length === 1) {
                if (baseAttributes.length && filteredProducts.length > 0) {
                    const matchedProduct = filteredProducts[0];
                    setFinalProduct(matchedProduct); // optional handler
                    const dynAttrs = await getAllAttribute(formContext, matchedProduct.productId);
                    // eslint-disable-next-line @typescript-eslint/prefer-for-of
                    for (let i = 0; i < dynAttrs.length; i++) {
                        const attr = dynAttrs[i];
                        const field = attr.crmfieldname;

                        // Priority 3: CRM values
                        if (existingValues.crmEntityData && field in existingValues.crmEntityData) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: existingValues.crmEntityData[field] };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = existingValues.crmEntityData[field];
                            continue; // skip the rest of this iteration
                        }

                        // Priority 4: Default value (and update state)
                        if (attr.defaultvalue !== undefined) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: attr.defaultvalue };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = attr.defaultvalue;
                            continue; // skip the rest of this iteration
                        }
                        // Fallback
                    }
                    setVisibleBaseAttributes(currentVisibleAttrs.filter(x => x.selectedBaseValue));
                    setPendingAttributes(dynAttrs);
                    return;
                }
            }
        }
        else {
            formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
            setFinalProduct(undefined);
            setPendingAttributes([]);
        }
    }
    // #endregion

    // #region : Product Number Change
    const loadDataOnProductNumberChange = async (type?: string, subtype?: string, family?: string, partNumber = "", onPartNumberChange = false) => {
        if (!type || !subtype || !family) return;

        const baseAttributesList = await getProductsForCombination(formContext, type, subtype, family);
        const productList = baseAttributesList.pamProductListData || [];
        setProducts(productList);
        const baseAttrs: DynamicAttributeBaseAttribute[] = baseAttributesList.getBaseAttributeContols;
        setBaseAttributes(baseAttrs);
        setVisibleBaseAttributes([]);
        setFinalProduct(null);
        setPendingAttributes([]);
        setAttributeValues({});

        if (baseAttrs.length > 0) {
            await resolveBaseAttributeOnProductNumberChange(baseAttrs, 0, productList, {}, [], partNumber, onPartNumberChange);
        }
        else {
            await renderAttributeFromFamily(type, subtype, family, partNumber, onPartNumberChange);
        }
    };

    const resolveBaseAttributeOnProductNumberChange = async (
        baseAttributes: DynamicAttributeBaseAttribute[],
        nextIndex: number,
        productList: any[],
        selectedBaseAttrValues: Record<string, string>,
        currentVisibleAttrs: DynamicAttributeBaseAttribute[],
        partnumber?: string, onPartNumberChange?: boolean
    ) => {
        if (baseAttributes.length > 0) {
            let filteredProducts = [...productList];
            const validAttrs = baseAttributes.slice(0, nextIndex).map(b => b.cmrfieldname);

            for (const attrName of validAttrs) {
                // 1️⃣ Get the selected value for that attribute
                const attrObj = baseAttributes.find(b => b.cmrfieldname === attrName);
                const val = attrObj?.selectedBaseValue; // you already have this property

                // 2️⃣ Apply filter only if value exists
                if (val) {
                    filteredProducts = filteredProducts.filter(p => p[attrName] === val);
                }
            }

            // Check for final match
            if (filteredProducts.length === 1) {
                if (baseAttributes.length && filteredProducts.length > 0) {
                    const matchedProduct = filteredProducts[0];
                    setFinalProduct(matchedProduct); // optional handler
                    const dynAttrs = await getAllAttribute(formContext, matchedProduct.productId);
                    setAttributeValues({});
                    // Attach Value With dynAttrs depend on the flag 
                    // eslint-disable-next-line @typescript-eslint/prefer-for-of
                    for (let i = 0; i < dynAttrs.length; i++) {
                        const attr = dynAttrs[i];
                        const field = attr.crmfieldname;

                        // Value change from part number 
                        if (onPartNumberChange) {
                            // Priority 3: Product data when part number changed

                            const extractedvalue = extractValueFromPartNo(partnumber || "", attr, false);
                            if (extractedvalue) {
                                setAttributeValues(prev => {
                                    const updated = { ...prev, [field]: extractedvalue };
                                    attributeValuesRef.current = updated;
                                    return updated;
                                });
                                dynAttrs[i].selectedValue = extractedvalue;
                                continue; // skip the rest of this iteration
                            }

                        }

                        // Priority 3: CRM values
                        else if (existingValues.crmEntityData && field in existingValues.crmEntityData) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: existingValues.crmEntityData[field] };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = existingValues.crmEntityData[field];
                            continue; // skip the rest of this iteration
                        }

                        // Priority 4: Default value (and update state)
                        if (attr.defaultvalue !== undefined) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: attr.defaultvalue };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = attr.defaultvalue;
                            continue; // skip the rest of this iteration
                        }
                        // Fallback
                    }
                    currentVisibleAttrs = baseAttributes.filter(attr => {
                        return filteredProducts.some(product =>
                            Object.keys(product).includes(attr.cmrfieldname)
                        );
                    });
                    setBaseAttributes(currentVisibleAttrs);
                    setPendingAttributes(dynAttrs);
                    return;
                }
                else if (nextIndex >= baseAttributes.length && filteredProducts.length > 0) {
                    const matchedProduct = filteredProducts[0];
                    setFinalProduct(matchedProduct); // optional handler
                    const dynAttrs = await getAllAttribute(formContext, matchedProduct.productId);

                    // Attach Value With dynAttrs depend on the flag 
                    // eslint-disable-next-line @typescript-eslint/prefer-for-of
                    for (let i = 0; i < dynAttrs.length; i++) {
                        const attr = dynAttrs[i];
                        const field = attr.crmfieldname;

                        // Value change from part number 
                        if (onPartNumberChange) {
                            // Priority 3: Product data when part number changed

                            const extractedvalue = extractValueFromPartNo(partnumber || "", attr, false);
                            if (extractedvalue) {
                                setAttributeValues(prev => {
                                    const updated = { ...prev, [field]: extractedvalue };
                                    attributeValuesRef.current = updated;
                                    return updated;
                                });
                                dynAttrs[i].selectedValue = extractedvalue;
                                continue; // skip the rest of this iteration
                            }

                        }

                        // Priority 3: CRM values
                        else if (existingValues.crmEntityData && field in existingValues.crmEntityData) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: existingValues.crmEntityData[field] };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = existingValues.crmEntityData[field];
                            continue; // skip the rest of this iteration
                        }

                        // Priority 4: Default value (and update state)
                        if (attr.defaultvalue !== undefined) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: attr.defaultvalue };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = attr.defaultvalue;
                            continue; // skip the rest of this iteration
                        }
                        // Fallback
                    }
                    currentVisibleAttrs = baseAttributes.filter(attr => {
                        return filteredProducts.some(product =>
                            Object.keys(product).includes(attr.cmrfieldname)
                        );
                    });
                    setBaseAttributes(currentVisibleAttrs);
                    setPendingAttributes(dynAttrs);
                    hasInitializedRef.current = true;
                    return;
                }
                else {
                    formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
                    // If still ambiguous or no match
                    setFinalProduct(undefined);
                    setPendingAttributes([]);
                    return;
                }
            }

            // Otherwise, show next base attribute
            if (nextIndex < baseAttributes.length) {
                const nextAttr = baseAttributes[nextIndex];
                const attrName = nextAttr.cmrfieldname;
                if (!currentVisibleAttrs.some(attr => attr.cmrfieldname === attrName)) {
                    const field = nextAttr.cmrfieldname;
                    // Define a helper to update attributeValues only once
                    if (onPartNumberChange) {
                        // Priority 3: Product data when part number changed
                        const extractedvalue = extractBaseAttributeValueFromPartNo(partnumber || "", nextAttr, false);
                        if (extractedvalue) {

                            setBaseAttrValues(prev => {
                                const updated = { ...prev, [field]: extractedvalue };
                                baseAttributesValuesRef.current = updated;
                                return updated;
                            });

                            nextAttr.selectedBaseValue = extractedvalue;
                            setVisibleBaseAttributes((prev: any) => [...prev, nextAttr]);

                            // Force     to show next base attribute till index limit reached
                            const currentIndex = baseAttributes.findIndex((b) => b.cmrfieldname === nextAttr.cmrfieldname);
                            const newVisibleAttrs = baseAttributes.slice(0, currentIndex + 1);
                            // setVisibleBaseAttributes(newVisibleAttrs);
                            const index = baseAttributes.findIndex(attr => attr.cmrfieldname === attrName);
                            if (index >= 0) {
                                await resolveBaseAttributeOnProductNumberChange(baseAttributes, index + 1, productList, {}, newVisibleAttrs, partnumber, true);
                            }
                        }
                        else {
                            setVisibleBaseAttributes((prev: any) => [...prev, nextAttr]);
                        }
                    }
                    else {
                        setVisibleBaseAttributes((prev: any) => [...prev, nextAttr]);
                    }
                }
                else {
                    // NO more option - Please Contact Admin or you can check this record
                    formContext.openAlertDialog("Warning", "No more base attribute found. Please select a valid combination.");
                    setFinalProduct(undefined);
                    setPendingAttributes([]);
                }
            }
            else if (nextIndex === baseAttributes.length) {
                // Means reached limit of last base attribute

                // Step 1: Build a key-value map of selected base attributes
                const selectedValues: any = {};
                baseAttributes.forEach(attr => {
                    selectedValues[attr.cmrfieldname] = attr.selectedBaseValue;
                });

                // Step 2: Find the product that matches all selected values
                const matchedProduct = filteredProducts.filter(product =>
                    Object.entries(selectedValues).every(([field, value]) => product[field] === value)
                );
                filteredProducts = matchedProduct;
                if (filteredProducts.length === 0) {
                    formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
                    // If still ambiguous or no match
                    setFinalProduct(undefined);
                    setPendingAttributes([]);
                    setAttributeValues({});

                }
                setFinalProduct(matchedProduct); // optional handler
                const dynAttrs = await getAllAttribute(formContext, matchedProduct[0]?.productId);

                // Attach Value With dynAttrs depend on the flag 
                // eslint-disable-next-line @typescript-eslint/prefer-for-of
                for (let i = 0; i < dynAttrs.length; i++) {
                    const attr = dynAttrs[i];
                    const field = attr.crmfieldname;

                    // Value change from part number 
                    if (onPartNumberChange) {
                        // Priority 3: Product data when part number changed

                        const extractedvalue = extractValueFromPartNo(partnumber || "", attr, false);
                        if (extractedvalue) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: extractedvalue };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = extractedvalue;
                            continue; // skip the rest of this iteration
                        }

                    }

                    // Priority 3: CRM values
                    else if (existingValues.crmEntityData && field in existingValues.crmEntityData) {
                        setAttributeValues(prev => {
                            const updated = { ...prev, [field]: existingValues.crmEntityData[field] };
                            attributeValuesRef.current = updated;
                            return updated;
                        });
                        dynAttrs[i].selectedValue = existingValues.crmEntityData[field];
                        continue; // skip the rest of this iteration
                    }

                    // Priority 4: Default value (and update state)
                    if (attr.defaultvalue !== undefined) {
                        setAttributeValues(prev => {
                            const updated = { ...prev, [field]: attr.defaultvalue };
                            attributeValuesRef.current = updated;
                            return updated;
                        });
                        dynAttrs[i].selectedValue = attr.defaultvalue;
                        continue; // skip the rest of this iteration
                    }
                    // Fallback
                }

                if (Object.keys(existingValues.crmEntityData).length > 0) {
                    currentVisibleAttrs = baseAttributes.filter(attr => {
                        return filteredProducts.some(product =>
                            Object.keys(product).includes(attr.cmrfieldname)
                        );
                    });
                    setVisibleBaseAttributes(currentVisibleAttrs);
                }
                setBaseAttributes(currentVisibleAttrs);
                setPendingAttributes(dynAttrs);
            }
            else if (baseAttributes.length > 0 && nextIndex >= baseAttributes.length) {
                formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
                // If still ambiguous or no match
                setFinalProduct(undefined);
                setPendingAttributes([]);
                setAttributeValues({});
            }
        }
        else {
            // Try to clear Pending Attribute
            // If still ambiguous or no match
            setFinalProduct(undefined);
            setPendingAttributes([]);
            setAttributeValues({});
        }
    }
    // #endregion

    // #region : Attribute Render Logic and On change Event Handler
    async function renderAttributeFromFamily(type?: string, subtype?: string, family?: string, partnumber?: string, onPartNumberChange?: boolean) {
        if (!type || !subtype || !family) return;
        // If no products match, try to find a product by main options
        const matchedProducts = await getPamProductbyMainOptions(
            formContext,
            type ?? "",
            subtype ?? "",
            family ?? ""
        );
        if (matchedProducts.length == 0) {


            formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
            setFinalProduct([]);
            setPendingAttributes([]);
            setAttributeValues({});
            return

        }
        const matchedProduct = matchedProducts[0]; // or handle empty array case
        const dynAttrs = await getAllAttribute(formContext, matchedProduct?.crmgp_productid);
        setFinalProduct(matchedProduct); // optional handler


        // Attach Value With dynAttrs depend on the flag 
        // eslint-disable-next-line @typescript-eslint/prefer-for-of
        for (let i = 0; i < dynAttrs.length; i++) {
            const attr = dynAttrs[i];
            const field = attr.crmfieldname;

            // Define a helper to update attributeValues only once
            const updateIfNeeded = (value: any) => {
                if (!(field in attributeValuesRef.current)) {
                    setAttributeValues(prev => {
                        const updated = { ...prev, [field]: value };
                        attributeValuesRef.current = updated;
                        return updated;
                    });
                }
                return value;
            };

            // Value change from part number 
            if (onPartNumberChange) {
                // Priority 3: Product data when part number changed
                const extractedvalue = extractValueFromPartNo(partnumber || "", attr, false);
                if (extractedvalue) {
                    // const updatedValues = {

                    //     [field]: extractedvalue
                    // };

                    // setAttributeValues(updatedValues);

                    setAttributeValues(prev => {
                        const updated = { ...prev, [field]: extractedvalue };
                        attributeValuesRef.current = updated;
                        return updated;
                    });

                    dynAttrs[i].selectedValue = extractedvalue;
                    continue; // skip the rest of this iteration
                }

            }
            // Priority 2: Use user-selected value if available but check it not intial load and not from part number
            // else if (field in attributeValues) {
            //     if (attr.options.length > 0) {
            //         const checkValue = attr.options.findIndex(x => x.ruledescription == attributeValues[field]);
            //         if (checkValue != -1) {
            //             dynAttrs[i].selectedValue = attributeValues[field];
            //             continue; // skip the rest of this iteration
            //         }
            //     }
            //     dynAttrs[i].selectedValue = attributeValues[field];
            //     continue;
            // }

            // Priority 3: CRM values
            else if (existingValues.crmEntityData && field in existingValues.crmEntityData) {
                // const updatedValues = {
                //     [field]: attr.defaultvalue
                // };

                // setAttributeValues(updatedValues);
                setAttributeValues(prev => {
                    const updated = { ...prev, [field]: existingValues.crmEntityData[field] };
                    attributeValuesRef.current = updated;
                    return updated;
                });
                dynAttrs[i].selectedValue = existingValues.crmEntityData[field];
                continue; // skip the rest of this iteration
            }

            // Priority 4: Default value (and update state)
            if (attr.defaultvalue) {
                // const updatedValues = {

                //     [field]: attr.defaultvalue
                // };

                // setAttributeValues(updatedValues);
                setAttributeValues(prev => {
                    const updated = { ...prev, [field]: attr.defaultvalue };
                    attributeValuesRef.current = updated;
                    return updated;
                });
                dynAttrs[i].selectedValue = attr.defaultvalue;
                continue; // skip the rest of this iteration
            }

            // Fallback
        }

        setPendingAttributes(dynAttrs);

    }


    const handleAttributeValueChange = (crmFieldName: string, value: any) => {
        // const updatedValues = {
        //     [crmFieldName]: value
        // };

        // setAttributeValues(updatedValues);
        setAttributeValues(prev => {
            const updated = { ...prev, [crmFieldName]: value };
            attributeValuesRef.current = updated;
            return updated;
        });

        pendingAttributes.forEach(attr => {
            if (attr.crmfieldname === crmFieldName) {
                attr.selectedValue = value;
            }

            //this field is disable it's only updated from other attribute change
            if (attr.crmfieldname === "new_pa_pass_attribute_to_jde") {
                const jdeValue = updatePassAttributetoJDE(formContext, baseAttributesRef.current, baseAttributesValuesRef.current,
                    pendingAttributesRef.current, attributeValuesRef.current, "new_pa_pass_attribute_to_jde");

                attr.selectedValue = jdeValue;

                // 1️⃣ Update state (UI updates)
                setAttributeValues(prev => {
                    const updated = { ...prev, ["new_pa_pass_attribute_to_jde"]: jdeValue };
                    attributeValuesRef.current = updated;
                    return updated;
                });
            }
        });

        //on change of base attribute, mark form dirty
        MarkFormDirty(formContext, attributeValuesRef.current, crmFieldName, value);
    };

    // #endregion

    // #region : Base Attribute Render and On change Event Handler
    const handleBaseAttrChange = async (attrName: string, value: string) => {

        // --- Clear existing entity context ---
        Object.assign(existingValues, {
            subType: "",
            type: "",
            family: "",
            crmEntityData: {},
            pamEntityData: {},
            partNumber: ""
        });

        // Store selected value inside selectedBaseValue
        setFinalProduct(undefined);
        setPendingAttributes([]);
        setAttributeValues({});
        if (value == "") {
            const index = baseAttributes.findIndex(b => b.cmrfieldname === attrName);
            const visibleBase = [...baseAttributes.slice(0, index + 1)];
            setVisibleBaseAttributes(visibleBase);
            setFinalProduct(undefined);
            setPendingAttributes([]);
            setAttributeValues({});
            return;
        }
        // Step 0: Skip if value didn't change
        if (baseAttributesValues[attrName] === value) {
            if (value === "") {
                if (baseAttributes.length === 1) {
                    setFinalProduct(undefined);
                    setPendingAttributes([]);
                    setAttributeValues({});
                    return;
                }
            }
            setFinalProduct(undefined);
            setPendingAttributes([]);
            setAttributeValues({});
            return; // nothing changed, exit early
        }

        // const updateIfNeeded = (value: any) => {
        //     if (!(attrName in baseAttributesValuesRef.current)) {
        //         setBaseAttrValues(prev => {
        //             const updated = { ...prev, [attrName]: value };
        //             baseAttributesValuesRef.current = updated;
        //             return updated;
        //         });
        //     }
        //     return value;
        // };

        // Step 1: Update visible base attributes up to and including the changed one

        const currentIndex = baseAttributes.findIndex((b) => b.cmrfieldname === attrName);
        const newVisibleAttrs = baseAttributes.slice(0, currentIndex + 1);

        newVisibleAttrs.forEach(attr => {
            if (attr.cmrfieldname === attrName) {
                attr.selectedBaseValue = value;
            }
        });

        setVisibleBaseAttributes(newVisibleAttrs);

        // Step 2: Prepare updatedValues
        const updatedValues = { ...baseAttributesValues, [attrName]: value };
        // Step 3: Filter only values that are in the currently visible base attributes
        const trimmedValues: Record<string, string> = {};
        newVisibleAttrs.forEach(attr => {
            const field = attr.cmrfieldname;
            if (field in updatedValues) {
                trimmedValues[field] = updatedValues[field];
            }
        });

        // Step 4: Apply trimmed base attribute values
        setBaseAttrValues(trimmedValues);
        setFinalProduct(null);

        // Step 5: Re-resolve for next base attribute or product match
        // Update state with new value and trigger attribute resolution
        const index = baseAttributes.findIndex(attr => attr.cmrfieldname === attrName);
        if (index >= 0) {
            // await resolveBaseAttributeStep(baseAttributes, index + 1, products, updatedValues, newVisibleAttrs);
            await resolveBaseAttributeManually(baseAttributes, index + 1, products, updatedValues, newVisibleAttrs);
        }
        //on change of base attribute, mark form dirty
        MarkFormDirty(formContext, attributeValuesRef.current, attrName, value);
    };

    // Progressive resolver for base attributes
    const resolveBaseAttributeManually = async (
        baseAttributes: DynamicAttributeBaseAttribute[],
        nextIndex: number,
        productList: any[],
        selectedBaseAttrValues: Record<string, string>,
        currentVisibleAttrs: DynamicAttributeBaseAttribute[],
    ) => {
        if (baseAttributes.length > 0) {
            let filteredProducts = [...productList];
            setAttributeValues({});
            // Filter products based on selected base attribute values
            // for (const attrName of Object.keys(selectedBaseAttrValues)) {
            //     filteredProducts = filteredProducts.filter(p => p[attrName] === selectedBaseAttrValues[attrName]);
            // }
            const validAttrs = baseAttributes.slice(0, nextIndex).map(b => b.cmrfieldname);

            for (const attrName of validAttrs) {
                const val = selectedBaseAttrValues[attrName];
                if (val) {
                    filteredProducts = filteredProducts.filter(p => p[attrName] === val);
                }
            }

            // Check for final match
            if (filteredProducts.length === 1) {
                if (baseAttributes.length && filteredProducts.length > 0) {
                    const matchedProduct = filteredProducts[0];
                    setFinalProduct(matchedProduct); // optional handler
                    const dynAttrs = await getAllAttribute(formContext, matchedProduct.productId);

                    // Attach Value With dynAttrs depend on the flag 
                    // eslint-disable-next-line @typescript-eslint/prefer-for-of
                    for (let i = 0; i < dynAttrs.length; i++) {
                        const attr = dynAttrs[i];
                        const field = attr.crmfieldname;
                        // Priority 4: Default value (and update state)
                        if (attr.defaultvalue) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: attr.defaultvalue };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = attr.defaultvalue;
                            continue; // skip the rest of this iteration
                        }
                        // Fallback
                    }

                    // setVisibleBaseAttributes(currentVisibleAttrs);
                    setPendingAttributes(dynAttrs);
                    return;
                }
                else if (nextIndex >= baseAttributes.length && filteredProducts.length > 0) {
                    const matchedProduct = filteredProducts[0];
                    setFinalProduct(matchedProduct); // optional handler
                    const dynAttrs = await getAllAttribute(formContext, matchedProduct.productId);
                    // Attach Value With dynAttrs depend on the flag 
                    // eslint-disable-next-line @typescript-eslint/prefer-for-of
                    for (let i = 0; i < dynAttrs.length; i++) {
                        const attr = dynAttrs[i];
                        const field = attr.crmfieldname;
                        if (attr.defaultvalue) {
                            setAttributeValues(prev => {
                                const updated = { ...prev, [field]: attr.defaultvalue };
                                attributeValuesRef.current = updated;
                                return updated;
                            });
                            dynAttrs[i].selectedValue = attr.defaultvalue;
                            continue; // skip the rest of this iteration
                        }

                        // Fallback
                    }

                    setBaseAttributes(currentVisibleAttrs);
                    setPendingAttributes(dynAttrs);
                    return;
                }
                else {
                    formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
                    // If still ambiguous or no match
                    setFinalProduct(undefined);
                    setPendingAttributes([]);
                    setAttributeValues({});
                    return;
                }
            }

            // Otherwise, show next base attribute
            if (nextIndex < baseAttributes.length) {
                const nextAttr = baseAttributes[nextIndex];
                const attrName = nextAttr.cmrfieldname;
                if (!currentVisibleAttrs.some(attr => attr.cmrfieldname === attrName)) {
                    const field = nextAttr.cmrfieldname;
                    // Define a helper to update attributeValues only once
                    nextAttr.selectedBaseValue = "";
                    setVisibleBaseAttributes((prev: any) => [...prev, nextAttr]);

                }
                else {
                    // NO more option - Please Contact Admin or you can check this record
                    formContext.openAlertDialog("Warning", "No more base attribute found. Please select a valid combination.");
                    setFinalProduct(undefined);
                    setPendingAttributes([]);
                    setAttributeValues({});
                }
            }
            else if (nextIndex === baseAttributes.length) {
                // Means reached limit of last base attribute
                // Step 1: Build a key-value map of selected base attributes
                const selectedValues: any = {};
                baseAttributes.forEach(attr => {
                    selectedValues[attr.cmrfieldname] = attr.selectedBaseValue;
                });

                // Step 2: Find the product that matches all selected values
                const matchedProduct = filteredProducts.filter(product =>
                    Object.entries(selectedValues).every(([field, value]) => product[field] === value)
                );

                filteredProducts = matchedProduct;
                if (filteredProducts.length === 0) {
                    formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
                    // If still ambiguous or no match
                    setFinalProduct(undefined);
                    setPendingAttributes([]);
                }
                setFinalProduct(matchedProduct); // optional handler
                const dynAttrs = await getAllAttribute(formContext, matchedProduct[0]?.productId);

                // Attach Value With dynAttrs depend on the flag 
                // eslint-disable-next-line @typescript-eslint/prefer-for-of
                for (let i = 0; i < dynAttrs.length; i++) {
                    const attr = dynAttrs[i];
                    const field = attr.crmfieldname;

                    // Priority 4: Default value (and update state)
                    if (attr.defaultvalue) {
                        setAttributeValues(prev => {
                            const updated = { ...prev, [field]: attr.defaultvalue };
                            attributeValuesRef.current = updated;
                            return updated;
                        });
                        dynAttrs[i].selectedValue = attr.defaultvalue;
                        continue; // skip the rest of this iteration
                    }
                };
                setBaseAttributes(currentVisibleAttrs);
                setPendingAttributes(dynAttrs);
            }
            else if (baseAttributes.length > 0 && nextIndex >= baseAttributes.length) {
                formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
                // If still ambiguous or no match
                setFinalProduct(undefined);
                setPendingAttributes([]);
                setAttributeValues({});
            }
        }
        else {
            // Try to clear Pending Attribute
            // If still ambiguous or no match
            setFinalProduct(undefined);
            setPendingAttributes([]);
            setAttributeValues({});
        }
    }
    // #endregion

    // #region : Static Dropdown : Type, SubType, Family
    const renderDropdowns = () => {
        return (
            <div className="reactproductdropdowns">
                {/* --- 🔹 Row: Action Button --- */}
                <div style={{ display: "flex", justifyContent: "flex-end", margin: "0px 16px" }}>
                    <Button
                        style={{ borderRadius: '0px' }}
                        appearance="primary"
                        onClick={() => setIsSearchModalOpen(true)}
                    >
                        Product Search
                    </Button>
                </div>

                {/* --- 🔹 Modal Popup --- */}
                <ProductSearchModal
                    formContext={formContext}
                    businessUnitId={businessUnitId}
                    open={isSearchModalOpen}
                    onClose={() => setIsSearchModalOpen(false)}
                    // onSelectProduct={(selectedPartNo) => {
                    //     setSelectedPartNumber(selectedPartNo);
                    // }}
                    onChange={(e) => onProductNumberChange(e)}
                />

                <div className="product-grid-container">
                    {/* Product Type */}
                    <div className="product-form-group">
                        <Label>Product Type</Label>
                        <Dropdown
                            selectedOptions={selectedType ? [selectedType] : []}
                            value={
                                types.find(t => t.key === selectedType)?.text ?? ""
                            }
                            onOptionSelect={async (_, data) => {
                                const selectedValue = data.optionValue ?? "";



                                // --- Update selection states ---
                                setSelectedType(selectedValue);
                                setisTypeChangedManually(true);

                                // --- Reset dependent dropdowns ---
                                setSelectedSubType("");
                                setSelectedFamily("");
                                setSubTypes([]);
                                setFamilies([]);

                                // After Header Thing clear
                                setBaseAttributes([]);
                                setVisibleBaseAttributes([]);
                                setFinalProduct(null);
                                setPendingAttributes([]);
                                setAttributeValues({});
                                setSelectedPartNumber("");

                                // --- Clear existing entity context ---
                                Object.assign(existingValues, {
                                    subType: "",
                                    type: "",
                                    family: "",
                                    crmEntityData: {},
                                    pamEntityData: {},
                                    partNumber: ""
                                });

                                // --- Load dependent data ---
                                const [subTypeOptions, familyOptions] = await Promise.all([
                                    getSubTypes(formContext, selectedValue),
                                    getFamiliesFromType(formContext, businessUnitId, selectedValue)
                                ]);

                                setSubTypes(subTypeOptions);
                                setFamilies(familyOptions);
                            }}
                            className="dropdownControl"
                            placeholder="Select type"
                        >
                            {types.map(type => (
                                <Option key={type.key} value={type.key}>
                                    {type.text}
                                </Option>
                            ))}
                        </Dropdown>
                    </div>

                    {/* Product Sub Type */}
                    <div className="product-form-group">
                        <Label>Product Sub Type</Label>

                        <Dropdown
                            className="dropdownControl"
                            placeholder="Select Sub type"
                            selectedOptions={selectedSubType ? [selectedSubType] : []}
                            value={
                                subTypes.find(t => t.key === selectedSubType)?.text ?? ""
                            }
                            onOptionSelect={async (_, data) => {
                                const selectedValue = data.optionValue ?? "";
                                // --- Update selection ---
                                setSelectedSubType(selectedValue);

                                // --- Reset lower-level selections and data ---
                                // setSelectedType("");
                                setSelectedFamily("");
                                setBaseAttributes([]);
                                setVisibleBaseAttributes([]);
                                setFinalProduct(null);
                                setPendingAttributes([]);
                                setSelectedPartNumber("");
                                setAttributeValues({});


                                // --- Clear existing entity context ---
                                Object.assign(existingValues, {
                                    subType: "",
                                    type: "",
                                    family: "",
                                    crmEntityData: {},
                                    pamEntityData: {},
                                    partNumber: ""
                                });

                                // --- Fetch product info ---
                                const product = await getProductTypeFromSubType(formContext, selectedValue);

                                if (product == null) {
                                    setSelectedType("");
                                }

                                // if (isTypeChangedManually) {
                                //     // Type manually overridden → skip family binding
                                //     // return;
                                // }

                                // --- Auto-set type & fetch families ---
                                setSelectedType(product._crmgp_producttypeid_value);
                                const familyOptions = await getFamilies(
                                    formContext,
                                    businessUnitId,
                                    product._crmgp_producttypeid_value,
                                    selectedValue
                                );
                                setFamilies(familyOptions);
                            }}
                        >
                            {subTypes.map(subType => (
                                <Option key={subType.key} value={subType.key}>
                                    {subType.text}
                                </Option>
                            ))}
                        </Dropdown>

                    </div>

                    {/* Product Family */}
                    <div className="product-form-group">
                        <Label>Product Family</Label>
                        <Dropdown
                            className="dropdownControl"
                            placeholder="Select Product Family"
                            selectedOptions={selectedFamily ? [selectedFamily] : []}
                            value={
                                families.find(t => t.key === selectedFamily)?.text ?? ""
                            }
                            onOptionSelect={async (_, data) => {

                                setBaseAttributes([]);
                                setVisibleBaseAttributes([]);
                                setFinalProduct(null);
                                setPendingAttributes([]);
                                setAttributeValues({});

                                const selectedValue = data.optionValue ?? "";
                                setSelectedFamily(selectedValue);
                                setSelectedPartNumber("");

                                // --- Clear existing entity context ---
                                Object.assign(existingValues, {
                                    subType: "",
                                    type: "",
                                    family: "",
                                    crmEntityData: {},
                                    pamEntityData: {},
                                    partNumber: ""
                                });

                                // --- Get related product info ---
                                const product = await getTypeSubTypeFromFamily(formContext, selectedValue);

                                if (isTypeChangedManuallyRef.current) {
                                    // Type manually changed → ensure subtype is valid
                                    const subTypeValue = selectedSubType || product._crmgp_productsubtypeid_value;
                                    setSelectedSubType(subTypeValue);
                                    loadDataOnHeaderChange(selectedType, subTypeValue, selectedValue);
                                } else {
                                    // Clear Types ANd Sub Types and load again 
                                    // Auto-load full hierarchy
                                    const subTypes = await getSubTypes(formContext, product._crmgp_producttypeid_value);
                                    setSubTypes(subTypes);
                                    setSelectedType(product._crmgp_producttypeid_value);
                                    setSelectedSubType(product._crmgp_productsubtypeid_value);
                                    loadDataOnHeaderChange(product._crmgp_producttypeid_value, product._crmgp_productsubtypeid_value, selectedValue);
                                }
                            }}
                        >
                            {families.map(family => (
                                <Option key={family.key} value={family.key}>
                                    {family.text}
                                </Option>
                            ))}
                        </Dropdown>
                    </div>

                    {/* Product Number */}
                    <div className="product-form-group" style={{ position: "relative" }}>
                        <Label>Product Number</Label>
                        <Input
                            id="crmgp_partNumber"
                            className="textControl partnumber-input"
                            placeholder="Enter product number"
                            data-crmfieldname="crmgp_partNumber"
                            value={selectedPartNumber ?? ""}
                            onFocus={() => {
                                if (suggestions.length > 0) {
                                    setShowSuggestions(true);
                                }
                            }}
                            onBlur={() => {
                                setTimeout(() => setShowSuggestions(false), 100);
                            }}
                            onChange={(e) => {
                                onProductNumberChange(e)
                            }}
                        />
                        {showSuggestions && suggestions.length > 0 && (
                            <div className="suggestion-container">
                                {suggestions.length > 0 && (
                                    <div className="suggestion-list">
                                        {suggestions.map((sug) => (
                                            <div key={sug.partnumber}
                                                onMouseDown={() => handleProductNumberSelect(sug.data)}
                                                // onMouseEnter={() => setHoveredSuggestion(sug)}
                                                // onMouseLeave={() => setHoveredSuggestion(null)}
                                                className={`suggestion-item ${hoveredSuggestion === sug.partnumber ? "hovered" : ""}`}
                                            >
                                                {sug.partnumber}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>

            </div>
        )
    };
    // #endregion

    // #region : ON Header Change and bind Base Attribute and Attribute
    const loadDataOnHeaderChange = async (type?: string, subtype?: string, family?: string) => {
        if (!type || !subtype || !family) return;

        const baseAttributesList = await getProductsForCombination(formContext, type, subtype, family);

        const productList = baseAttributesList.pamProductListData || [];
        setProducts(productList);

        const baseAttrs: DynamicAttributeBaseAttribute[] = baseAttributesList.getBaseAttributeContols;

        setBaseAttributes(baseAttrs);
        setVisibleBaseAttributes([]);
        setBaseAttrValues({});

        if (baseAttrs.length > 0) {
            await resolveBaseAttributeOnHeaderChange(baseAttrs, 0, productList, {}, []);
        }
        else {
            await renderAttributeFromFamily(type, subtype, family);
        }
    };

    // Progressive resolver for base attributes
    const resolveBaseAttributeOnHeaderChange = async (
        baseAttributes: DynamicAttributeBaseAttribute[],
        nextIndex: number,
        productList: any[],
        selectedBaseAttrValues: Record<string, string>,
        currentVisibleAttrs: DynamicAttributeBaseAttribute[]
    ) => {

        if (baseAttributes.length > 0) {
            const filteredProducts = [...productList];
            const nextAttr = baseAttributes[nextIndex];
            const attrName = nextAttr.cmrfieldname;
            setVisibleBaseAttributes((prev: any) => [...prev, nextAttr]);

        }
        else {
            formContext.openAlertDialog("Warning", "No matching product found. Please select a valid combination.");
            // Try to clear Pending Attribute
            // If still ambiguous or no match
            setFinalProduct(undefined);
            setPendingAttributes([]);
        }
    }
    // #endregion

    // #region : Productt Number On Change and its Logic
    const onProductNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {

        // Your logic to handle product number change  const value = e.target.value;
        const value = e.target.value;
        setSelectedPartNumber(value);
        if (value.length >= 3) {
            setShowSuggestions(true);  // show suggestions
            fetchProductNumberSuggestions(value);
        }
        else {
            setSuggestions([]);
            setShowSuggestions(false); // hide suggestions

            // Clear selections if input is cleared
            setSelectedType("");
            setSelectedSubType("");
            setSelectedFamily("");
            setBaseAttributes([]);
            setVisibleBaseAttributes([]);
            setFinalProduct(null);
            setPendingAttributes([]);
        }
    };

    const fetchProductNumberSuggestions = async (query: string) => {
        try {

            const res = await searchProductByPartNumber(formContext, query, businessUnitId);

            const unique = new Map<string, any>();
            res.forEach((r: any) => {
                if (!unique.has(r.productnumber)) {
                    unique.set(r.productnumber, r);
                }
            });

            // Auto-select if full match
            if (unique.has(query)) {
                handleProductNumberSelect(unique.get(query));
            }
            else {
                const suggestionItems = Array.from(unique.entries()).map(([partnumber, data]) => ({
                    partnumber, // <-- use partnumber instead of label
                    data,
                }));
                hasInitializedRef.current = true;
                setSuggestions(suggestionItems);
            }

        } catch (error) {
            console.error("Error fetching product number suggestions:", error);
            setSuggestions([]);
        }
    };

    const handleProductNumberSelect = async (record: any) => {
        const selected = record.productnumber;
        setSelectedPartNumber(selected); // Set selected part number
        setSuggestions([]);               // Clear suggestions so list disappears
        setHoveredSuggestion(null);       // Reset hover state
        setShowSuggestions(false);        // Hide dropdown

        try {

            if (!record) {
                formContext.openAlertDialog("Product Not Found", `No product found with product number '${selected}'.`);


                return;
            }

            Object.assign(existingValues, {
                subType: "",
                type: "",
                family: "",
                crmEntityData: {},
                pamEntityData: {},
                partNumber: ""
            });
            const type = record["_new_producttype_value"];
            const subtype = record["_new_productsubtype_value"];
            const family = record["_new_family_value"];

            if (!type && !subtype && !family) {
                formContext.openAlertDialog("Missing Mappings", `Product '${record.name}' is missing Product Type, Sub Type, and Family mapping. Please check the data.`);
                return;
            }

            // Get Options and bind inside THree Dropdowns
            setSelectedFamily(family);
            const subTypes = await APIHelper.getSubTypesByRecordBU(formContext, businessUnitId);

            setSubTypes(subTypes);
            setSelectedType(type);
            setSelectedSubType(subtype);
            loadDataOnProductNumberChange(type, subtype, family, selected, true);

        } catch (err) {
            console.error("Error loading full product details:", err);
            formContext.openAlertDialog("Error", "Something went wrong while retrieving the product details.");
        }
    };

    // #endregion

    // #region : Save and Validation
    const saveProductAttributesWithParent = async (parentEntity: string, parentId: string) => {
        try {
            const payload: Record<string, unknown> = {};
            const record: Record<string, unknown> = {};

            // 1. Collect from all dynamic fields
            Object.entries(baseAttributesValuesRef.current).forEach(([field, value]) => {
                if (field && value !== undefined) {
                    payload[field] = value;
                }
            });

            Object.entries(attributeValuesRef.current).forEach(([field, value]) => {
                if (field && value !== undefined) {
                    payload[field] = value;
                }
            });

            // let productAttributeId: string | null = existingValues?.crmEntityData["new_productattributesid"] || null;
            const productAttributeField = context.parameters.ProductAttributeLookup?.raw;
            let productAttributeId: string | null = productAttributeField.length > 0 ? productAttributeField[0]?.id : null;

            if (parentEntity == "opportunityproduct") {
                payload["new_OpportunityProduct@odata.bind"] = `/opportunityproducts(${parentId})`;
            }
            else if (parentEntity == "qoutedetail") {
                payload["new_QuoteDetail@odata.bind"] = `/quotedetails(${parentId})`;
            }
            else if (parentEntity == "salesorderdetail") {
                payload["new_SalesOrderDetail@odata.bind"] = `/salesorderdetails(${parentId})`;
            }

            if (productAttributeId) {
                await formContext.updateRecord("new_productattributes", productAttributeId, payload);
            }
            else {
                const created = await formContext.createRecord("new_productattributes", payload);
                productAttributeId = created.id;
            }

            // 3. Link to parent record
            if (productAttributeId) {
                record["new_ProductAttribute@odata.bind"] = `/new_productattributeses(${productAttributeId})`;

                await formContext.updateRecord(parentEntity, parentId, record);
            }
        } catch (e: any) {
            console.error("Failed to save product attributes:", e);
            alert("Failed to save product attributes: " + e.message);
        }
    };

    const validateBaseAttributesFromRefs = async (): Promise<ValidationResult> => {

        const defaultResult: ValidationResult = {
            isValid: false,
            productCode: null,
            pamProductId: null,
            crmProductid: null,
            productPartNumber: null,
            productDescription: null,
            pamProductType: null,
            pamProductSubType: null,
            pamProductFamily: null,
            uomid: null
        };


        const pamProductId = pamProductIdRef.current || '';
        const pamProductConfigs: any = await getPamProductConfigDetails(formContext, pamProductId);

        const productType = pamProductConfigs.crmgp_producttype || "";
        defaultResult.pamProductType = pamProductConfigs['_crmgp_producttypeid_value@OData.Community.Display.V1.FormattedValue'] || "";
        defaultResult.pamProductSubType = pamProductConfigs['_crmgp_productsubtypeid_value@OData.Community.Display.V1.FormattedValue'] || "";
        defaultResult.pamProductFamily = pamProductConfigs['_crmgp_productfamilyid_value@OData.Community.Display.V1.FormattedValue'] || "";


        const isValidAttributes = validateAttributes(productType, formContext,
            pendingAttributesRef.current, attributeValuesRef.current, selectedPartNumberRef.current);

        if (!isValidAttributes) {
            return defaultResult;
        }

        const validCrmPart = await validateCrmPartNumber(pamProductConfigs);
        if (validCrmPart == null || validCrmPart.productcode == 0) {
            return defaultResult;
        }

        defaultResult.isValid = true;
        defaultResult.productCode = validCrmPart.productcode;
        defaultResult.pamProductId = pamProductId;
        defaultResult.crmProductid = validCrmPart.productid;
        defaultResult.productPartNumber = validCrmPart.partno;
        defaultResult.productDescription = validCrmPart.productdescription;
        defaultResult.uomid = validCrmPart.uomid;
        return defaultResult;
    };



    const validateCrmPartNumber = async (pamProductConfigs: any): Promise<CRMProductEntity | null> => {

        const defaultCRMProductEntity: CRMProductEntity | null = {
            productcode: 0,
            partno: "",
            productdescription: "",
            productid: "",
            uomid: ""
        }

        const productType = pamProductConfigs.crmgp_producttype || "";
        let partNo = selectedPartNumberRef.current;
        let partDescription = "";

        if (PAM_PRODUCT_TYPE[productType] !== "StandardProduct") {
            const partInfo = generatePartInfoFromControls(baseAttributesRef.current,
                pendingAttributesRef.current,
                baseAttributesValuesRef.current,
                attributeValuesRef.current,
                false, pamProductConfigs
            );

            partNo = partInfo.partNo;
            partDescription = partInfo.partDescription;
        }

        if (partNo && partNo.trim().length >= 1) {
            const defaultCRMProductEntity = await getProductFromPartNumber(formContext, partNo, partDescription);
            if (defaultCRMProductEntity) {
                setSelectedPartNumber(partNo);
                setCrmProductEntity(defaultCRMProductEntity ? defaultCRMProductEntity : undefined);
                //formContext.setFieldValue("new_productcode", result.productcode);
                return defaultCRMProductEntity; // Return true if part number is valid
            }
        }
        return null; // Return false if validation fails
    };
    // #endregion

    return (
        <FluentProvider theme={webLightTheme}>
            <div id="">
                {renderDropdowns()}

                {visibleBaseAttributes.length > 0 && (
                    <div id="reactbaseattributesContainer">
                        {
                            visibleBaseAttributes.map((baseAttr, index) => {
                                const isLast = index === pendingAttributes.length - 1;

                                // const baseattvalue = getBaseAttributeValue(baseAttr, existingValues.crmEntityData);
                                const baseattvalue = baseAttr.selectedBaseValue;
                                const baseselectedOptions = baseattvalue ? [baseattvalue] : [];

                                return (
                                    <div key={baseAttr.cmrfieldname} className="product-form-group">
                                        <Label>{baseAttr.attributename}</Label>
                                        <Dropdown
                                            className="dropdownControl"
                                            placeholder={`Select ${baseAttr.attributename}`}
                                            // selectedOptions={baseAttributesValues[baseAttr.cmrfieldname] ? [baseAttributesValues[baseAttr.cmrfieldname]] : []}
                                            // value={baseAttributesValues[baseAttr.cmrfieldname] || ""}
                                            selectedOptions={baseselectedOptions}
                                            value={baseattvalue || ""}
                                            onOptionSelect={(_, data) => handleBaseAttrChange(baseAttr.cmrfieldname, data.optionValue as string)}
                                        >
                                            <Option value="">---Select---</Option>
                                            {(baseAttr.options || []).map(opt => (
                                                <Option key={opt.attributevalue} value={opt.attributevalue}>
                                                    {opt.attributevalue}
                                                </Option>
                                            ))}
                                        </Dropdown>
                                    </div>
                                )
                            })
                        }
                    </div>
                )}
                <div id="reactattributesContainer" >
                    {pendingAttributes.map((attr, index) => {
                        const isLast = index === pendingAttributes.length - 1;
                        const currentEntity = formContext.getCurrentEntityName();
                        const isHidden = attr.crmgp_hidden;
                        const isRequired =
                            currentEntity === "opportunityproduct"
                                ? attr.crmgp_requiredproject
                                : currentEntity === "qoutedetail"
                                    ? attr.crmgp_requiredquote
                                    : attr.crmgp_requiredorder;



                        // const selectedOptions = value ? [value] : [];
                        const value = attr.selectedValue;
                        const selectedOptions = value ? [value] : [];
                        // decide if this field should take the full row
                        const isNotesField = ["new_pa_notes", "new_pa_pass_attribute_to_jde"].includes(attr.crmfieldname);

                        // pick wrapper classes
                        const wrapperClass = `field-wrapper ${isNotesField ? "full-span" : ""}`;

                        return (
                            <div
                                key={attr.id}
                                className={wrapperClass}
                                style={{ display: isHidden === true ? "none" : undefined }}
                            >
                                <Label htmlFor={attr.crmfieldname}>
                                    {attr.name}
                                    {isRequired === true ? <span style={{ color: "red" }}>*</span> : ""}
                                </Label>
                                {renderAttributeControl({
                                    attr,
                                    selectedvalue: value,
                                    selectedOptions: selectedOptions,
                                    OnChanage: handleAttributeValueChange
                                })}
                            </div>
                        );
                    }
                    )}
                    {hasSuggestiondNumberRef.current = false}
                    {isReverseLogicRef.current = false}

                </div>
            </div>
        </FluentProvider>
    ); // Placeholder for the component structure
}

export default ProductAttributeSelector;