/* eslint-disable @typescript-eslint/no-explicit-any */


import * as React from "react";
import {
    Button,
    Dialog,
    DialogSurface,
    DialogBody,
    DialogTitle,
    DialogContent,
    DialogActions,
    Input,
    Table,
    TableHeader,
    TableRow,
    TableHeaderCell,
    TableBody,
    TableCell
} from "@fluentui/react-components";
import { searchProduct } from "./CRMApi";

interface ProductSearchModalProps {
    formContext: any,
    businessUnitId: string,
    open: boolean;
    onClose: () => void;
    // onSelectProduct: (partNumber: string) => void;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

interface ProductRecord {
    productid: string;
    productnumber: string;
    description?: string;
    name?: string;
    new_altproductdescription?: string;
    new_productcode?: string;
}

interface Props {
    results: ProductRecord[];
    handleSelect: (product: ProductRecord) => void;
}
const PAGE_SIZE = 12;

const ProductSearchModal: React.FC<ProductSearchModalProps> = ({
    formContext,
    businessUnitId,
    open,
    onClose,
    onChange
}) => {
    const [partNo, setPartNo] = React.useState("");
    const [productDesc, setProductDesc] = React.useState("");
    const [altProductDesc, setAltProductDesc] = React.useState("");
    const [results, setResults] = React.useState<ProductRecord[]>([]);
    const [loading, setLoading] = React.useState(false);


    // 🔹 Pagination state
    const [currentPage, setCurrentPage] = React.useState(1);
    const totalPages = Math.ceil(results.length / PAGE_SIZE);

    const startIndex = (currentPage - 1) * PAGE_SIZE;
    const endIndex = startIndex + PAGE_SIZE;
    const currentRows = results.slice(startIndex, endIndex);

    // 🔹 Search Click
    const handleSearch = async () => {
        try {
            
            if (!productDesc && !altProductDesc && !partNo) {
                alert("Please enter at least one search criteria.");
                return;
            }

            setLoading(true);

            setResults([]);
            setCurrentPage(1); // reset pagination

            const data = await searchProduct(formContext,businessUnitId, partNo, productDesc, altProductDesc);
            setResults(data);
        } catch (error: any) {
            console.error("Error retrieving products:", error);
            alert("Failed to retrieve products: " + error.message);
        } finally {
            setLoading(false);
        }
    };

    // 🔹 Clear
    const handleClear = () => {
        
        setPartNo("");
        setProductDesc("");
        setAltProductDesc("");
        setResults([]);
        setCurrentPage(1);
    };

    // 🔹 Cancel
    const handleCancel = () => {
        handleClear();
        onClose();
    };

    // 🔹 Select Product
    const handleSelect = (record: ProductRecord) => {
        
        // onSelectProduct(record.productnumber);
        // Create a *type-safe* synthetic event
        const fakeEvent = {
            target: { value: record.productnumber }
        } as unknown as React.ChangeEvent<HTMLInputElement>;

        onChange(fakeEvent);
        handleClear();
        onClose();
    };

    // 🔹 Pagination controls
    const goToPage = (page: number) => {
        if (page >= 1 && page <= totalPages) setCurrentPage(page);
    };


    return (
        <Dialog open={open} onOpenChange={(_, data) => !data.open && onClose()}>
            <DialogSurface style={{ maxWidth: "80vw" }}>
                <DialogBody>
                    <DialogTitle>Product Search</DialogTitle>
                    <DialogContent>
                        {/* 🔸 Row 1: Textboxes */}
                        <div style={{ display: "flex", gap: "12px", marginBottom: "12px" }}>
                            <Input
                                placeholder="Part No"
                                value={partNo}
                                onChange={(_, data) => setPartNo(data.value)}
                                style={{ flex: 1 }}
                            />
                            <Input
                                placeholder="Product Description"
                                value={productDesc}
                                onChange={(_, data) => setProductDesc(data.value)}
                                style={{ flex: 1 }}
                            />
                            <Input
                                placeholder="Alt Product Description"
                                value={altProductDesc}
                                onChange={(_, data) => setAltProductDesc(data.value)}
                                style={{ flex: 1 }}
                            />
                        </div>

                        {/* 🔸 Row 2: Buttons */}
                        <div style={{ display: "flex", gap: "8px", marginBottom: "16px" }}>
                            <Button appearance="primary" onClick={handleSearch} disabled={loading}>
                                {loading ? "Searching..." : "Search"}
                            </Button>
                            <Button appearance="secondary" onClick={handleClear}>
                                Clear
                            </Button>
                            <Button appearance="outline" onClick={handleCancel}>
                                Cancel
                            </Button>
                        </div>

                        {/* 🔸 Row 3: Table Results */}
                        {results.length > 0 && (
                            <>
                                <Table
                                    aria-label="Product Results Table"
                                    style={{
                                        tableLayout: "auto",
                                        width: "auto",
                                        minWidth: "100%",
                                    }}
                                >
                                    <TableHeader>
                                        <TableRow>
                                            <TableHeaderCell style={{ fontWeight: "bold" }}>Part No</TableHeaderCell>
                                            <TableHeaderCell style={{ fontWeight: "bold" }}>Product Description</TableHeaderCell>
                                            <TableHeaderCell style={{ fontWeight: "bold" }}>Alt Product Description</TableHeaderCell>
                                            <TableHeaderCell style={{ fontWeight: "bold" }}>Product Code</TableHeaderCell>
                                            <TableHeaderCell style={{ fontWeight: "bold" }}>Action</TableHeaderCell>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {currentRows.map((r) => (
                                            <TableRow key={r.productid}>
                                                <TableCell style={{ whiteSpace: "nowrap" }}>{r.productnumber}</TableCell>
                                                <TableCell>{r.name ?? ""}</TableCell>
                                                <TableCell>{r.new_altproductdescription ?? ""}</TableCell>
                                                <TableCell>{r.new_productcode ?? ""}</TableCell>
                                                <TableCell>
                                                    <Button
                                                        size="small"
                                                        appearance="primary"
                                                        onClick={() => handleSelect(r)}
                                                    >
                                                        Select
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>

                                {/* 🔹 Pagination Controls */}
                                <div
                                    style={{
                                        display: "flex",
                                        justifyContent: "space-between",
                                        alignItems: "center",
                                        marginTop: "12px",
                                    }}
                                >
                                    <span style={{ fontSize: "13px" }}>
                                        Showing {startIndex + 1}–{Math.min(endIndex, results.length)} of{" "}
                                        {results.length}
                                    </span>
                                    <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                                        <Button
                                            size="small"
                                            onClick={() => goToPage(currentPage - 1)}
                                            disabled={currentPage === 1}
                                        >
                                            Previous
                                        </Button>
                                        <span>
                                            Page {currentPage} of {totalPages}
                                        </span>
                                        <Button
                                            size="small"
                                            onClick={() => goToPage(currentPage + 1)}
                                            disabled={currentPage === totalPages}
                                        >
                                            Next
                                        </Button>
                                    </div>
                                </div>
                            </>
                        )}

                        {results.length === 0 && !loading && (
                            <p style={{ textAlign: "center", color: "#999" }}>
                                No records found.
                            </p>
                        )}
                    </DialogContent>

                    {/* <DialogActions>
                        <Button appearance="secondary" onClick={handleCancel}>
                            Close
                        </Button>
                    </DialogActions> */}
                </DialogBody>
            </DialogSurface>
        </Dialog>
    );
};

export default ProductSearchModal;
