/* eslint-disable @typescript-eslint/no-explicit-any */
import {
    PamProductList,
    DynamicAttributeBaseAttribute,
    DynamicAttributeoptions,
    DynamicAttribute,
    CRMProductEntity,
    FetchXmlFilter,
    ATTRIBUTE_CONTROL_TYPE
} from "../types/commonType";
import { sortOptions } from "./CRMHelper";

export async function fetchAllODataRecords(
    formContext: any,
    entityName: string,
    selectFields?: string[],
    filter = "",
    orderBy?: string): Promise<any[]> {

    const queryParts: string[] = [];

    if (selectFields && selectFields.length > 0) {
        queryParts.push(`$select=${selectFields.join(",")}`);
    }

    if (filter) {
        queryParts.push(`$filter=${filter}`);
    }

    if (orderBy) {
        queryParts.push(`$orderby=${orderBy}`);
    }
    const query = queryParts.join("&");
    const nextLink: string | null = `?${query}`;
    try {
        const result: any = await formContext.retrieveMultipleRecords(
            entityName,
            nextLink
        );
        return result;
    } catch (error) {
        console.error("Error fetching OData records:", error);
        return [];
    }
}


export async function fetchAllDistinctFetchXmlRecords(
    formContext: any,
    entityName: string,
    distinctFields: string[],
    filters?: FetchXmlFilter[],
    orderByFields?: string[]
): Promise<any[]> {
    if (!distinctFields || distinctFields.length === 0) {
        throw new Error("At least one field must be specified for distinct retrieval.");
    }

    const attributesXml = distinctFields
        .map(field => `<attribute name="${field}" />`)
        .join("");

    const orderByXml = (orderByFields || [])
        .map(field => `<order attribute="${field}" descending="false" />`)
        .join("");

    let filterXml = "";
    if (filters && filters.length > 0) {
        const conditions = filters
            .map(f =>
                `<condition attribute="${f.attribute}" operator="${f.operator}" value="${f.value}" />`
            )
            .join("");
        filterXml = `<filter type="and">${conditions}</filter>`;
    }

    const fetchXml = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">
                        <entity name="${entityName}">
                            ${attributesXml}
                            ${orderByXml}
                            ${filterXml}
                        </entity>
                    </fetch>`;

    try {

        const encodedFetchXml = encodeURIComponent(fetchXml);
        const result = await formContext.retrieveMultipleRecords(
            entityName,
            `?fetchXml=${encodedFetchXml}`
        );

        return result || [];
    } catch (error) {
        console.error("FetchXML Error:", error);
        return [];
    }
}

export async function getBusinessUnit(formContext: any): Promise<string> {
    try {
        const entityType = formContext._entityName;
        const userId = formContext.getCurrentUserId();
        const businessUnitId = await formContext.getBusinessUnit(userId);
        return businessUnitId;
    } catch (error) {
        console.error("Error getting Business Unit:", error);
        return "";
    }
}


export async function getBusinessUnitFromRecord(formContext: any): Promise<string> {
    try {
        const entityType = formContext._entityName?.toLowerCase();
        let businessUnitId = "";
        if (!entityType) {
            console.warn("Entity type not found in form context.");
            return "";
        }
        let parentId = "";
        let parentEntity = "";

        // Determine parent entity & ID based on where PCF is used
        switch (entityType) {
            case "opportunityproduct":
                parentEntity = "opportunity";
                parentId = formContext.getFieldValue("opportunityid")?.[0]?.id.replace('{', '').replace('}', '');
                break;

            case "quotedetail":
                parentEntity = "quote";
                parentId = formContext.getFieldValue("quoteid")?.[0]?.id.replace('{', '').replace('}', '');
                break;

            case "salesorderdetail": // order product
            case "orderproduct":
                parentEntity = "salesorder";
                parentId = formContext.getFieldValue("salesorderid")?.[0]?.id.replace('{', '').replace('}', '');
                break;
            default:
                console.warn(`Unsupported entity type: ${entityType}`);
                break;

        }

        if (parentId && parentEntity) {
            const response = await formContext.retrieveRecord(
                parentEntity,
                parentId,
                "?$select=" + parentEntity + "id,_owningbusinessunit_value"
            );
            businessUnitId = response["_owningbusinessunit_value"] || "";
        }
        return businessUnitId;
    } catch (error) {
        console.error("Error getting Business Unit:", error);
        return "";
    }
}


export async function getTypesByUserBU(formContext: any, businessUnitId: string): Promise<{ key: string; text: string }[]> {
    const options: { key: string; text: string }[] = [];
    try {
        const result = await fetchAllDistinctFetchXmlRecords(formContext, "product",
            ["new_producttype"],
            [
                { attribute: "statecode", operator: "eq", value: 0 },
                { attribute: "new_owningbusinessunit", operator: "eq", value: businessUnitId },
                { attribute: "new_producttype", operator: "not-null", value: "" }

            ],
            ["new_producttype"]
        );

        // Deduplicate in calling code if needed
        const unique = Array.from(new Map(result.map(r => [r._new_producttype_value, r])).values());

        unique.forEach((e) => {
            options.push({
                key: e._new_producttype_value,
                text: e["_new_producttype_value@OData.Community.Display.V1.FormattedValue"]
            });
        });
    } catch (error) {
        console.error("Error fetching products:", error);
    }
    return options;
}

export async function getSubTypes(formContext: any, productType: string): Promise<{ key: string; text: string }[]> {
    const options: { key: string; text: string }[] = [];
    try {

        const result = await fetchAllDistinctFetchXmlRecords(formContext, "crmgp_productsubtype",
            ["crmgp_productsubtypeid", "crmgp_name"],
            [
                { attribute: "statecode", operator: "eq", value: 0 },
                { attribute: "crmgp_producttypeid", operator: "eq", value: productType }

            ],
            ["crmgp_name"]
        );

        // Deduplicate in calling code if needed
        const unique = Array.from(new Map(result.map(r => [r.crmgp_productsubtypeid, r])).values());

        unique.forEach((e) => {
            options.push({
                key: e.crmgp_productsubtypeid,
                text: e.crmgp_name
            });
        });
    } catch (error) {
        console.error("Error fetching sub types:", error);
    }
    return options;
}

export async function getSubTypesByRecordBU(formContext: any, businessUnitId: string): Promise<{ key: string; text: string }[]> {
    const options: { key: string; text: string }[] = [];
    try {

        const result = await fetchAllDistinctFetchXmlRecords(formContext, "crmgp_productsubtype",
            ["crmgp_productsubtypeid", "crmgp_name"],
            [
                { attribute: "statecode", operator: "eq", value: 0 }
                // { attribute: "owningbusinessunit", operator: "eq", value: businessUnitId }
            ],
            ["crmgp_name"]
        );

        // Deduplicate in calling code if needed
        const unique = Array.from(new Map(result.map(r => [r.crmgp_productsubtypeid, r])).values());

        unique.forEach((e) => {
            options.push({
                key: e.crmgp_productsubtypeid,
                text: e.crmgp_name
            });
        });
    } catch (error) {
        console.error("Error fetching sub types:", error);
    }
    return options;
}

export async function getFamilies(formContext: any, businessUnitId: string, productType?: string, productSubType?: string): Promise<{ key: string; text: string }[]> {
    const options: { key: string; text: string }[] = [];
    try {

        const result = await fetchAllDistinctFetchXmlRecords(formContext, "product",
            ["new_family"],
            [
                { attribute: "statecode", operator: "eq", value: 0 },
                { attribute: "new_producttype", operator: "eq", value: productType ?? "" },
                { attribute: "new_productsubtype", operator: "eq", value: productSubType ?? "" },
                { attribute: "new_owningbusinessunit", operator: "eq", value: businessUnitId ?? "" }
            ],
            ["new_family"]
        );
        // Deduplicate in calling code if needed
        const unique = Array.from(new Map(result.map(r => [r._new_family_value, r])).values());

        unique.forEach((e) => {
            options.push({
                key: e._new_family_value,
                text: e["_new_family_value@OData.Community.Display.V1.FormattedValue"]
            });
        });
    } catch (error) {
        console.error("Error fetching products:", error);
    }
    return options;
}

export async function getFamiliesFromType(formContext: any, businessUnitId: string, productType?: string, productSubType?: string): Promise<{ key: string; text: string }[]> {
    const options: { key: string; text: string }[] = [];
    try {

        const result = await fetchAllDistinctFetchXmlRecords(formContext, "product",
            ["new_family"],
            [
                { attribute: "statecode", operator: "eq", value: 0 },
                { attribute: "new_producttype", operator: "eq", value: productType ?? "" },
                { attribute: "new_owningbusinessunit", operator: "eq", value: businessUnitId ?? "" }
            ],
            ["new_family"]
        );
        // Deduplicate in calling code if needed
        const unique = Array.from(new Map(result.map(r => [r._new_family_value, r])).values());

        unique.forEach((e) => {
            options.push({
                key: e._new_family_value,
                text: e["_new_family_value@OData.Community.Display.V1.FormattedValue"]
            });
        });
    } catch (error) {
        console.error("Error fetching products:", error);
    }
    return options;
}

export async function getFamiliesByRecordBu(formContext: any, businessUnitId: string, productType?: string, productSubType?: string): Promise<{ key: string; text: string }[]> {
    const options: { key: string; text: string }[] = [];
    try {

        const result = await fetchAllDistinctFetchXmlRecords(formContext, "product",
            ["new_family"],
            [
                { attribute: "statecode", operator: "eq", value: 0 },
                { attribute: "new_family", operator: "not-null", value: "" },
                { attribute: "new_owningbusinessunit", operator: "eq", value: businessUnitId }
            ],
            ["new_family"]
        );
        // Deduplicate in calling code if needed
        const unique = Array.from(new Map(result.map(r => [r._new_family_value, r])).values());

        unique.forEach((e) => {
            options.push({
                key: e._new_family_value,
                text: e["_new_family_value@OData.Community.Display.V1.FormattedValue"]
            });
        });
    } catch (error) {
        console.error("Error fetching products:", error);
    }
    return options;
}

export async function getPamProductConfigDetails(formContext: any, pamProductId: string): Promise<Record<string, string>> {
    const cleanData: Record<string, string> = {};
    try {

        const result = await fetchAllODataRecords(formContext, "crmgp_product", undefined,
            `statecode eq 0 and crmgp_isactive eq true and crmgp_productid eq ${pamProductId}`,
            undefined);

        const record = result?.[0];
        if (record) {
            Object.keys(record).forEach((key) => {
                const value = record[key];
                if (key && value !== undefined) {
                    cleanData[key] = value;
                }
            });
        }
    } catch (error) {
        console.error("Error loading PAM values:", error);
    }
    return cleanData;
}

export async function getProductAttributes(formContext: any, productAttributeId: string): Promise<Record<string, string>> {
    const cleanData: Record<string, string> = {};
    try {

        const result = await fetchAllODataRecords(formContext, "new_productattributes", undefined,
            `statecode eq 0 and new_productattributesid eq ${productAttributeId}`,
            undefined);

        const record = result?.[0];
        if (record) {
            Object.keys(record).forEach((key) => {
                const value = record[key];
                if (key && value !== undefined) {
                    cleanData[key] = value;
                }
            });
        }
    } catch (error) {
        console.error("Error fetching products:", error);
    }
    return cleanData;
}

export async function getProductsForCombination(formContext: any, productType?: string, productSubType?: string, productFamily?: string):
    Promise<{
        getBaseAttributeContols: DynamicAttributeBaseAttribute[],
        pamProductListData: PamProductList[]
    }> {


    let baseattributes: DynamicAttributeBaseAttribute[] = [];
    const baseAttributeMap = new Map<string, DynamicAttributeBaseAttribute>();
    // const transformed: { [productId: string]: any } = {};
    const transformed: PamProductList[] = [];
    try {

        const fetchXml = `<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">
                            <entity name="crmgp_baseproductattribute">
                                <all-attributes />
                                <order attribute="crmgp_attributesequence" descending="false" />
                                <filter type="and">
                                <condition attribute="statecode" operator="eq" value="0" />
                                <condition attribute="crmgp_isactive" operator="eq" value="1" />
                                <condition attribute="crmgp_crmfieldname" operator="not-null" />
                                </filter>
                                <link-entity name="crmgp_product" from="crmgp_productid" to="crmgp_productid" alias="product">
                                <filter type="and">
                                    <condition attribute="crmgp_productfamilyid" operator="eq" value="${productFamily}" />
                                    <condition attribute="crmgp_producttypeid" operator="eq" value="${productType}" />
                                    <condition attribute="crmgp_productsubtypeid" operator="eq" value="${productSubType}" />
                                    <condition attribute="crmgp_isactive" operator="eq" value="1" />
                                </filter>
                                </link-entity>
                            </entity>
                        </fetch>`;

        const encodedFetchXml = encodeURIComponent(fetchXml);
        const result = await formContext.retrieveMultipleRecords("crmgp_baseproductattribute", `?fetchXml=${encodedFetchXml}`);

        result.forEach((item: any) => {
            const crmFieldName = item.crmgp_crmfieldname;
            const attributeName = item.crmgp_attributename;

            const option: DynamicAttributeoptions = {
                key: item.crmgp_attributevalue,
                text: item.crmgp_attributevalue,
                pamproductid: item._crmgp_productid_value,
                attributeName: item.crmgp_attributename,
                attributeId: item.crmgp_baseproductattributeid,
                attributevalue: item.crmgp_attributevalue,
                attributevaluemetric: item.crmgp_attributevaluemetric,
                startindex: item.crmgp_startindex,
                partnostartfrom: item.crmgp_partnostartfrom,
                partnolength: item.crmgp_partnolength,
                partnolengthmetric: item.crmgp_partnolengthmetric,
                startlocation: item.crmgp_rulestartfrom,
                startlocationmetric: item.crmgp_rulestartfrommetric,
                rulename: item.crmgp_rulename,
                rulemetric: item.crmgp_rulenamemetric,
                rulelength: item.crmgp_rulelength,
                rulelengthmetric: item.crmgp_rulelengthmetric,
                cmrfieldname: item.crmgp_crmfieldname,
                foxprofieldmapindex: item.crmgp_foxprofieldmapindex
            };

            if (!baseAttributeMap.has(crmFieldName)) {
                // First time seeing this crmfieldname
                baseAttributeMap.set(crmFieldName, {
                    attributename: attributeName,
                    cmrfieldname: crmFieldName,
                    options: [option],
                });
            } else {
                // Already exists – append to options
                const existing = baseAttributeMap.get(crmFieldName)!;
                // Prevent duplicate option entries by value
                if (!existing.options.some(o => o.key === option.key)) {
                    existing.options.push(option);
                }
            }
        });

        result.forEach((item: { _crmgp_productid_value: any; crmgp_attributename: any; crmgp_attributevalue: any; crmgp_crmfieldname: any; }) => {
            const productId = item._crmgp_productid_value;
            const attributeName = item.crmgp_attributename;
            const attributeValue = item.crmgp_attributevalue;
            const crmfieldname = item.crmgp_crmfieldname

            if (!transformed[productId]) {
                transformed[productId] = { productId };
            }

            if (crmfieldname) {
                transformed[productId][crmfieldname] = attributeValue;
            }
        });
        baseattributes = Array.from(baseAttributeMap.values());

        //apply sorting to options
        baseattributes.forEach(attr => {
            if (attr.options && attr.options.length > 1) {
                attr.options = sortOptions(attr.options);
            }
        });

    } catch (error) {
        console.error("Error fetching products:", error);
    }

    return {
        getBaseAttributeContols: Array.from(baseAttributeMap.values()),
        pamProductListData: Object.values(transformed)
    };
}

export async function getAllAttribute(formContext: any, selectedPamProductId: string): Promise<DynamicAttribute[]> {
    let attributesControls: DynamicAttribute[] = [];
    try {

        const fetchXml = `<fetch>
                                <entity name='crmgp_productattribute'>
                                <all-attributes />
                                <order attribute="crmgp_attributesequence" descending="false" />
                                <filter type='and'>
                                   <condition attribute='statecode' operator='eq' value='0' />
                                   <condition attribute='crmgp_isactive' operator='eq' value='1' />
                                   <condition attribute='crmgp_crmfieldname' operator='not-null' />
                                   <condition attribute='crmgp_productid' operator='eq' value='${selectedPamProductId}' />
                                   </filter>
                                   <link-entity name='crmgp_productattributeoption' from='crmgp_productattributeid' to='crmgp_productattributeid' alias='attributeoption' link-type='outer'>
                                     <all-attributes />
                                     <order attribute="crmgp_rulesequence" descending="false" />
                                   </link-entity>
                                    <link-entity name='crmgp_product' from='crmgp_productid' to='crmgp_productid' alias='linkedproduct' link-type='inner'>
                                        <attribute name='crmgp_producttype' />
                                    </link-entity>
                                <order attribute='crmgp_attributesequence' />
                               </entity>
                            </fetch>`;


        const response = await formContext.retrieveMultipleRecords("crmgp_productattribute", `?fetchXml=${encodeURIComponent(fetchXml)}`);

        // Group attributes by ID
        const grouped: Record<string, DynamicAttribute> = {};
        let productType = null;
        for (const entity of response) {
            const attrId = entity.crmgp_productattributeid;
            productType = entity['linkedproduct.crmgp_producttype'];
            if (!grouped[attrId]) {
                grouped[attrId] = {
                    id: attrId,
                    name: entity.crmgp_name,
                    controlType: entity.crmgp_controltype,
                    crmfieldname: entity.crmgp_crmfieldname,
                    defaultvalue: entity.crmgp_defaultvalue ?? "",
                    crmgp_requiredproject: entity.crmgp_requiredproject,
                    crmgp_requiredorder: entity.crmgp_requiredorder,
                    crmgp_requiredquote: entity.crmgp_requiredquote,
                    startindex: entity.crmgp_startindex,
                    partnostartfrom: entity.crmgp_partnostartfrom,
                    partnolength: entity.crmgp_partnolength,
                    partnolengthmetric: entity.crmgp_partnolengthmetric,
                    rulestartfrom: entity.crmgp_rulestartfrom,
                    rulestartfrommetric: entity.crmgp_rulestartfrommetric,
                    rulelength: entity.crmgp_rulelength,
                    rulelengthmetric: entity.crmgp_rulelengthmetric,
                    defaultvaluemetric: entity.crmgp_defaultvaluemetric,
                    crmgp_hidden: entity.crmgp_hidden,
                    donotupdatepartnoincrm: entity.crmgp_donotupdatepartnoincrm,
                    crmgp_lengthmultiplier: entity.crmgp_lengthmultiplier,
                    options: [],
                    foxprofieldmapindex: entity.crmgp_foxprofieldmapindex
                };
            }
            if (entity["attributeoption.crmgp_ruledescription"]) {
                grouped[attrId].options.push({
                    name: entity["attributeoption.crmgp_name"],
                    ruledescription: entity["attributeoption.crmgp_ruledescription"],
                    rulesequence: entity["attributeoption.crmgp_rulesequence"],
                    rulestartfrom: entity["attributeoption.crmgp_rulestartfrom"],
                    rulelength: entity["attributeoption.crmgp_rulelength"],
                    isactive: entity["attributeoption.crmgp_isactive"],
                    rulenamemetric: entity["attributeoption.crmgp_rulenamemetric"],
                    ruledescriptionmetric: entity["attributeoption.crmgp_ruledescriptionmetric"],
                    rulestartfrommetric: entity["attributeoption.crmgp_rulestartfrommetric"],
                    rulelengthmetric: entity["attributeoption.crmgp_rulelengthmetric"]
                });
            }
        }
        attributesControls = Object.values(grouped);
    } catch (error) {
        console.error("Error fetching products:", error);
    }
    return attributesControls;
}


export async function getProductFromPartNumber(formContext: any, partNo: string, partDescription: string): Promise<CRMProductEntity | null> {

    // Call fetchProductNumberSuggestions and block until done
    const encoded = `?$filter=productnumber eq '${partNo}'`;
    const result = await formContext.retrieveMultipleRecords("product", encoded);
    try {

        if (!result || result.length === 0) {
            formContext.openAlertDialog("Part Number Not Found", `No product found for generated Part Number: ${partNo}`);
            return null;
        }

        const product = result[0];
        const crmProductEntity: CRMProductEntity = {
            productcode: Number(product.new_productcode) || 0,
            productdescription: product.name || "",
            partno: product.productnumber || "",
            productid: product.productid || "",
            uomid: product["_defaultuomid_value"] || ""
        };
        return crmProductEntity;
    } catch (error) {
        console.error("Error validating Part Number:", error);
    }
    return null;
}


export function generatePartInfoFromControls(
    baseattributes: DynamicAttributeBaseAttribute[],
    attributes: DynamicAttribute[],
    baseattributeValues: Record<string, string>,
    attributeValues: Record<string, string>,
    isMetric: boolean,
    pamProduct: any
): { partNo: string; partDescription: string } {

    // Start with default prefix/description from product
    const partNoPrefix = pamProduct?.crmgp_partnoprefix || "";
    const productDescription = pamProduct?.crmgp_productdescription || "";

    let partNo = partNoPrefix;
    let partDescription = productDescription;

    // --- Step 1: Process base attributes ---
    for (const baseAttr of baseattributes) {
        const fieldName = baseAttr.cmrfieldname;
        const value = baseattributeValues[fieldName];

        if (!value) continue;

        const selectedOption = (baseAttr.options || []).find(opt => opt.attributevalue === value);
        if (!selectedOption) continue;

        if (Number(selectedOption.partnostartfrom) > 0) {
            partNo = addPartString(
                partNo,
                Number(selectedOption.partnostartfrom),
                Number(selectedOption.partnolength),
                isMetric ? selectedOption.rulemetric : selectedOption.rulename
            );
        }

        if (Number(selectedOption.startlocation) > 0) {
            partDescription = addPartString(
                partDescription,
                Number(selectedOption.startlocation),
                Number(selectedOption.rulelength),
                isMetric ? selectedOption.attributevaluemetric : selectedOption.attributevalue
            );
        }
    }

    // --- Step 2: Process dynamic attributes ---
    for (const attr of attributes) {
        const fieldName = attr.crmfieldname;
        const value = attributeValues[fieldName];

        if (!value) continue;

        const doNotUpdatePart = attr?.donotupdatepartnoincrm;
        const startFromNo = attr.partnostartfrom;
        const ruleStartFrom = attr.rulestartfrom;

        const selectedOption = attr.options?.find(opt => opt.ruledescription === value);

        if (!doNotUpdatePart) {
            const attcontrolType = ATTRIBUTE_CONTROL_TYPE[attr.controlType];
            if (attcontrolType === "PickList" && selectedOption) {
                if (Number(startFromNo) > 0) {

                    const attoptionvalue = isMetric ? (selectedOption.rulenamemetric ?? "") : (selectedOption.name ?? "");

                    partNo = addPartString(
                        partNo,
                        Number(startFromNo),
                        Number(attr.partnolength),
                        attoptionvalue
                    );
                }

                if (Number(ruleStartFrom) > 0) {
                    const attoptiText = isMetric ? (selectedOption.ruledescription ?? "") : (selectedOption.ruledescriptionmetric ?? "");
                    partDescription = addPartString(
                        partDescription,
                        Number(ruleStartFrom),
                        Number(attr.rulelength),
                        attoptiText
                    );
                }
            }
            else {
                if (Number(startFromNo) > 0) {
                    partNo = addPartString(partNo, Number(startFromNo), Number(attr.partnolength), value);
                }
                if (Number(ruleStartFrom) > 0) {
                    partDescription = addPartString(partDescription, Number(ruleStartFrom), Number(attr.rulelength), value);
                }
            }
        }
    }

    return { partNo, partDescription };
}

export function addPartString(pCurrentString: string, pStartFrom: number, pLength: number, pValue: string): string {

    if (pStartFrom === 0 || pLength === 0)
        return pCurrentString;

    try {

        if (pValue.length > pLength) {
            pValue = pValue.substring(0, pLength);
        }
        else if (pValue.length < pLength) {
            pValue = pValue.padEnd(pLength, ' ');
        }

        if (pCurrentString.length < pStartFrom + pLength) {
            pCurrentString = pCurrentString.padEnd(pStartFrom + pLength - 1, ' ');
        }

        pCurrentString = pCurrentString.substring(0, pStartFrom - 1) + pValue + pCurrentString.substring(pStartFrom + pLength - 1);
    }
    catch (e) {
        return "Error!";
    }
    return pCurrentString;
}


export async function searchProductByPartNumber(formContext: any, partNumber: string, businessUnitId: string): Promise<any | null> {
    try {
        if (!partNumber || !businessUnitId) {
            console.warn("Part number or business unit ID is missing");
            return null;
        }

        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        const result = await Xrm.WebApi.retrieveMultipleRecords("product", `?$select=productid,_new_family_value,name,productnumber,_new_productsubtype_value,_new_producttype_value&$filter=(startswith(productnumber,'${partNumber}') and _new_owningbusinessunit_value eq ${businessUnitId})&$orderby=productnumber asc`);

        // const result = await fetchAllDistinctFetchXmlRecords(formContext, "product",
        //     ["productnumber", "productid", "new_family", "name", "productnumber", "new_productsubtype", "new_producttype"],
        //     [
        //         { attribute: "productnumber", operator: "like", value: partNumber + "%" },
        //         { attribute: "new_owningbusinessunit", operator: "eq", value: businessUnitId ?? "" }
        //     ],
        //     ["productnumber"]
        // );


        return result?.entities;
    } catch (error) {
        console.error("Error fetching product by part number:", error);
        throw error;
    }
}


export async function getPamProductbyMainOptions(formContext: any, productType: string, productSubType: string, productFamily: string): Promise<any[]> {
    try {
        const pamProduct = await fetchAllODataRecords(formContext,
            "crmgp_product",
            ["crmgp_productid", "crmgp_producttype"],
            `(crmgp_isactive eq true and _crmgp_producttypeid_value eq  ${productType} and _crmgp_productsubtypeid_value eq ${productSubType} and _crmgp_productfamilyid_value eq ${productFamily})&$top=1`,
            '');
        return pamProduct;
    } catch (error) {
        console.error("Error getting Business Unit:", error);
        return [];
    }
}

export async function searchProduct(formContext: any, businessUnitId: string, partNo: string, productDesc: string, altProductDesc: string): Promise<any[]> {
    try {

        const filters: string[] = [];

        if (partNo) {
            filters.push(`startswith(productnumber,'${partNo}')`);
        }

        if (productDesc) {
            filters.push(`contains(name,'${productDesc}')`);
        }

        if (altProductDesc) {
            filters.push(`contains(new_altproductdescription,'${altProductDesc}')`);
        }

        filters.push(`_new_owningbusinessunit_value eq ${businessUnitId}`);
        filters.push(" statecode eq  0 ");
        const filterString = filters.length > 0 ? `${filters.join(" and ")}` : "";

        const crmProduct = await fetchAllODataRecords(formContext,
            "product",
            ["name", "new_altproductdescription", "description", "new_productcode", "productnumber"],
            `${filterString}`,
            'productnumber');

        const data = crmProduct.map((item: any) => ({
            productid: item.productid,
            productnumber: item.productnumber,
            description: item.description,
            name: item.name,
            new_altproductdescription: item.new_altproductdescription,
            new_productcode: item.new_productcode
        }));

        return data;

    } catch (error) {
        console.error("Error getting Search Product:", error);
        return [];
    }
}