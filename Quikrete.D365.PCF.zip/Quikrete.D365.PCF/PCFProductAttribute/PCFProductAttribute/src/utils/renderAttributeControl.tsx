/* eslint-disable @typescript-eslint/no-explicit-any */

import * as React from "react";
import { ATTRIBUTE_CONTROL_TYPE, DynamicAttribute } from "../types/commonType"; // adjust import path
import { Input, Checkbox, Textarea, Dropdown, Option } from "@fluentui/react-components";


interface Props {
    attr: DynamicAttribute;
    selectedvalue?: string;
    selectedOptions?: string[];
    isRequired?: boolean;
    OnChanage?: (crmFieldName: string, value: any) => void;
};

export const renderAttributeControl = ({ attr, selectedvalue, selectedOptions, isRequired, OnChanage }: Props) => {
    const controlType = ATTRIBUTE_CONTROL_TYPE[attr.controlType];
    switch (controlType) {
        case "String":
            return (
                <Input
                    className="textControl"
                    type="text"
                    value={selectedvalue || ""}
                    data-requiredfield={isRequired}
                    data-defaultvalue={attr.defaultvalue}
                    data-startindex={attr.startindex}
                    data-partnostartfrom={attr.partnostartfrom}
                    data-partnolength={attr.partnolength}
                    data-partnolengthmetric={attr.partnolengthmetric}
                    data-rulestartfrom={attr.rulestartfrom}
                    data-rulestartfrommetric={attr.rulestartfrommetric}
                    data-rulelength={attr.rulelength}
                    data-rulelengthmetric={attr.rulelengthmetric}
                    data-defaultvaluemetric={attr.defaultvaluemetric}
                    data-donotupdatepartnoincrm={attr.donotupdatepartnoincrm}
                    onChange={(e) => OnChanage?.(attr.crmfieldname, e.target.value)}
                />
            );

        case "Multiline":
        case "Multiline String":
            return (

                <Textarea
                    className="textControl"
                    disabled={attr.crmfieldname == "new_pa_pass_attribute_to_jde" ? true : false}
                    data-requiredfield={isRequired}
                    data-defaultvalue={attr.defaultvalue}
                    data-startindex={attr.startindex}
                    data-partnostartfrom={attr.partnostartfrom}
                    data-partnolengthmetric={attr.partnolengthmetric}
                    data-partnolength={attr.partnolength}
                    data-rulestartfrom={attr.rulestartfrom}
                    data-rulestartfrommetric={attr.rulestartfrommetric}
                    data-rulelength={attr.rulelength}
                    data-rulelengthmetric={attr.rulelengthmetric}
                    data-defaultvaluemetric={attr.defaultvaluemetric}
                    data-donotupdatepartnoincrm={attr.donotupdatepartnoincrm}
                    value={selectedvalue || ""}
                    onChange={(e) => OnChanage?.(attr.crmfieldname, e.target.value)}
                />
            );

        case "Number":
            return (
                <Input
                    className="textControl"
                    type="number"
                    value={selectedvalue || ""}
                    data-requiredfield={isRequired}
                    data-partnostartfrom={attr.partnostartfrom}
                    data-defaultvalue={attr.defaultvalue}
                    data-startindex={attr.startindex}
                    data-partnolengthmetric={attr.partnolengthmetric}
                    data-partnolength={attr.partnolength}
                    data-rulestartfrom={attr.rulestartfrom}
                    data-rulestartfrommetric={attr.rulestartfrommetric}
                    data-rulelength={attr.rulelength}
                    data-rulelengthmetric={attr.rulelengthmetric}
                    data-defaultvaluemetric={attr.defaultvaluemetric}
                    data-donotupdatepartnoincrm={attr.donotupdatepartnoincrm}
                    onChange={(e) => OnChanage?.(attr.crmfieldname, e.target.value)}
                />

            );

        case "PickList":
            {
                // const currentValue = attributeValues[attr.crmFieldName] ?? "";
                return (
                    <Dropdown
                        className="dropdownControl"
                        selectedOptions={selectedOptions ?? [selectedvalue ?? ""]}
                        value={selectedvalue ?? ""}
                        data-requiredfield={isRequired}
                        data-defaultvalue={attr.defaultvalue}
                        data-startindex={attr.startindex}
                        data-partnostartfrom={attr.partnostartfrom}
                        data-partnolengthmetric={attr.partnolengthmetric}
                        data-partnolength={attr.partnolength}
                        data-rulestartfrom={attr.rulestartfrom}
                        data-rulestartfrommetric={attr.rulestartfrommetric}
                        data-rulelength={attr.rulelength}
                        data-rulelengthmetric={attr.rulelengthmetric}
                        data-defaultvaluemetric={attr.defaultvaluemetric}
                        data-donotupdatepartnoincrm={attr.donotupdatepartnoincrm}

                        onOptionSelect={(_, data) => {
                            const selected = data.optionValue as string;
                            OnChanage?.(attr.crmfieldname, selected);
                        }}

                    >
                        <Option value="">---Select---</Option>
                        {attr.options.map((opt) => (
                            <Option key={opt.ruledescription} value={opt.ruledescription}
                                data-ruledescription={opt.ruledescription}
                                data-rulesequence={opt.rulesequence}
                                data-rulestartfrom={opt.rulestartfrom}
                                data-rulelength={opt.rulelength}
                                data-isactive={opt.isactive}
                                data-rulenamemetric={opt.rulenamemetric}
                                data-ruledescriptionmetric={opt.ruledescriptionmetric}
                                data-rulestartfrommetric={opt.rulestartfrommetric}
                                data-rulelengthmetric={opt.rulelengthmetric}
                                disabled={!opt.isactive}
                            >
                                {opt.ruledescription}
                            </Option>
                        ))}
                    </Dropdown>
                );
            }
        case "CheckBox":
            return (
                <Checkbox
                    data-requiredfield={isRequired}
                    label={attr.name}
                    checked={selectedvalue === "true" || selectedvalue === "1"}
                    data-defaultvalue={attr.defaultvalue}
                    data-startindex={attr.startindex}
                    data-partnostartfrom={attr.partnostartfrom}
                    data-partnolength={attr.partnolength}
                    data-partnolengthmetric={attr.partnolengthmetric}
                    data-rulestartfrom={attr.rulestartfrom}
                    data-rulestartfrommetric={attr.rulestartfrommetric}
                    data-rulelength={attr.rulelength}
                    data-rulelengthmetric={attr.rulelengthmetric}
                    data-defaultvaluemetric={attr.defaultvaluemetric}
                    data-donotupdatepartnoincrm={attr.donotupdatepartnoincrm}
                    onChange={(e, data) => OnChanage?.(attr.crmfieldname, data.checked ? "true" : "false")}
                />
            );

        case "Multi Select Checkbox": {
            const allOptions = attr.options;
            const selectedValues = selectedvalue ? selectedvalue.split(",") : [];
            return (
                <Dropdown
                    className="dropdownControl"
                    multiselect
                    placeholder={
                        selectedValues.length > 0
                            ? selectedValues.join(", ")
                            : "---"
                    }
                    data-partnostartfrom={attr.partnostartfrom}
                    data-defaultvalue={attr.defaultvalue}
                    data-startindex={attr.startindex}
                    data-partnolength={attr.partnolength}
                    data-partnolengthmetric={attr.partnolengthmetric}
                    data-rulestartfrom={attr.rulestartfrom}
                    data-rulestartfrommetric={attr.rulestartfrommetric}
                    data-rulelength={attr.rulelength}
                    data-rulelengthmetric={attr.rulelengthmetric}
                    data-defaultvaluemetric={attr.defaultvaluemetric}
                    selectedOptions={selectedValues}
                    data-requiredfield={isRequired}
                    data-donotupdatepartnoincrm={attr.donotupdatepartnoincrm}
                    onOptionSelect={(_, data) => {
                        if (typeof data.optionValue === "string") {
                            let updated: string[];

                            if (data.optionValue === "__ALL__") {

                                const isAllSelected = allOptions.every((opt) =>
                                    selectedValues.includes(opt.ruledescription)
                                );
                                updated = isAllSelected
                                    ? []
                                    : allOptions.map(opt => opt.ruledescription);

                            } else {
                                const val = data.optionValue;
                                updated = selectedValues.includes(val)
                                    ? selectedValues.filter((v) => v !== val)
                                    : [...selectedValues, val];

                            }
                            OnChanage?.(attr.crmfieldname, updated.join(","));
                        }
                    }}
                >
                    {/* Select All Option */}
                    <Option key="__ALL__" value="__ALL__">
                        Select All
                    </Option>

                    {/* Real options */}
                    {allOptions.map((opt) => (
                        <Option key={`${attr.crmfieldname}_${opt.ruledescription}`} value={opt.ruledescription}>
                            {opt.ruledescription}
                        </Option>
                    ))}
                </Dropdown>
            );

        }

        default:
            return <span>Unsupported Control</span>;
    }
};
