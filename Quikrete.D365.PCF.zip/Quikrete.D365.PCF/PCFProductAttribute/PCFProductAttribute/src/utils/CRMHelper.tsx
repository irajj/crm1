/* eslint-disable no-debugger */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
    ATTRIBUTE_CONTROL_TYPE,
    DynamicAttribute,
    DynamicAttributeBaseAttribute,
    PAM_PRODUCT_TYPE
} from "../types/commonType"; // adjust import path


export async function MarkFormDirty(
    formContext: any,
    attributeDefaultValues: Record<string, any>,
    attrName: string,
    value: any
) {

    try {
        if (!formContext) return;

        // Initialize global tracker if not exists
        if (!(top as any).__fieldChangeTracker) {
            (top as any).__fieldChangeTracker = {};
        }
        const tracker = (top as any).__fieldChangeTracker;

        // --- Normalization helper for consistent comparison ---
        const normalize = (val: any): string => {
            if (Array.isArray(val)) {
                return JSON.stringify(val.map(v => v?.id || v?.name || v));
            }
            if (typeof val === "object" && val !== null) {
                return JSON.stringify(val);
            }
            if (val === undefined || val === null) return "";
            return String(val).trim().toLowerCase();
        };

        const normalizedNewValue = normalize(value);

        // --- Step 1: Capture default/original value only once ---
        if (!tracker[attrName]) {
            tracker[attrName] = {
                defaultValue: normalize(attributeDefaultValues[attrName]),
                currentValue: normalizedNewValue,
                isDirty: false
            };
        }

        const defaultVal = tracker[attrName].defaultValue;

        // --- Step 2: Update current value ---
        tracker[attrName].currentValue = normalizedNewValue;

        // --- Step 3: Compare with default ---
        tracker[attrName].isDirty = normalizedNewValue !== defaultVal;

        // --- Step 4: Determine overall form dirty state ---
        const isAnyDirty = Object.values(tracker).some(
            (t: any) => t.isDirty === true
        );

        const tokenAttr = formContext.getAttribute("new_makeformdirtytoken");
        if (!tokenAttr) {
            console.warn("Field 'new_makeformdirtytoken' not found on form.");
            return;
        }

        if (isAnyDirty) {
            // Form is unsaved → assign a new unique token
            const token = `${Date.now()}_${Math.floor(Math.random() * 10000)}`;
            // tokenAttr.setValue(token);

            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            window.parent.Xrm.Page.getAttribute("new_makeformdirtytoken").setValue(token);
            tokenAttr.fireOnChange();
            (top as any).__formHasUnsavedChanges = true;
            console.log(`Form unsaved (changed field: ${attrName})`);
        } else {
            // All fields back to defaults → clear token
            tokenAttr.setValue(null);
            tokenAttr.fireOnChange();
            (top as any).__formHasUnsavedChanges = false;
            console.log("Form back to saved (all fields restored)");
        }

        console.table(tracker);
    } catch (error) {
        console.error("Failed in MarkFormDirty:", error);
    }
}


export async function MarkFormDirtyMain(formContext: any, attrbiuteDefaultValue: Record<string, any>, attrName: string, value: string) {
    try {

        if (!formContext) return;

        // Use the new token field instead of boolean
        const attr = formContext.getAttribute("new_makeformdirtytoken");
        if (!attr) {
            console.warn("Field 'new_makeformdirtytoken' not found on form.");
            return;
        }

        // Generate a unique token (timestamp + random string)
        const newToken = `${Date.now()}_${Math.floor(Math.random() * 10000)}`;

        // Set the new token value
        attr.setValue(newToken);
        attr.fireOnChange();

        console.log(`✅ Form marked dirty with token: ${newToken}`);
    } catch (error) {
        console.error("❌ Failed to mark form dirty:", error);
    }
}


export async function MarkFormDirtyForRefresh(formContext: any) {
    try {
        if (formContext) {
            const attr = formContext.getAttribute("new_makeformdirty");
            const isdirty = attr.getIsDirty();
            if (attr && !isdirty) {
                const originalValue = attr.getValue();
                // If already true, toggle to false and back to true
                if (originalValue === true) {
                    formContext.setFieldValue("new_makeformdirty", false);

                } else {
                    formContext.setFieldValue("new_makeformdirty", true);
                }
            }
            else {
                // find Form Dirty or not if true the 
                const formDirty = formContext.data.entity.getIsDirty();
                if (formDirty) {
                    const originalValue = attr.getValue();
                    // If already true, toggle to false and back to true
                    if (originalValue === true) {
                        formContext.setFieldValue("new_makeformdirty", false);
                    } else {
                        formContext.setFieldValue("new_makeformdirty", true);
                    }
                }
            }
        }
    } catch (error) {
        console.warn("Failed to toggle dirty field:", error);
    }
}


export function extractValueFromPartNo(
    partNo: string,
    attr: DynamicAttribute,
    isMetric: boolean
): string | undefined {
    if (attr.donotupdatepartnoincrm) return;

    const start = Number(attr.partnostartfrom);
    const length = Number(attr.partnolength);

    if (start > 0 && length > 0) {
        const segment = partNo.substring(start - 1, start - 1 + length).trim();
        const controlType = ATTRIBUTE_CONTROL_TYPE[attr.controlType]
        if (controlType === "PickList") {
            const matched = attr.options?.find(opt =>
                (isMetric ? opt.rulenamemetric ?? "" : opt.name ?? "") === segment
            );
            return matched?.ruledescription;
        } else {
            return segment;
        }
    }

    return;
}

export function extractBaseAttributeValueFromPartNo(
    partNo: string,
    baseAttr: DynamicAttributeBaseAttribute,
    isMetric: boolean
): string | undefined {
    if (!baseAttr.options || baseAttr.options.length === 0) return;

    const option = baseAttr.options[0]; // Assuming start and length are same for all options
    const start = Number(option.partnostartfrom);
    const length = Number(option.partnolength);

    if (start > 0 && length > 0) {
        const segment = partNo.substring(start - 1, start - 1 + length).trim();

        const matched = baseAttr.options.find(opt =>
            (isMetric ? opt.rulemetric : opt.rulename) === segment
        );
        return matched?.attributevalue;
    }
    return;
}

// Helper function to get Product Type and Subtype from Product by Family
export async function getTypeSubTypeFromFamily(
    formContext: any,
    familyId: string
) {
    try {
        const fetchResult = await formContext.retrieveMultipleRecords(
            "crmgp_product",
            `?$select=_crmgp_productsubtypeid_value,_crmgp_producttypeid_value&$filter=(_crmgp_productfamilyid_value eq ${familyId} and _crmgp_producttypeid_value ne null and _crmgp_productsubtypeid_value ne null)&$top=1`
        );

        return fetchResult?.[0] || null;
    } catch (error) {
        console.error("Error fetching type/subtype from product:", error);
        return null;
    }
}

export async function getProductTypeFromSubType(
    formContext: any,
    subTypeId: string
) {
    try {
        const fetchResult = await formContext.retrieveRecord("crmgp_productsubtype", subTypeId, "?$select=_crmgp_producttypeid_value");

        return fetchResult || null;
    } catch (error) {
        console.error("Error fetching subtype from type:", error);
        return null;
    }
}


export async function getTypeFromSubType(
    formContext: any,
    subTypeID: string
) {
    try {
        const fetchResult = await formContext.retrieveRecord("crmgp_productsubtype", subTypeID, `?$select=_crmgp_producttypeid_value`);

        return fetchResult || null;
    } catch (error) {
        console.error("Error fetching type/subtype from product:", error);
        return null;
    }
}

function isNumeric(value: string): boolean {
    return value !== null && value !== undefined && value !== "" && !isNaN(Number(value));
}

function shouldSortNumeric(options: any[]): boolean {
    return options.every(o => isNumeric(o.key));
}

export function sortOptions(options: any[]): any[] {
    if (shouldSortNumeric(options)) {
        // Numeric sort
        return options.sort((a, b) => Number(a.key) - Number(b.key));
    } else {
        // Alphanumeric sort (handles A1, A10, A2 properly)
        return options.sort((a, b) =>
            a.text.localeCompare(b.text, undefined, {
                numeric: true,
                sensitivity: "base"
            })
        );
    }
}

export function validateAttributes(
    productType: string,
    formContext: any,
    attributes: DynamicAttribute[],
    attributeValues: Record<string, string>,
    partNumber: string | undefined = undefined
): boolean {

    const missingFields: string[] = [];

    // Step 1: If Product Type is "StandardProduct"
    if (PAM_PRODUCT_TYPE[productType] === "StandardProduct") {
        if (!partNumber && partNumber?.trim() === "") {
            formContext.openAlertDialog(
                "Standard Product",
                "You have selected a Standard Product. Please directly type-in PartNo to select product"
            );
            return false;
        }
        return true;
    }

    // Step 3: Validate required dynamic attributes
    attributes.forEach(attr => {
        const field = attr.crmfieldname;
        const value = attributeValues[field];
        const fieldLable = attr.name;

        const isRequired =
            formContext.getCurrentEntityName() === "opportunityproduct"
                ? attr.crmgp_requiredproject
                : formContext.getCurrentEntityName() === "quotedetail"
                    ? attr.crmgp_requiredquote
                    : attr.crmgp_requiredorder;

        if (isRequired && (!value || value.trim() === "" || value === "---")) {
            missingFields.push(`• ${attr.name}`);
        }

        if (field === "new_pa_application" || fieldLable.toLowerCase() === "application") {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            window.parent.Xrm.Page.getAttribute("new_applicationcode").setValue(value);
        }
    });

    //Length Multiplier fields
    const lengthMultiplierField = attributes.find(attr => attr.crmgp_lengthmultiplier);
    if (lengthMultiplierField) {
        const value = attributeValues[lengthMultiplierField.crmfieldname];
        const lengthMultiplierValue = parseFloat(value);

        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        const pcs = window.parent.Xrm.Page.getAttribute("new_pcs").getValue();
        const pcsPerQty = parseFloat(pcs);
        if (!isNaN(lengthMultiplierValue) && !isNaN(pcsPerQty)) {
            const qty = lengthMultiplierValue * pcsPerQty;
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            window.parent.Xrm.Page.getAttribute("quantity").setValue(qty);
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-expect-error
            window.parent.Xrm.Page.getAttribute("new_lengthmultiplier").setValue(lengthMultiplierValue);
        }
    }
    else {
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        window.parent.Xrm.Page.getAttribute("new_lengthmultiplier").setValue(1);
        // formContext.setFieldValue("new_lengthmultiplier", 1);
    }

    // Step 4: Show validation dialog
    if (missingFields.length > 0) {
        formContext.openAlertDialog(
            "Missing Required Fields",
            "Please fill the following required fields:\n\n" + missingFields.join("\n")
        );
        return false;
    }
    return true;
}


export function updatePassAttributetoJDE(
    formContext: any,
    baseAttributes: DynamicAttributeBaseAttribute[],
    baseAttributeValues: Record<string, string>,
    attributes: DynamicAttribute[],
    attributeValues: Record<string, string>,
    crmFieldName: string
): string {

    const jdeString: string[] = [];

    const attribute = attributes.find(a => a.crmfieldname === crmFieldName);
    if (!attribute) return "";


    /* ================= BASE ATTRIBUTES (FIRST PRIORITY) ================= */
    baseAttributes.forEach(baseAttr => {

        const selectedValue = baseAttributeValues[baseAttr.cmrfieldname];

        if (!selectedValue) return;

        const option = baseAttr.options?.find(o =>
            o.attributevalue === selectedValue &&
            o.foxprofieldmapindex != null &&
            o.foxprofieldmapindex > 0
        );

        if (!option) return;

        // Safe to use
        const index = option.foxprofieldmapindex - 1; // 1-based → 0-based
        jdeString[index] = baseAttr.attributename + ":" + selectedValue;
    });

    /* ================= NORMAL ATTRIBUTES ================= */

    attributes?.forEach(attr => {

        const selectedValue = attributeValues?.[attr.crmfieldname];
        if (!selectedValue) return;

        if (!attr.foxprofieldmapindex || attr.foxprofieldmapindex <= 0) return;

        // Safe to use
        const index = attr.foxprofieldmapindex - 1; // 1-based → 0-based
        jdeString[index] = attr.name + ":" + selectedValue;
    });

    // Filter out undefined, null, and empty strings, then join with ";"
    let jdeValue = jdeString.filter(Boolean).join(";").trim();

    // Add trailing ";" if there's any data
    if (jdeValue.length > 0 && !jdeValue.endsWith(";")) {
        jdeValue += ";";
    }

    return jdeValue
}