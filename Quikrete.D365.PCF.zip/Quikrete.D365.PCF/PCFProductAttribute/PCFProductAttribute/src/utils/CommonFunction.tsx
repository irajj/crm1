/* eslint-disable no-debugger*/
/* eslint-disable @typescript-eslint/no-explicit-any */
import { DynamicAttributeBaseAttribute } from "../types/commonType";
import { ProductBaseAttributes } from "../types/commonType";
import { DynamicAttribute } from "../types/commonType";

export const CommonFunction = {

    async getBusinessUnit(formContext: any): Promise<string> {
        try {
            const userId = formContext.getCurrentUserId();
            const businessUnitId = await formContext.getBusinessUnit(userId);
            return businessUnitId;
        } catch (error) {
            console.error("Error getting Business Unit:", error);
            return "";
        }
    },

    async getPamProductConfigDetails(formContext: any, pamProductId: string): Promise<Record<string, string>> {
        const cleanData: Record<string, string> = {};
        const fetchXml = `
            <fetch>
                <entity name='crmgp_product'>
                    <all-attributes />
                    <order attribute='crmgp_name' descending='false' />
                    <filter type='and'>
                        <condition attribute='crmgp_productid' operator='eq' value='${pamProductId}' />
                    </filter>
                </entity>
            </fetch>
        `;

        try {
            const response = await formContext.retrieveMultipleRecords("crmgp_product", `?fetchXml=${encodeURIComponent(fetchXml)}`);
            const record = response?.[0];
            if (record) {
                Object.keys(record).forEach((key) => {
                    if (!key.includes("@") && key !== "crmgp_productid") {
                        const value = record[key];
                        if (key && value !== undefined) {
                            cleanData[key] = value;
                        }
                    }
                });
            }
        } catch (error) {
            console.error("Error loading PAM values:", error);
        }
        return cleanData;
    },

    async getProductAttributes(formContext: any, productAttributeId: string): Promise<Record<string, string>> {
        const cleanData: Record<string, string> = {};

        try {
            const fetchXml = `
        <fetch>
            <entity name='new_productattributes'>
                <all-attributes />
                <filter type='and'>
                    <condition attribute='new_productattributesid' operator='eq' value='${productAttributeId}' />
                </filter>
            </entity>
        </fetch>
    `;
            const response = await formContext.retrieveMultipleRecords(
                "new_productattributes",
                `?fetchXml=${encodeURIComponent(fetchXml)}`
            );

            const record = response?.[0];

            if (record) {

                Object.keys(record).forEach((key) => {
                    if (!key.includes("@") && key !== "new_productattributesid") {
                        const value = record[key];
                        if (key && value !== undefined) {
                            cleanData[key] = value;
                        }
                    }
                });
            }
        } catch (error) {
            console.error("Error fetching products:", error);
        }
        return cleanData;
    },

    async getProductsTypes(formContext: any, businessUnitId: string): Promise<{ key: string; text: string }[]> {
        let options: { key: string; text: string }[] = [];

        try {
            const fetchXml = `
                <fetch distinct="true">
                  <entity name="product">
                    <attribute name="new_producttype" />
                    <filter type="and">
                      <condition attribute="statecode" operator="eq" value="0" />
                      <condition attribute="new_owningbusinessunit" operator="eq" value="${businessUnitId}" />
                      <condition attribute="new_producttype" operator="not-null" />
                    </filter>
                    <order attribute="new_producttype" />
                  </entity>
                </fetch>
            `;

            const encodedFetchXml = encodeURIComponent(fetchXml);
            const result = await formContext.retrieveMultipleRecords("product", `?fetchXml=${encodedFetchXml}`);

            options = result.map((e: any) => ({
                key: e._new_producttype_value,
                text: e["_new_producttype_value@OData.Community.Display.V1.FormattedValue"]
            }));


            // const uniqueProductTypesMap = new Map<string, string>();

            // result.forEach((entity: any) => {
            //     const id = entity._new_producttype_value;
            //     const name = entity["_new_producttype_value@OData.Community.Display.V1.FormattedValue"];
            //     if (id && name && !uniqueProductTypesMap.has(id)) {
            //         uniqueProductTypesMap.set(id, name);
            //     }
            // });
            // options = Array.from(uniqueProductTypesMap.entries()).map(([id, name]) => ({
            //     key: id,
            //     text: name
            // }));
        } catch (error) {
            console.error("Error fetching products:", error);

        }
        return options;
    },

    async getProductSubTypes(formContext: any, productType: string): Promise<{ key: string; text: string }[]> {
        let options: { key: string; text: string }[] = [];

        try {
            const fetchXml = `
<fetch distinct="true">
  <entity name="crmgp_productsubtype">
    <attribute name="crmgp_productsubtypeid" />
    <attribute name="crmgp_name" />
    <order attribute="crmgp_name" />
    <filter type="and">
      <condition attribute="statecode" operator="eq" value="0" />
      <condition attribute="crmgp_producttypeid" operator="eq" value="${productType}" />
    </filter>
  </entity>
</fetch>
`;





            const encodedFetchXml = encodeURIComponent(fetchXml);
            const result = await formContext.retrieveMultipleRecords("crmgp_productsubtype", `?fetchXml=${encodedFetchXml}`);
            options = result.map((e: any) => ({
                key: e.crmgp_productsubtypeid,
                text: e.crmgp_name
            }));


        } catch (error) {
            console.error("Error fetching products:", error);

        }
        return options;
    },

    async getProductFamilies(formContext: any, businessUnitId: string, productType: string, productSubType: string): Promise<{ key: string; text: string }[]> {
        let options: { key: string; text: string }[] = [];

        try {


            const fetchXml = `
<fetch distinct="true">
  <entity name="product">
    <attribute name="new_family" />
    <filter type="and">
      <condition attribute="new_owningbusinessunit" operator="eq" value="${businessUnitId}" />
      	<condition attribute="new_producttype" operator="eq" value="${productType}" />
			<condition attribute="new_productsubtype" operator="eq" value="${productSubType}" />
      <condition attribute="statecode" operator="eq" value="0" />
      <condition attribute="new_family" operator="not-null" />
    </filter>
    <order attribute="new_family" />
  </entity>
</fetch>
`;
            const encodedFetchXml = encodeURIComponent(fetchXml);
            const result = await formContext.retrieveMultipleRecords("product", `?fetchXml=${encodedFetchXml}`);
            options = result.map((e: any) => ({
                key: e._new_family_value,
                text: e["_new_family_value@OData.Community.Display.V1.FormattedValue"]
            }));
        } catch (error) {
            console.error("Error fetching products:", error);

        }
        return options;
    },

    async getBaseAttributeControl(formContext: any, productType: string, productSubType: string, productFamily: string): Promise<{
        getBaseAttributeContols: DynamicAttributeBaseAttribute[],
        transformedData: ProductBaseAttributes[]
    }> {
        
        let baseattributes: DynamicAttributeBaseAttribute[] = [];
        const baseAttributeMap = new Map<string, DynamicAttributeBaseAttribute>();
        const transformed: { [productId: string]: any } = {};

        try {

            const fetchXml = `
<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">
  <entity name="crmgp_baseproductattribute">
    <all-attributes />
    <order attribute="crmgp_attributesequence" descending="false" />
    <filter type="and">
      <condition attribute="statecode" operator="eq" value="0" />
    </filter>
    <link-entity name="crmgp_product" from="crmgp_productid" to="crmgp_productid" alias="product">
      <filter type="and">
        <condition attribute="crmgp_productfamilyid" operator="eq" value="${productFamily}" />
        <condition attribute="crmgp_producttypeid" operator="eq" value="${productType}" />
        <condition attribute="crmgp_productsubtypeid" operator="eq" value="${productSubType}" />
      </filter>
    </link-entity>
  </entity>
            </fetch>`;

            const encodedFetchXml = encodeURIComponent(fetchXml);

            const result = await formContext.retrieveMultipleRecords(
                "crmgp_baseproductattribute",
                `?fetchXml=${encodedFetchXml}`
            );

            result.forEach((item: any) => {
                const crmFieldName = item.crmgp_crmfieldname;
                const attributeName = item.crmgp_attributename;
                const option = {
                    key: item.crmgp_attributevalue,
                    text: item.crmgp_attributevalue,
                    pamproductid: item._crmgp_productid_value,
                    crmFieldName: item.crmgp_crmfieldname,
                    attributeName: item.crmgp_attributename,
                    attributeId: item.crmgp_baseproductattributeid,
                    attributevalue: item.crmgp_attributevalue,
                    attributevaluemetric: item.crmgp_attributevaluemetric,
                    startindex: item.crmgp_startindex,
                    partnostartfrom: item.crmgp_partnostartfrom,
                    partnolength: item.crmgp_partnolength,
                    partnolengthmetric: item.crmgp_partnolengthmetric,
                    startlocation: item.crmgp_rulestartfrom,
                    startlocationmetric: item.crmgp_rulestartfrommetric,
                    rulename: item.crmgp_rulename,
                    rulemetric: item.crmgp_rulenamemetric,
                    rulelength: item.crmgp_rulelength,
                    rulelengthmetric: item.crmgp_rulelengthmetric,
                };

                if (!baseAttributeMap.has(crmFieldName)) {
                    // First time seeing this crmfieldname
                    baseAttributeMap.set(crmFieldName, {
                        attributename: attributeName,
                        cmrfieldname: crmFieldName,
                        options: [option],
                    });
                } else {
                    // Already exists – append to options
                    const existing = baseAttributeMap.get(crmFieldName)!;
                    // Prevent duplicate option entries by value
                    if (!existing.options.some(o => o.key === option.key)) {
                        existing.options.push(option);
                    }
                }
            });

            result.forEach((item: { _crmgp_productid_value: any; crmgp_attributename: any; crmgp_attributevalue: any; crmgp_crmfieldname: any; }) => {
                const productId = item._crmgp_productid_value;
                const attributeName = item.crmgp_attributename;
                const attributeValue = item.crmgp_attributevalue;
                const crmfieldname = item.crmgp_crmfieldname

                if (!transformed[productId]) {
                    transformed[productId] = { productId };
                }

                if (crmfieldname) {
                    transformed[productId][crmfieldname] = attributeValue;
                }
            });
            // setTransformedData(Object.values(transformed));

            baseattributes = Array.from(baseAttributeMap.values());
        } catch (error) {
            console.error("Error fetching products:", error);

        }

        return {
            getBaseAttributeContols: Array.from(baseAttributeMap.values()),
            transformedData: Object.values(transformed)
        };
    },

    async getPamProductbyMainOptions(formContext: any, productType: string, productSubType: string, productFamily: string): Promise<[]> {
        try {
            const pamProduct = await formContext.retrieveMultipleRecords("crmgp_product", `?$select=crmgp_productid,crmgp_producttype&$filter=(_crmgp_producttypeid_value eq  ${productType} and _crmgp_productsubtypeid_value eq ${productSubType} and _crmgp_productfamilyid_value eq ${productFamily})&$top=1`);
            return pamProduct;
        } catch (error) {
            console.error("Error getting Business Unit:", error);
            return [];
        }
    },



    async getAllAttribute(formContext: any, selectedPamProductId: string): Promise<DynamicAttribute[]> {
        
        let attributesControls: DynamicAttribute[] = [];

        try {

            const fetchXml = `
                                <fetch>
                                <entity name='crmgp_productattribute'>
                                <all-attributes />
                                <order attribute="crmgp_attributesequence" descending="false" />
                                <filter type='and'>
                                   <condition attribute='statecode' operator='eq' value='0' />
                                   <condition attribute='crmgp_productid' operator='eq' value='${selectedPamProductId}' />
                                   </filter>
                                   <link-entity name='crmgp_productattributeoption' from='crmgp_productattributeid' to='crmgp_productattributeid' alias='attributeoption' link-type='outer'>
                                     <all-attributes />
                                     <order attribute="crmgp_rulesequence" descending="false" />
                                   </link-entity>
                                    <link-entity name='crmgp_product' from='crmgp_productid' to='crmgp_productid' alias='linkedproduct' link-type='inner'>
                                        <attribute name='crmgp_producttype' />
                                    </link-entity>
                                <order attribute='crmgp_attributesequence' />
                               </entity>
                               </fetch>`;


            const response = await formContext.retrieveMultipleRecords(
                "crmgp_productattribute",
                `?fetchXml=${encodeURIComponent(fetchXml)}`
            );

            // Group attributes by ID
            const grouped: Record<string, DynamicAttribute> = {};
            let productType = null;
            for (const entity of response) {
                const attrId = entity.crmgp_productattributeid;
                productType = entity['linkedproduct.crmgp_producttype'];
                if (!grouped[attrId]) {
                    grouped[attrId] = {
                        id: attrId,
                        name: entity.crmgp_name,
                        controlType: entity.crmgp_controltype,
                        crmFieldName: entity.crmgp_crmfieldname,
                        defaultValue: entity.crmgp_defaultvalue ?? "",
                        crmgp_requiredproject: entity.crmgp_requiredproject,
                        crmgp_requiredorder: entity.crmgp_requiredorder,
                        crmgp_requiredquote: entity.crmgp_requiredquote,
                        startindex: entity.crmgp_startindex,
                        partnostartfrom: entity.crmgp_partnostartfrom,
                        partnolength: entity.crmgp_partnolength,
                        partnolengthmetric: entity.crmgp_partnolengthmetric,
                        rulestartfrom: entity.crmgp_rulestartfrom,
                        rulestartfrommetric: entity.crmgp_rulestartfrommetric,
                        rulelength: entity.crmgp_rulelength,
                        rulelengthmetric: entity.crmgp_rulelengthmetric,
                        defaultvaluemetric: entity.crmgp_defaultvaluemetric,
                        crmgp_hidden: entity.crmgp_hidden,
                        donotupdatepartnoincrm: entity.crmgp_donotupdatepartnoincrm,
                        options: [],
                    };
                }
                if (entity["attributeoption.crmgp_ruledescription"]) {
                    grouped[attrId].options.push({
                        ruleDescription: entity["attributeoption.crmgp_ruledescription"],
                        ruleSequence: entity["attributeoption.crmgp_rulesequence"],
                        ruleStartFrom: entity["attributeoption.crmgp_rulestartfrom"],
                        ruleLength: entity["attributeoption.crmgp_rulelength"],
                        isActive: entity["attributeoption.crmgp_isactive"],
                        ruleNameMetric: entity["attributeoption.crmgp_rulenamemetric"],
                        ruleDescriptionMetric: entity["attributeoption.crmgp_ruledescriptionmetric"],
                        ruleStartFromMetric: entity["attributeoption.crmgp_rulestartfrommetric"],
                        ruleLengthMetric: entity["attributeoption.crmgp_rulelengthmetric"]
                    });
                }
            }
            attributesControls = Object.values(grouped);
        } catch (error) {
            console.error("Error fetching products:", error);
        }
        return attributesControls;
    },
}
