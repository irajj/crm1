/* eslint-disable no-debugger */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useState } from "react";

export function useBusinessUnit(formContext: any): string {
    debugger
    const [businessUnitId, setBusinessUnitId] = useState<string>("");

    useEffect(() => {
        const fetchBusinessUnit = async () => {
            try {
                const userId = formContext.getCurrentUserId();
                const buId = await formContext.getBusinessUnit(userId);
                setBusinessUnitId(buId);
            } catch (err) {
                console.error("Error loading Business Unit:", err);
            }
        };

        fetchBusinessUnit();
    }, [formContext]);

    return businessUnitId;
}
