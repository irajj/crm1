/* eslint-disable @typescript-eslint/no-explicit-any */
export const ATTRIBUTE_CONTROL_TYPE: any = {
    550470000: "String",
    550470001: "Multiline String",
    550470002: "Number",
    550470003: "PickList",
    550470004: "CheckBox",
    550470005: "Multi Select Checkbox"
};

export const PAM_PRODUCT_TYPE: any = {
    100000000: "AttributeDriven",
    100000001: "StandardProduct",
};

export interface RuleOption {
    name: string;
    ruledescription: string;
    rulesequence?: number;
    rulestartfrom?: number;
    rulelength?: number;
    isactive?: boolean;
    rulenamemetric?: string;
    ruledescriptionmetric?: string;
    rulestartfrommetric?: string;
    rulelengthmetric?: string;
}

export interface DynamicAttributeBaseAttribute {
    attributename: any;
    cmrfieldname: any;
    selectedBaseValue?: string;
    options: DynamicAttributeoptions[],
}

export interface DynamicAttributeoptions {
    key: string;
    text: string;
    pamproductid: any;
    attributeId: string;
    attributevalue: any;
    attributevaluemetric?: any;
    startindex: any;
    partnostartfrom: any;
    partnolength: any;
    partnolengthmetric: any;
    startlocation: any;
    startlocationmetric: any;
    rulename: any;
    rulemetric: any;
    rulelength: any;
    rulelengthmetric: any;
    attributeName: string;
    cmrfieldname: string;
    foxprofieldmapindex: number;
}

export interface DynamicAttribute {
    id: string;
    name: string;
    controlType: string;
    crmfieldname: string;
    defaultvalue: string;
    startindex: string;
    partnostartfrom: number;
    partnolength: string;
    partnolengthmetric: string;
    rulestartfrom: string;
    rulestartfrommetric: string;
    rulelength: string;
    rulelengthmetric: string;
    defaultvaluemetric: string;
    donotupdatepartnoincrm?: boolean;
    crmgp_requiredproject: boolean;
    crmgp_hidden: boolean;
    crmgp_requiredorder: boolean;
    crmgp_requiredquote: boolean;
    crmgp_lengthmultiplier: boolean;
    options: RuleOption[];
    selectedValue?: string;
    foxprofieldmapindex: number;
};

export interface CRMProductEntity {
    productcode: number;
    partno: string;
    productdescription: string;
    productid: string;
    uomid: string;
}

export type PamProductList = {
    productId: string;
} & Record<string, string>; // dynamic attribute name like "Shape", "Corrugation", etc.

export interface FetchXmlFilter {
    attribute: string;
    operator: string; // e.g., "eq", "neq", "like"
    value: string | number | boolean;
}

export interface ValidationResult {
    isValid: boolean;
    productCode: number | null;
    pamProductId: string | null;
    crmProductid: string | null;
    productPartNumber: string | null;
    productDescription: string | null;
    pamProductFamily: string | null;
    pamProductType: string | null;
    pamProductSubType: string | null;
    uomid: string | null;
}
