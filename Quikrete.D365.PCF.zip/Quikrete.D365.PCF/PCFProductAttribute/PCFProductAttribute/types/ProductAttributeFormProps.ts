// types/ProductAttributeFormProps.ts
import { IInputs } from "../generated/ManifestTypes";

export interface ProductAttributeFormProps {
    context: ComponentFramework.Context<IInputs>;
    notifyOutputChanged: () => void;
}
