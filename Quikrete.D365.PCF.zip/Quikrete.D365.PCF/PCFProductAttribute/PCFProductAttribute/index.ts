/* eslint-disable no-debugger */

/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-inferrable-types */

import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import * as ReactDOM from "react-dom/client";
import * as APIHelper from "./src/utils/CRMApi";
import ProductAttributeSelector from "./src/ProductAttributeSelector";
import { FontWeights } from "@fluentui/react";
// Assuming you have a CSS file for styles

export class PCFProductAttribute implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private container: HTMLDivElement;
    private root: ReactDOM.Root;
    private notifyOutputChanged: () => void;
    private context!: ComponentFramework.Context<IInputs>;

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this.container = container;
        this.notifyOutputChanged = notifyOutputChanged;
        this.root = ReactDOM.createRoot(container);
        this.context = context;

        // Call async init function
        this.waitForFormContextAndInitialize();
    }

    private waitForFormContextAndInitialize(
        attempts: number = 0,
        maxAttempts: number = 20,
        intervalMs: number = 100
    ): void {
        const _formContext = (window as any).FormContext;

        if (_formContext) {
            this.initializeControl(_formContext);
        }
        else if (attempts < maxAttempts) {
            setTimeout(() => {
                this.waitForFormContextAndInitialize(attempts + 1, maxAttempts, intervalMs);
            }, intervalMs);
        }
        else {
            // Render error message in the control
            this.root.render(
                React.createElement("div", {
                    style: {
                        display: "flex",
                        color: "red",
                        fontSize: "25px",
                        fontWeight: "bold"
                    }
                }, "⚠ Unable to load FormContext after waiting. Please refresh or contact admin.")
            );
        }
    }

    private async waitForBusinessUnitId(formContext: any, maxRetries = 10, intervalMs = 500): Promise<string> {
        return new Promise((resolve, reject) => {
            let attempts = 0;

            const checkBusinessUnit = async () => {
                try {
                    const businessUnitId = await APIHelper.getBusinessUnitFromRecord(formContext);

                    if (businessUnitId && businessUnitId.trim() !== "") {
                        resolve(businessUnitId);
                    } else if (attempts < maxRetries) {
                        attempts++;
                        console.warn(`Business Unit ID not found (attempt ${attempts}/${maxRetries}), retrying...`);
                        setTimeout(checkBusinessUnit, intervalMs);
                    } else {
                        reject(new Error("Business Unit ID not available after maximum retries."));
                    }
                } catch (error) {
                    reject(error);
                }
            };

            checkBusinessUnit();
        });
    }

    private async initializeControl(formContext: any): Promise<void> {
        try {


            // Step 2: Fetch business unit and related data
            const businessUnitId = await this.waitForBusinessUnitId(formContext);

            const types = await APIHelper.getTypesByUserBU(formContext, businessUnitId);
            const productFamiles = await APIHelper.getFamiliesByRecordBu(formContext, businessUnitId);

            // Step 1: Wait until CRM-bound fields are available
            const { productAttributeField, pamProductField, partNumber } =
                await this.waitForFormParameters();



            // Step 3: Fetch related entity data
            let crmValues: any = [];
            let pamValues: any = [];

            if (productAttributeField?.length > 0) {
                crmValues = await APIHelper.getProductAttributes(formContext, productAttributeField[0].id);
            }

            if (pamProductField?.length > 0) {
                pamValues = await APIHelper.getPamProductConfigDetails(formContext, pamProductField[0].id);
            }

            // If Type Exist then filter with type and bu
            let subTypes: any = [];
            if (pamValues?._crmgp_producttypeid_value) {
                subTypes = await APIHelper.getSubTypes(formContext, pamValues?._crmgp_producttypeid_value);
            }
            else {
                subTypes = await APIHelper.getSubTypesByRecordBU(formContext, businessUnitId);
            }

            const entityId = formContext.getCurrentRecordId();
            const opportunityId = formContext.getAttribute("opportunityid")?.getValue()?.[0]?.id?.replace(/[{}]/g, "").toLowerCase();
            // debugger
            this.root.render(
                React.createElement(ProductAttributeSelector, {
                    existingValues: {
                        type: pamValues?._crmgp_producttypeid_value,
                        subType: pamValues._crmgp_productsubtypeid_value,
                        family: pamValues._crmgp_productfamilyid_value,
                        crmEntityData: crmValues,
                        pamEntityData: pamValues,
                        partNumber: partNumber ?? ""
                    },
                    businessUnitId: businessUnitId,
                    typesOptions: types,
                    subTypesOptions: subTypes,
                    familyOptions: productFamiles,
                    formContext: formContext,
                    context: this.context
                })
            );
            // Step 4: Render React component safely

        } catch (err) {
            console.error("Error loading data:", err);

            // failed → hard reload
            try {
                this.root.unmount();
                this.root = ReactDOM.createRoot(this.container);
                this.waitForFormContextAndInitialize();
                return;
            } catch (inner) {
                console.error("Hard reload failed:", inner);
            }

            this.root.render(
                React.createElement("div", {
                    style: { color: "red", fontSize: "25px", fontWeight: "bold" }
                }, "⚠ Something went wrong while loading the attribute control. Please try refreshing the page.")
            );
        }
    }

    /**
     * Waits for context.parameters values to become available
     */
    private async waitForFormParameters(maxRetries = 10, intervalMs = 500): Promise<any> {
        return new Promise((resolve, reject) => {
            let attempts = 0;

            const checkValues = () => {
                const productAttributeField = this.context.parameters.ProductAttributeLookup?.raw;
                const pamProductField = this.context.parameters.PAMProductReference?.raw;
                const partNumber = this.context.parameters.ProductNumberReference?.raw;

                if (productAttributeField || pamProductField || partNumber) {
                    resolve({ productAttributeField, pamProductField, partNumber });
                } else if (attempts < maxRetries) {
                    attempts++;
                    setTimeout(checkValues, intervalMs);
                } else {
                    reject(new Error("Form parameters not ready after retries"));
                }
            };

            checkValues();
        });
    }

    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Add code to update control view
    }

    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as "bound" or "output"
     */
    public getOutputs(): IOutputs {
        return {};
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void {
        // Add code to cleanup control if necessary
        if (this.root) {
            this.root.unmount();
        }
    }
}
