/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    context: ComponentFramework.PropertyTypes.StringProperty;
    ProductAttributeLookup: ComponentFramework.PropertyTypes.LookupProperty;
    PAMProductReference: ComponentFramework.PropertyTypes.LookupProperty;
    ProductNumberReference: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    context?: string;
    ProductAttributeLookup?: ComponentFramework.LookupValue[];
    PAMProductReference?: ComponentFramework.LookupValue[];
    ProductNumberReference?: string;
}
